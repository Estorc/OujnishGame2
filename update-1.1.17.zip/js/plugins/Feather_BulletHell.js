//=============================================================================
// RPG Maker MZ - Bullet Hell Engine
//=============================================================================

/*:
 * @target MZ
 * @plugindesc A Bullet Hell Engine in RPG Maker MZ.
 * @author Feather
 *
 * @help 
 * This plugin provides a complete engine to create bullet hell scenes.
 *
 *
 * @command add
 * @text Add Object
 * @desc 
 * @arg name
 * @type string
 * @text Name
 * @desc 
 * @arg posx
 * @type variable
 * @text PosX
 * @desc 
 * @arg posy
 * @type variable
 * @text PosY
 * @desc 
 * @arg width
 * @type number
 * @text Width
 * @desc 
 * @arg height
 * @type number
 * @text Height
 * @desc 
 * @arg speed
 * @type variable
 * @text Speed
 * @desc 
 * @arg direction
 * @type variable
 * @text Direction
 * @desc 
 * @arg directioniscircle
 * @type boolean
 * @text DirectionIsCircle
 * @desc 
 * @arg sprite
 * @type file
 * @dir img/bhsprite/
 * @require 1
 * @text Sprite
 * @desc 
 * @arg hp
 * @type number
 * @text HP
 * @desc 
 * @arg candie
 * @type boolean
 * @text CanDie
 * @desc 
 * @arg canbetouched
 * @type boolean
 * @text CanBeTouched
 * @desc 
 * @arg action
 * @type number
 * @text ActionID
 * @desc 
 * @arg deathaction
 * @type number
 * @text DeathActionID
 * @desc 
 * @arg isPlayerShot
 * @type boolean
 * @text IsPlayerShot
 * @desc 
 * @arg isBonus
 * @type boolean
 * @text IsBonus
 * @desc
 * @arg BonusPower
 * @type number
 * @text BonusPower
 * @desc 
 *
 * @command remove
 * @text Remove Object
 * @desc 
 * @arg id
 * @type number
 * @text ID
 * @desc 
 *
 * @command removename
 * @text Remove Name
 * @desc 
 * @arg name
 * @type string
 * @text Name
 * @desc 
 *
 * @command clear
 * @text Clear Object
 * @desc 
 *
 * @command resetppg
 * @text Reset PPG
 * @desc 
 * @arg id
 * @type number
 * @text ID
 * @desc 
 */
 

(() => {
    const pluginName = "Feather_BulletHell";


	//-----------------------------------------------------------------------------
	// BulletHell
	//
	// The main class of the Bullet Hell Engine.


	BulletHell = function() {
		this.initialize(...arguments);
	};
	
	
	BulletHell.prototype.initialize = function() {
		
		// Ressources
		
		this.hitSFX = {name: 'Darkness6', pan: 0, pitch: 150, volume: 90};
		this.xpSFX = {name: 'Heal2', pan: 0, pitch: 150, volume: 90};
		this.levelUpSFX = {name: 'Up4', pan: 0, pitch: 150, volume: 90};
		this.levelMaxSFX = {name: 'Up8', pan: 0, pitch: 150, volume: 90};
		this.shotHitSFX = {name: 'Thunder2', pan: 0, pitch: 150, volume: 100};
		this.shotSFX = {name: 'Attack2', pan: 0, pitch: 150, volume: 60};
		
		// Damage
		
		this.modifier = 1;
		this.randomizer = 0;
		
		// Switches
		
		this.showCollisions = false;
		this.active = false;
		this.paused = false;
		this.showPictureBellow = false;
		this.movementsActive = true;


		// Screen
		
		this.bhmaxwidth = 200;
		this.bhmaxheight = 200;
		
		this.bhworldwidth = 1280;
		this.bhworldheight = 720;
		
		this.screenw = 1280;
		this.screenh = 720;
		
		this.screenx = 0;
		this.screeny = 0;
		
		this.xShift = 0;
		this.yShift = 0;
		
		// Events
		
		this.onHitEvents = [];
		this.onHit = function (damage) { let _this = this;this.onHitEvents.forEach(function(event){damage = event.call(_this,damage)}); return damage };
		
		// Children / Links
		
		this.spriteset = null;
		this.objectsSprite = {};
		this.objects = [];
		this.texts = [];
		this.scenes = [];
		this.activeScene = null;
	
	};
	

	BulletHell.loadScript = function(filename) {
		const url = ("js/plugins/bullethell/"+ filename +".js");
		const script = document.createElement("script");
		script.type = "text/javascript";
		script.src = url;
		script.async = false;
		script.defer = true;
		script._url = url;
		document.body.appendChild(script);
	};
	

	BulletHell.prototype.addEventOnHit = function (event) {
		
		this.onHitEvents.push(event);
		return this.onHitEvents.length-1;
		
	};
	
	
	BulletHell.prototype.remove = function (object) {
		let index = this.objects.indexOf(object);
		if (index !== -1) {
			this.objects.splice(index, 1);
			if(index <= this.iteration) {
				
				this.iteration--;
				
			}
		}
		return this;
	};
	
	
	BulletHell.prototype.reset = function() {
		
		$gameBulletHell.scenes = [];
		$gameBulletHell.activeScene = null;
		$gameBulletHell.objects = [];
		$gameBulletHell.active = false;
		$gameBulletHell.modifier = 1;
		$gameBulletHell.randomizer = 0;
		$gameBulletHell.showPictureBellow = false;
		$gameBulletHell.xShift = 0;
		$gameBulletHell.yShift = 0;
		
	};
	
	
	// Import all mains files

	BulletHell.loadScript("functions/main")
	BulletHell.loadScript("functions/scenes")
	BulletHell.loadScript("functions/utils")
	BulletHell.loadScript("functions/utils/seedrandom")
	BulletHell.loadScript("functions/transform")
	BulletHell.loadScript("functions/objects")
	BulletHell.loadScript("functions/sprites")
	BulletHell.loadScript("functions/player")
	BulletHell.loadScript("functions/text")
	BulletHell.loadScript("functions/actions")
	BulletHell.loadScript("functions/input")
	
	
	// Invoke BulletHell Instance
	
	$gameBulletHell = new BulletHell();


	//-----------------------------------------------------------------------------
	// Classes rewrite
	//
	
	
	___FeatherBH___Scene_Gameover_terminate = Scene_Gameover.prototype.terminate;
	Scene_Gameover.prototype.terminate = function() {
		___FeatherBH___Scene_Gameover_terminate.call(this);
		
		ConfigManager["battleAniSpeed"] = $gameBulletHell.activeScene.tempAniSpeed;
		$gameBulletHell.reset();
		
	};


	$BHWaitFrames = 0;
	___FeatherBH___Game_Interpreter_updateWait = Game_Interpreter.prototype.updateWait;
	Game_Interpreter.prototype.updateWait = function() {
		return ___FeatherBH___Game_Interpreter_updateWait.call(this) || $gameBulletHell.updateBHWaitFrames(this);
	};
	
	
	___FeatherBH___BattleManager_setup = BattleManager.setup;
	BattleManager.setup = function(troopId, canEscape, canLose) {
		___FeatherBH___BattleManager_setup.call(this, troopId, canEscape, canLose);
		this.bulletHellPreviousState = $gameBulletHell.active;
		$gameBulletHell.active = false;
	};
	
	
	___FeatherBH___Scene_Battle_terminate = Scene_Battle.prototype.terminate;
	Scene_Battle.prototype.terminate = function() {
		___FeatherBH___Scene_Battle_terminate.call(this);
		BattleManager.bulletHellPreviousState && ($gameBulletHell.active = BattleManager.bulletHellPreviousState);
		BattleManager.bulletHellPreviousState = null;
	};
	

	//-----------------------------------------------------------------------------
	// Plugin Commands
	//

	
    PluginManager.registerCommand(pluginName, "resetppg", args => {
		
		$gameBulletHell.ppg_attackPaternID = eval(args.id);

    });


    PluginManager.registerCommand(pluginName, "add", args => {
		
		bhargs = {};
		bhargs.name = args.name;
		bhargs.posx = $gameVariables.value(args.posx) + $gameBulletHell.bhmaxwidth/2;
		bhargs.posy = $gameVariables.value(args.posy) + $gameBulletHell.bhmaxheight/2;
		bhargs.width = parseFloat(args.width);
		bhargs.height = parseFloat(args.height);
		bhargs.speed = $gameVariables.value(args.speed);
		bhargs.direction = $gameVariables.value(args.direction);
		bhargs.sprite = args.sprite;
		bhargs.hp = parseFloat(args.hp);
		bhargs.candie = args.candie;
		bhargs.canbetouched = args.canbetouched;
		bhargs.action = parseFloat(args.action);
		bhargs.deathaction = parseFloat(args.deathaction);
		bhargs.directioniscircle = args.directioniscircle;
		bhargs.isPlayerShot = args.isPlayerShot;
		bhargs.isBonus = args.isBonus;
		bhargs.BonusPower = parseFloat(args.BonusPower);
		bhargs.anchorAligned = eval(args.anchorAligned);
		$gameBulletHell.createBHObject(bhargs);

    });
	
	
    PluginManager.registerCommand(pluginName, "remove", args => {
		$gameBulletHell.objects[args.id] = null;
        $gameBulletHell.objects.splice(args.id);
    });
	
	
    PluginManager.registerCommand(pluginName, "removename", args => {
		
		$gameBulletHell.removeObjectByName(args.name);
		
    });
	
	
    PluginManager.registerCommand(pluginName, "clear", args => {
		$gameBulletHell.texts = [];
		$gameBulletHell.objects = [];
		$gameBulletHell.BHBitmap = new Bitmap(1280 + $gameBulletHell.bhmaxwidth,720 + $gameBulletHell.bhmaxheight);
    });
	

    PluginManager.registerCommand(pluginName, "set", args => {
        textPictureText = String(args.text);
    });

	
})();
