module.exports = {
		
    name: 'Beast Battle',
	id: 1,


load (thisTurn, scene, parameters) {
	
	if (typeof scene.ppg_attackPaternID === 'undefined') {
		
		scene.ended = false;
		scene.ppg_attackPaternWillChange = false;
		scene.ppg_attackPaternID = 0;
		scene.ppg_currentSubject = null;
		scene.ppg_lastdialogue = 0;
		scene.active = false;
		
		scene.isBlueSoul = false;
		scene.soulHasJump = false;
		scene.soulGravity = 0;
		scene.soulJumpPower = 0;
		scene.soulDirection = 8;
		scene.tempAniSpeed = 0;
		
	}
	
	
	
	
	//SceneManager._scene._statusWindow.visible = false;
	
	if (!scene.tempAniSpeed) {
		scene.tempAniSpeed = ConfigManager["battleAniSpeed"]
	}
	ConfigManager["battleAniSpeed"] = 0
	
	if (!$gameMessage.isBusy()) {
		
		// Do the actions
		if (!scene.active) {
			
			this.active = true;
			
			
			scene.ppg_lastdialogue = 0;
			scene.soulDirection = 8;
			this.player.shotDelay = 2;
			this.player.collisionRect.x1 = 10;
			this.player.collisionRect.x2 = 24;
			this.player.collisionRect.y1 = 37;
			this.player.collisionRect.y2 = 52;
			$gameSwitches.setValue(514, false);
			
			this.gravModifier = 1;
			
			this.objects = [];
			
			
			
			scene.active = true;
			this.showPictureBellow = false;
			//const subject = thisTurn._subject;
			//const action = subject.currentAction();
			
				
			//_______________ ATTACK PATERN _____________________________


			args = {};args.name = "Boss";args.width = 242;args.height = 264;args.speed = 1;args.candie = "true";args.canbetouched = "true";args.deathaction = 12;args.isPlayerShot = "false";args.isBonus = "false";args.posx = 640-121+$gameBulletHell.bhmaxwidth/2;args.posy = -264+$gameBulletHell.bhmaxheight/2;args.directioniscircle = "false";args.sprite = 'beast';args.direction = 180;args.action = 13;args.hp = 6000;args.collision = [{type:'rect',x1:0,y1:0,x2:242,y2:83},{type:'rect',x1:66,y1:0,x2:23,y2:215},{type:'rect',x1:153,y1:0,x2:23,y2:215},{type:'rect',x1:108,y1:0,x2:26,y2:225},{type:'rect',x1:89,y1:0,x2:64,y2:190},{type:'circle',x:66,y:82,radius:66},{type:'circle',x:176,y:82,radius:66}];
					
			//this.createBHObject(args)
			
			
			args.anchorx = 0;
			args.opacity = 0;
			args.speed = 0;
			args.collision = [{}];
			args.sprite = 'hpbarCover';
			args.name = "hpbarCover";
			args.action = 'HP Bar';
			args.posx = this.bhmaxwidth/2+640-224/2;
			args.posy = this.bhmaxheight/2+720-45;
			args.candie = "false";
			args.zindex = 20;
			args.anchorAligned = false;
			this.createBHObject(args)
			
			args.sprite = 'hpbar';
			args.name = "hpbar";
			args.action = 'HP Bar';
			args.posx = this.bhmaxwidth/2+640-224/2;
			args.posy = this.bhmaxheight/2+720-45;
			args.zindex = 21;
			this.createBHObject(args)
			
			scene.ppg_attackPaternID++;

		}
		
		
		if (!this.paused) {

			this.player.canShot = !scene.isBlueSoul;
			this.player.shotType = 0;

			let leftBorder = -17;
			let rightBorder = 1263;
			let topBorder = -31;
			let bottomBorder = 689;
			
			if (this.player.pos.x < leftBorder) {
				
				this.player.pos.x = leftBorder;
				
			}
			
			if (this.player.pos.x > rightBorder) {
				
				this.player.pos.x = rightBorder;
				
			}
			
			if (this.player.pos.y < topBorder) {
				
				this.player.pos.y = topBorder;
				
			}
			
			if (this.player.pos.y > bottomBorder) {
				
				this.player.pos.y = bottomBorder;
				
			}

		}
		
		if (scene.ended) {
			this.player.collisionRect.x1 = 0;
			this.player.collisionRect.x2 = 0;
			this.player.collisionRect.y1 = 0;
			this.player.collisionRect.y2 = 0;
			this.player.pos.x = -50;
			$gameScreen.erasePicture(2);
			$gameScreen.erasePicture(4);
			this.clearSpinningAttack();
			scene.active = false;
			thisTurn.endAction && thisTurn.endAction();
			//thisTurn._subject = null;
			$gameScreen.erasePicture(3);
			this.objects = [];
			ConfigManager["battleAniSpeed"] = scene.tempAniSpeed;
			scene.tempAniSpeed = 0;
			scene.ended = false;
		}
	}
}
}