//-----------------------------------------------------------------------------
// Loading images ['gamedir://img/bhsprite/']
//


const imagesDir = 'img/bhsprite';


BHpreloadImages = function() {
	
let images = readdirSync(`${imagesDir}/`).filter(files => files.endsWith('.png'));

    for (const file of images) {
        console.log(`-> Loaded BHsprite ${file}`);
		$gameBulletHell.loadImages(file.slice(0, -4));
    };
	
};




//-----------------------------------------------------------------------------
// BulletHell
//
// The main class of the Bullet Hell Engine.


BulletHell.prototype.loadImages = function(name) {


if (name == "null" || name == null) {
	
	return null;
	
}

if (!this.objectsSprite.hasOwnProperty(name)) {
	
	let tempSprite = name.split('@');
	
	this.objectsSprite[name] = {
		bitmap: Bitmap.load("img/bhsprite/" + name + ".png"),
		frames: (tempSprite.length >= 2) ? eval(tempSprite[1]) : 1,
		frameDuration: (tempSprite.length == 3) ? eval(tempSprite[2]) : 10,
		name: name
	}
	
}

return this.objectsSprite[name];


};


//-----------------------------------------------------------------------------
// Spriteset_Feather
//
// New BulletHell functions for the Spriteset_Feather class.


Spriteset_Feather.prototype.createBulletHellSprite = function() {
    this._bhSprite = new Sprite();
	this._bhTexts = new Sprite();
    this.addChild(this._bhSprite);
	this.addChild(this._bhTexts);
};


Spriteset_Feather.prototype.addPlayerSprite = function(sprite,frames,angle) {
	
	let bh = $gameBulletHell;
		
	this.PLsprite = new Sprite(sprite);
	this.PLsprite.anchor.x = 0;
	this.PLsprite.anchor.y = 0;
	this.PLsprite.angle = angle;
	this.PLsprite.x = bh.player.pos.x - bh.screenx + bh.xShift;
	this.PLsprite.y = bh.player.pos.y - bh.screeny + bh.yShift;
	this.PLsprite.opacity = 255;
	this.PLsprite.scale.y = 1;
	this.PLsprite.scale.x = 1;
	this.PLsprite.zindex = 1;
	this.PLsprite.setFrame(bh.player.frame*(sprite.width/frames),0,sprite.width/frames, sprite.height);
	
	this._bhSprite.addChild(this.PLsprite);
	
	if (bh.showCollisions) {
		
		let plCollision = bh.player.drawPlayerCollision();
		plCollision.x = bh.player.pos.x+bh.player.collisionRect.x1 - bh.screenx + bh.xShift;
		plCollision.y = bh.player.pos.y+bh.player.collisionRect.y1 - bh.screeny + bh.yShift;
		plCollision.zindex = 9;
		this._bhSprite.addChild(plCollision)
		
	}
	
};


Spriteset_Feather.prototype.addSprite = function(i) {
	
	let bhsprite = {"width":0, "height":0};
	let bh = $gameBulletHell;
	let obj = bh.objects[i];

	if (obj.sprite && obj.sprite != "null") {
		
		let frames = obj.sprite.frames
		if (obj.hitframetimer > 0) {
			obj.frame += frames;
		};
		obj.canbetouched && (frames *= 2)
		bhsprite = obj.sprite.bitmap
		
		this.sprites[i] = new Sprite(bhsprite);
		this.sprites[i].anchor.x = obj.anchor.x;
		this.sprites[i].anchor.y = obj.anchor.y;
		this.sprites[i].angle = obj.angle;
		this.sprites[i].blendMode = obj.blendMode;
		this.sprites[i].x = (obj.anchorAligned ? 0 : (bhsprite.width/frames)*this.sprites[i].anchor.x) + obj.pos.x + obj.offset.x - bh.bhmaxwidth/2 - bh.screenx + bh.xShift;
		this.sprites[i].y = (obj.anchorAligned ? 0 : bhsprite.height*this.sprites[i].anchor.y) + obj.pos.y + obj.offset.y - bh.bhmaxheight/2 - bh.screeny + bh.yShift;
		this.sprites[i].opacity = obj.opacity;
		this.sprites[i].scale.y = obj.scale.y;
		this.sprites[i].scale.x = obj.scale.x;
		this.sprites[i].zindex = obj.zindex;
		this.sprites[i].setFrame(obj.frame*(bhsprite.width/frames),0,bhsprite.width/frames, bhsprite.height)
		
		if (obj.motionblurFrames) {
				for (item of obj.motionblurSprites) {
					item.opacity = (obj.motionblurSprites.indexOf(item)/(obj.motionblurFrames+1))*obj.opacity;
					this._bhSprite.addChild(item);
				};
				if (obj.motionblurSprites.length == obj.motionblurFrames) {
					obj.motionblurSprites.shift();
				}
				obj.motionblurSprites.push(this.sprites[i]);
		}
		
		this._bhSprite.addChild(this.sprites[i]);

		
		if (bh.showCollisions) {
			
			let colmaskBitmap = new Bitmap(0,0,bhsprite.width,bhsprite.height)
			this.colmasks[i] = new Sprite(colmaskBitmap);
			this.colmasks[i].anchor.x = this.sprites[i].anchor.x
			this.colmasks[i].anchor.y = this.sprites[i].anchor.y
			this.colmasks[i].angle = ((obj.collision_angle == 'angle') ? this.sprites[i].angle : obj.collision_angle)
			this.colmasks[i].x = this.sprites[i].x
			this.colmasks[i].y = this.sprites[i].y
			this.colmasks[i].scale.y = ((obj.collision_scale.y == 'scale') ? this.sprites[i].scale.y : obj.collision_scale.y);
			this.colmasks[i].scale.x = ((obj.collision_scale.x == 'scale') ? this.sprites[i].scale.x : obj.collision_scale.x);
			this.colmasks[i].zindex = 9;
			
			this.collisions[i] = obj.drawCollision();
			
			this.collisions[i].zindex = 9;
			this.collisions[i].x = -(bhsprite.width/frames)*this.colmasks[i].anchor.x - obj.offset.x
			this.collisions[i].y = -bhsprite.height*this.colmasks[i].anchor.y - obj.offset.y
			this.colmasks[i].addChild(this.collisions[i]);
			this._bhSprite.addChild(this.colmasks[i]);
			
		};
		
	}
	
	return bhsprite
};


//-----------------------------------------------------------------------------
// Spriteset_Feather rewrite
//


___FeatherBH___Spriteset_Feather_update = Spriteset_Feather.prototype.update;
Spriteset_Feather.prototype.update = function() {
	___FeatherBH___Spriteset_Feather_update.call(this);
	this.removeChild(this._pictureContainer);
	this.removeChild(this._bhSprite);
	this.removeChild(this._bhTexts);
	if ($gameBulletHell.showPictureBellow) {this.addChild(this._pictureContainer)};
	this.addChild(this._bhSprite);
	this.addChild(this._bhTexts);
	if ($gameBulletHell.active) { $gameBulletHell.update(this) };
	if (!$gameBulletHell.showPictureBellow) { this.addChild(this._pictureContainer) };
};


___FeatherBH___Spriteset_Feather_initialize = Spriteset_Feather.prototype.initialize;
Spriteset_Feather.prototype.initialize = function() {
	___FeatherBH___Spriteset_Feather_initialize.call(this);
	this.sprites = [];
	this.colmasks = [];
	this.collisions = [];
};


___FeatherBH___Spriteset_Feather_createUpperLayer = Spriteset_Feather.prototype.createUpperLayer;
Spriteset_Feather.prototype.createUpperLayer = function() {
	___FeatherBH___Spriteset_Feather_createUpperLayer.call(this);
	this.createBulletHellSprite();
};


Spriteset_Feather.prototype.createPictures = function() {
	const rect = this.pictureContainerRect();
	this._pictureContainer = new Sprite();
	this._pictureContainer.setFrame(rect.x, rect.y, rect.width, rect.height);
	for (let i = 1; i <= $gameScreen.maxPictures(); i++) {
		this._pictureContainer.addChild(new Sprite_Picture(i));
	}
};