module.exports = {
		
    name: 'SP_Crystal Star',
	id: 135,

    execute (index, _BH) {
		if(typeof this.begin === 'undefined') {
			this.timer = 0; 
			this.btimer = 0;
			this.maxhp = this.hp;
			
			this.animt = 0; 
			this.animy = this.pos.y;
			this.animx = this.pos.x;
			this.anima = this.angle;
			this.animd = 60;
			this.desty = 272+44;
			this.destx = 0;
			this.desta = 0;
			this.explode = false;
			
			this.begin = 0;
		}
		
		
		if (this.hp <= 0) {
			
				_BH.removeObjectByName(`${this.name} 54`);
				AudioManager.playSe({name: 'Earth4', pan: 0, pitch: 150, volume: 200});
				AudioManager.playSe({name: 'Fire2', pan: 0, pitch: 100, volume: 200});
				for (n = 0; n<100; n++) {
					
					args = {};
					args.name = "";
					args.posx = this.pos.x + 43-8;
					args.posy = this.pos.y + 43-8;
					args.offsetx = -8;
					args.offsety = -8;
					args.width = 16;
					args.height = 16;
					args.speed = 2+Math.random()*5;
					args.direction = Math.random()*360;
					args.directioniscircle = "true";
					args.sprite = 'WarudoBullet';
					args.hp = 0;
					args.candie = "false";
					args.canbetouched = "false";
					args.action = 0;
					args.deathaction = 0;
					args.isPlayerShot = "false";
					args.isBonus = "false";
					args.anchorAligned = false;
					_BH.createBHObject(args)
					
				}
				
				this.candie = true;
			return 0;
			
		}
			
		
		if (this.animt < this.animd) {
			this.animt += 1;
			this.pos.y = _BH.easeOutSine(this.animt,this.animy,this.desty,this.animd);
			this.pos.x = _BH.easeOutSine(this.animt,this.animx,this.destx,this.animd);
			this.angle = _BH.easeOutSine(this.animt,this.anima,this.desta,this.animd);
			args = {};
			args.name = "";
			args.posx = this.pos.x;
			args.posy = this.pos.y;
			args.width = 0;
			args.height = 0;
			args.speed = 0;
			args.direction = 0;
			args.directioniscircle = "true";
			args.sprite = 'crystalStar';
			args.hp = 10;
			args.candie = "true";
			args.canbetouched = "true";
			args.action = 'Disappear Object';
			args.deathaction = 0;
			args.isPlayerShot = "false";
			args.scalex = this.scale.x;
			args.scaley = this.scale.y;
			args.collision = [{}];
			args.isBonus = "false";
			args.zindex = -1;
			args.angle = this.angle;
			args.anchorAligned = false;
			_BH.createBHObject(args)
			
		} else {
			
			if (this.explode) {
				
				_BH.objects[0].explode = true;
				if (this.maxhp == 9999) {
					_BH.damageValue = (10000 - this.hp)*10;
				} else {
					_BH.damageValue = (10000 - this.hp)*30;
				}
				this.hp = 0;
				
			}
			
			if (this.timer % 360 == 0 && this.maxhp == 9999) {
			
				this.animt = 0;
				this.animd = 30;
				this.animy = this.pos.y;
				this.animx = this.pos.x;
				this.desty = 272+44+Math.random()*200-100 - this.animy;
				this.destx = 640+44+Math.random()*200-100 - this.animx;
				
			this.anima = this.angle;
			this.desta = 360;
				
			}
			
			if (this.timer % 360 == 1 && this.maxhp != 1) {
				if (this.maxhp == 9999) {
					
					_BH.createTFHeartPointer(this.pos.x+44,this.pos.y+44,3,360,`${this.name} 54`);
				
				} else {
					
					_BH.createHeartPointer(this.pos.x+44,this.pos.y+44,3,360,`${this.name} 54`);
					
				}
			}
			
			this.timer += 1;
			
		}
		
    },
};