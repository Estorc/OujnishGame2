module.exports = {
		
    name: 'Top Hat Letter Bottom',
	id: 35,

    execute (index, _BH) {
		if (typeof this.letters === 'undefined') { 

			if (this.pos.x > 1280/2 + _BH.bhmaxwidth/2 + 16) {
				
				this.letters = ['ppg_letter1','ppg_letter2','ppg_letter3','ppg_letter4','ppg_letter5'];
				
			} else {
				
				this.letters = ['ppg_letter5','ppg_letter4','ppg_letter3','ppg_letter2','ppg_letter1'];
				
			}

		}
			
		if (typeof this.maxhp === 'undefined') { this.maxhp = this.hp }
			
		
		if (this.speed > 0 && this.direction.y != -1) {
			if (this.pos.y > 100) {
				if (this.speed <= 1) {
					
					this.speed = 0;
					this.pos.y = Math.ceil(this.pos.y);
					this.pos.x = Math.ceil(this.pos.x);
					
				} else {
				
					this.speed *= 0.25;
				
				}
			}
		} else {
			
			this.hp -= 1;
			
			
			if (this.hp == Math.floor(this.maxhp*0.9)) {
				
					_BH.createPlayerDirigedBullet(this.pos.x+8,this.pos.y+48,this.letters[0],32,32,5,index,0,0,[{'type':'circle','x':32/2,'y':32/2,'radius': (64)/4}])
					AudioManager.playSe({name: 'Shot2', pan: 0, pitch: 150, volume: 100});
					
			}
				
				
				
			if (this.hp == Math.floor(this.maxhp*0.7)) {
				
					_BH.createPlayerDirigedBullet(this.pos.x+8,this.pos.y+48,this.letters[1],32,32,5,index,0,0,[{'type':'circle','x':32/2,'y':32/2,'radius': (64)/4}])
					AudioManager.playSe({name: 'Shot2', pan: 0, pitch: 150, volume: 100});
					
			}
				
				
				
			if (this.hp == Math.floor(this.maxhp*0.5)) {
				
					_BH.createPlayerDirigedBullet(this.pos.x+8,this.pos.y+48,this.letters[2],32,32,5,index,0,0,[{'type':'circle','x':32/2,'y':32/2,'radius': (64)/4}])
					AudioManager.playSe({name: 'Shot2', pan: 0, pitch: 150, volume: 100});
					
			}
				
				
				
			if (this.hp == Math.floor(this.maxhp*0.3)) {
				
					_BH.createPlayerDirigedBullet(this.pos.x+8,this.pos.y+48,this.letters[3],32,32,5,index,0,0,[{'type':'circle','x':32/2,'y':32/2,'radius': (64)/4}])
					AudioManager.playSe({name: 'Shot2', pan: 0, pitch: 150, volume: 100});
					
			}
				
				
				
			if (this.hp == Math.floor(this.maxhp*0.1)) {
				
					_BH.createPlayerDirigedBullet(this.pos.x+8,this.pos.y+48,this.letters[4],32,32,5,index,0,0,[{'type':'circle','x':32/2,'y':32/2,'radius': (64)/4}])
					AudioManager.playSe({name: 'Damage2', pan: 0, pitch: 150, volume: 100});
					
			}
			
			if (this.hp <= 0) {
				
				if (this.speed == 0) {this.direction.y *= -1; this.speed = 1}
				this.speed *= 1.25;
			}
			
		}
    },
};