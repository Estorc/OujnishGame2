module.exports = {
		
    name: 'HP Bar',
	id: 1150,

    execute (index, _BH) {
		
		let currentHp = $gameParty.battleMembers().reduce((a, b)=> a + b.hp,0)/$gameParty.battleMembers().reduce((a, b)=> a + b.mhp,0);
		
		if (!this.name.contains("static")) {
		
			if (typeof this.lastHp === 'undefined') {
				this.lastHp = currentHp;
				this.animt = 0; 
				this.desto = 0;
			}
			
			if (this.desto > 0) {
				
				this.opacity = _BH.easeOutSine(this.animt,0,255,30);
				this.animt += (this.desto == 1) ? 1 : -0.5;
				if (this.animt == 30) this.desto = 2;
				if (this.desto == 2 && this.animt == 0) {this.desto = 0; this.opacity = 0};
				
			}
		
		}
		
		if (this.name.contains("hpbar")) {
			
			this.scale.x = currentHp;
		
		}

		if (!this.name.contains("static")) {
		
			this.pos.x = _BH.player.pos.x+37/2+_BH.bhmaxwidth/2-56/2;
			this.pos.y = _BH.player.pos.y+62/2+_BH.bhmaxwidth/2-25;
			
			if (currentHp != this.lastHp) {
				
				this.animt = 0;
				this.desto = 1;
				
				this.lastHp = currentHp;		
				
			}
		
		}
		
    },
};