module.exports = {
		
    name: 'OTF_Eye',
	id: 1101,

    execute (index, _BH) {
		if(typeof this.begin === 'undefined') {

			this.begin = 0;
			this.timer = 0;
			this.originx = this.pos.x;
			this.originy = this.pos.y;
			
		}
		
		this.angle = _BH.getDirectionToPlayer(index,37,37)
		
	},
};