module.exports = {
		
    name: 'KK_HeadLoading',
	id: 1101,

    execute (index, _BH) {
		if(typeof this.begin === 'undefined') {

			this.begin = 0;
			this.timer = 0;
			this.originx = this.pos.x;
			this.originy = this.pos.y;
			this.parent.stopTurning = true;
			
		}

		this.angle = this.parent.angle;
		this.anchor.y = this.parent.anchor.y;
		
		if (this.frame >= 7 && this.frametimer >= 4) {
			
			this.frametimer = 4;
			
			if (this.timer == 0) {
				
				args = {};
				args.name = "";
				args.posx = this.pos.x+123;
				args.posy = this.pos.y+123-30;
				args.width = 1470*2 + 316;
				args.height = 60;
				args.speed = 0;
				args.direction = 0;
				args.directioniscircle = "false";
				args.sprite = 'KK-CannonLaser';
				args.hp = 0;
				args.candie = "false";
				args.opacity = 0;
				args.canbetouched = "false";
				args.cantbeinstakill = "true";
				args.action = "KK_CannonLaser";
				args.anchorx = 0;
				args.deathaction = 0;
				args.anchory = 0.5;
				args.scaley = 0;
				args.angle = this.angle+90;
				args.collision_angle = "angle";
				args.isPlayerShot = "false";
				args.isBonus = "false";
				args.anchorAligned = false;
				_BH.createBHObject(args)
			
			}
			
			this.timer += 1;
			
			if (this.timer >= 150) {
				
				this.parent.stopTurning = false;
				this.candie = true;
				this.hp = 0;
				
			}
			
		}
		
	},
};