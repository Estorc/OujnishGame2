module.exports = {
		
    name: 'KK_Arm1',
	id: 1102,

    execute (index, _BH) {
		if(typeof this.begin === 'undefined') {

			this.begin = 0;
			this.timer = 0;
			this.originx = this.pos.x;
			this.originy = this.pos.y;
			
		}
		
		this.timer += 0.1;
		this.scale.x = Math.sin(this.timer)/16+1.0625
		this.scale.y = Math.sin(this.timer)/16+1.0625
		
		if (_BH.objects[0].hp < 750) {
		
			if (_BH.objects[0].hp % 5 == 0 && _BH.objects[0].hp % 50 < 35) {
				
				AudioManager.playSe({name: 'Attack2', pan: 0, pitch: 200, volume: 40});
			
					args = {};
					args.name = "";
					args.width = 16;
					args.height = 16;
					args.speed = 5;
					args.direction = 180;
					args.directioniscircle = "false";
					args.sprite = 'thanoscarbullet';
					args.hp = 0;
					args.scalex = 0.5;
					args.scaley = 0.5;
					args.damage = 0.75;
					args.collision_scalex = 'scale'
					args.collision_scaley = 'scale'
					args.candie = "false";
					args.canbetouched = "false";
					args.action = 0;
					args.deathaction = 0;
					args.isPlayerShot = "false";
					args.isBonus = "false";
					
					for (let i = 0; i<8; i++) {
					
						switch (i) {
							
						case 0:
							args.posx = this.pos.x + 640 + -315*this.scale.x -8;
							args.posy = this.pos.y + 114 + 97*this.scale.y -8;
							break;
							
						case 1:
							args.posx = this.pos.x + 640 + -266*this.scale.x -8;
							args.posy = this.pos.y + 114 + 167*this.scale.y -8;
							break;
							
						case 2:
							args.posx = this.pos.x + 640 + -176*this.scale.x -8;
							args.posy = this.pos.y + 114 + 237*this.scale.y -8
							break;
							
						case 3:
							args.posx = this.pos.x + 640 + -86*this.scale.x -8;
							args.posy = this.pos.y + 114 + 167*this.scale.y -8;
							break;
							
						case 4:
							args.posx = this.pos.x + 640 + 86*this.scale.x -8;
							args.posy = this.pos.y + 114 + 167*this.scale.y -8;
							break;
							
						case 5:
							args.posx = this.pos.x + 640 + 176*this.scale.x -8;
							args.posy = this.pos.y + 114 + 237*this.scale.y -8
							break;
							
						case 6:
							args.posx = this.pos.x + 640 + 266*this.scale.x -8;
							args.posy = this.pos.y + 114 + 167*this.scale.y -8;
							break;
							
						case 7:
							args.posx = this.pos.x + 640 + 315*this.scale.x -8;
							args.posy = this.pos.y + 114 + 97*this.scale.y -8
							break;
						}
						args.anchorAligned = false;
						_BH.createBHObject(args)
					
					}
					
			}
			
		} else {
		
			if (_BH.objects[0].hp % 150 == 0) {
				
				AudioManager.playSe({name: 'Attack2', pan: 0, pitch: 150, volume: 80});
			
					args = {};
					args.name = "";
					args.width = 16;
					args.height = 16;
					args.speed = 10;
					args.directioniscircle = "true";
					args.sprite = 'thanoscarbullet';
					args.hp = 0;
					args.scalex = 1;
					args.scaley = 1;
					args.damage = 0.5;
					args.collision_scalex = 'scale'
					args.collision_scaley = 'scale'
					args.candie = "false";
					args.canbetouched = "false";
					args.action = 0;
					args.deathaction = 0;
					args.isPlayerShot = "false";
					args.isBonus = "false";
					
					for (let i = 0; i<8; i++) {
					
						switch (i) {
							
						case 0:
							args.posx = this.pos.x + 640 + -315*this.scale.x -8;
							args.posy = this.pos.y + 114 + 97*this.scale.y -8;
							break;
							
						case 1:
							args.posx = this.pos.x + 640 + -266*this.scale.x -8;
							args.posy = this.pos.y + 114 + 167*this.scale.y -8;
							break;
							
						case 2:
							args.posx = this.pos.x + 640 + -176*this.scale.x -8;
							args.posy = this.pos.y + 114 + 237*this.scale.y -8
							break;
							
						case 3:
							args.posx = this.pos.x + 640 + -86*this.scale.x -8;
							args.posy = this.pos.y + 114 + 167*this.scale.y -8;
							break;
							
						case 4:
							args.posx = this.pos.x + 640 + 86*this.scale.x -8;
							args.posy = this.pos.y + 114 + 167*this.scale.y -8;
							break;
							
						case 5:
							args.posx = this.pos.x + 640 + 176*this.scale.x -8;
							args.posy = this.pos.y + 114 + 237*this.scale.y -8
							break;
							
						case 6:
							args.posx = this.pos.x + 640 + 266*this.scale.x -8;
							args.posy = this.pos.y + 114 + 167*this.scale.y -8;
							break;
							
						case 7:
							args.posx = this.pos.x + 640 + 315*this.scale.x -8;
							args.posy = this.pos.y + 114 + 97*this.scale.y -8
							break;
						}
						args.motionblurFrames = 3;
						args.direction = _BH.getDirectionToPosition(args.posx+8,args.posy+8,_BH.player.pos.x+18+_BH.bhmaxwidth/2,_BH.player.pos.y+43+_BH.bhmaxheight/2);
						args.anchorAligned = false;
						_BH.createBHObject(args)
					
					}
					
			}
			
		}
		
		
	},
};