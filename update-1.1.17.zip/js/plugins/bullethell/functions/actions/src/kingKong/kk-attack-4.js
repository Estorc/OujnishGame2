module.exports = {
		
    name: 'KK Attack 4',
	id: 4204,

    execute (index, _BH) {
			if(typeof this.begin === 'undefined') {

				this.scene.swapSoul("blue");
				this.maxhp = this.hp;
				_BH.player.pos.x = 640-18;
				_BH.player.pos.y = 800;
				this.begin = 0;
				this.bones = [];
				
			}


			if (this.hp == this.maxhp) {
				
				
			for (let i = 0; i<37; i++) {
					
				args = {};
				args.name = "";
				args.speed = 0;
				args.directioniscircle = "false";
				args.hp = 34+8-Math.sin(i/37*Math.PI)*8;
				args.candie = "true";
				args.canbetouched = "false";
				args.deathaction = 0;
				args.isPlayerShot = "false";
				args.isBonus = "false";
				args.cantbeinstakill = "true";
				args.action = 2401;
				args.sprite = "bonepart1";
				args.width = 0;
				args.height = 0;
				args.collision = [{}];
				args.anchorx = 0;
				args.posx = 452+8 + i*10 + _BH.bhmaxwidth/2;
				args.posy = 76 + _BH.bhmaxwidth/2;
				args.angle = 90;
				args.collision_angle = "angle";
				args.direction = args.angle-270;
				args.anchorAligned = false;
				_BH.createBHObject(args)
				
			}
			
			}
			
			
			if (this.hp % 30 == 0) {
			
			for (let j = 0; j<2; j++) {
					
				args = {};
				args.name = "";
				args.speed = 2.5;
				args.directioniscircle = "false";
				args.hp = (j == 0) ? 58.5 : 2.5;
				args.candie = "true";
				args.canbetouched = "false";
				args.deathaction = 0;
				args.isPlayerShot = "false";
				args.isBonus = "false";
				args.cantbeinstakill = "true";
				args.action = 2401;
				args.sprite = "bonepart1";
				args.width = 0;
				args.height = 0;
				args.collision = [{}];
				args.anchorx = 0;
				args.posx = 452+8-5 + j*370 + _BH.bhmaxwidth/2;
				args.posy = ((j == 0) ? 76 : 460) + _BH.bhmaxwidth/2;
				args.angle = (j == 0) ? 90 : 270;
				args.collision_angle = "angle";
				args.direction = (j == 0) ? 90 : -90;
				args.anchorAligned = false;
				this.bones.push(_BH.createBHObject(args))
				
			}
			
			}
			
			
			
			
			this.bones.forEach(function (x) {
				if ((x.angle == 270 && x.pos.x < 452+8-5 + _BH.bhmaxwidth/2) || (x.angle == 90 && x.pos.x > 452+8 + 370-5+ _BH.bhmaxwidth/2)) {
					
					x.hp = 0
					
				}
				
			})
			
			
			this.hp -= 1;


    },
};