module.exports = {
		
    name: 'Top Hat Letter Bottom',
	id: 801,

    execute (index, _BH) {
		if (typeof this.letters === 'undefined') { 

			if (this.pos.x > 1280/2 + _BH.bhmaxwidth/2 + 16) {
				
				this.letters = ['tf_letter1','tf_letter2','tf_letter3','tf_letter4','tf_letter1'];
				
			} else {
				
				this.letters = ['tf_letter1','tf_letter4','tf_letter3','tf_letter2','tf_letter1'];
				
			}

		}
			
		if (typeof this.maxhp === 'undefined') { this.maxhp = this.hp }
			
		
		if (this.speed > 0 && this.direction.y != -1) {
			if (this.pos.y > 100) {
				if (this.speed <= 1) {
					
					this.speed = 0;
					this.pos.y = Math.ceil(this.pos.y);
					this.pos.x = Math.ceil(this.pos.x);
					
				} else {
				
					this.speed *= 0.25;
				
				}
			}
		} else {
			
			this.hp -= 1;
			
			
			if (this.hp == Math.floor(this.maxhp*0.9)) {
				
					_BH.createPlayerDirigedBullet(this.pos.x+8,this.pos.y+48,this.letters[0],32,32,5,index,0,0,[{'type':'circle','x':32/2,'y':32/2,'radius': (64)/4}])
					AudioManager.playSe({name: 'Bow1', pan: 0, pitch: 150, volume: 100});
					
			}
				
				
				
			if (this.hp == Math.floor(this.maxhp*0.7)) {
				
					_BH.createPlayerDirigedBullet(this.pos.x+8,this.pos.y+48,this.letters[1],32,32,5,index,0,0,[{'type':'circle','x':32/2,'y':32/2,'radius': (64)/4}])
					AudioManager.playSe({name: 'Bow1', pan: 0, pitch: 150, volume: 100});
					
			}
				
				
				
			if (this.hp == Math.floor(this.maxhp*0.5)) {
				
					_BH.createPlayerDirigedBullet(this.pos.x+8,this.pos.y+48,this.letters[2],32,32,5,index,0,0,[{'type':'circle','x':32/2,'y':32/2,'radius': (64)/4}])
					AudioManager.playSe({name: 'Bow1', pan: 0, pitch: 150, volume: 100});
					
			}
				
				
				
			if (this.hp == Math.floor(this.maxhp*0.3)) {
				
					_BH.createPlayerDirigedBullet(this.pos.x+8,this.pos.y+48,this.letters[3],32,32,5,index,0,0,[{'type':'circle','x':32/2,'y':32/2,'radius': (64)/4}])
					AudioManager.playSe({name: 'Bow1', pan: 0, pitch: 150, volume: 100});
					
			}
				
				
				
			if (this.hp == Math.floor(this.maxhp*0.1)) {
				
					_BH.createPlayerDirigedBullet(this.pos.x+8,this.pos.y+48,this.letters[4],32,32,5,index,0,0,[{'type':'circle','x':32/2,'y':32/2,'radius': (64)/4}])
					AudioManager.playSe({name: 'Bow1', pan: 0, pitch: 150, volume: 100});
					AudioManager.playSe({name: 'DevourerAttack', pan: 0, pitch: 150, volume: 60});
					
			}
			
			if (this.hp <= 0) {
				
				if (this.speed == 0) {this.direction.y *= -1; this.speed = 1}
				this.speed *= 1.25;
			}
			
		}
    },
};