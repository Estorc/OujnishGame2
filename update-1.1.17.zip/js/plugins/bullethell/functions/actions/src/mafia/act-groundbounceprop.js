module.exports = {
		
    name: 'Ground Bounce Prop',
	id: 86,

    execute (index, _BH) {
			if (typeof this.gravity === 'undefined') { 
				this.random = Math.floor(Math.random()*2);
				this.baseX = this.pos.x;
				this.maxY = this.pos.y+20;
				this.gravity = 5
				this.zindex = 3;
				this.oldCollision = this.collision;				
				
				args = {};
				args.name = "";
				args.speed = 0;
				args.directioniscircle = "false";
				args.hp = 1;
				args.candie = "true";
				args.canbetouched = "false";
				args.deathaction = 0;
				args.isPlayerShot = "false";
				args.isBonus = "false";
				args.cantbeinstakill = "true";
				args.action = 0;
				args.sprite = 'BombBulletShadow';
				args.width = 0;
				args.height = 0;
				args.offsety = 0;
				args.offsetx = 0;
				args.posx = this.pos.x;
				args.posy = this.maxY-16;
				args.direction = 0;
				args.zindex = -0.5;
				args.collision = [{}];
				args.anchorAligned = false;
				this.shadow = _BH.createBHObject(args)
				this.cantbeinstakill = true;
				this.hp = 1;
			}
			this.gravity -= 0.25;
			this.maxY += ((this.random) ? 2 : -1)/(1+Math.abs(this.baseX-this.pos.x)/10);
			
			this.pos.y -= this.gravity;
			if (typeof this.shadow !== 'undefined' && typeof this.shadow.pos.y !== 'undefined') {
				this.shadow.pos.y = this.maxY-16;
				this.shadow.pos.x = this.pos.x
			}
		
		if (this.pos.y < this.maxY-48) {
			
			this.collision = [{}]
			this.zindex = 3;
			
		} else {
			
			this.collision = this.oldCollision;
			this.zindex = 0.5;
			
		}
		
		if (this.pos.y > this.maxY-this.height && this.pos.x < 808 + _BH.bhmaxwidth/2 - this.width && this.pos.x > 472 + _BH.bhmaxwidth/2) {
			
				this.pos.y = this.maxY-this.height;
				this.gravity = Math.abs(this.gravity*((this.random) ? 0.75 : 1));
				if (this.direction.y < 0) {
					this.gravity /= 1+Math.abs(this.direction.y);
				}
				this.direction.y = 0;
			
		}
		if ((this.pos.x > 808 + _BH.bhmaxwidth/2 - this.width || this.pos.x < 472 + _BH.bhmaxwidth/2) || this.pos.y > 720+$gameBulletHell.bhmaxheight/2) {
			
				this.shadow.hp = 0;
			
		}
		
		
		let maxYTruck = 302;
		
		if (this.pos.x > 808-90 + _BH.bhmaxwidth/2 - this.width && !(this.pos.x > 808 + _BH.bhmaxwidth/2 - this.width)) {
			
				maxYTruck = 302;
				maxYTruck += 73 * ((this.pos.x-(808-90 + _BH.bhmaxwidth/2 - this.width))/(808 + _BH.bhmaxwidth/2 - this.width -(808-90 + _BH.bhmaxwidth/2 - this.width)));
			
		}
		
		if (this.pos.x < 472+90 + _BH.bhmaxwidth/2 && !(this.pos.x < 472 + _BH.bhmaxwidth/2)) {
			
				maxYTruck = 375;
				maxYTruck -= 73 * ((this.pos.x-(472 + _BH.bhmaxwidth/2))/((472+90 + _BH.bhmaxwidth/2) - (472 + _BH.bhmaxwidth/2)));
			
		}
		
		if (this.collideWithPlayer || (this.maxY < maxYTruck+$gameBulletHell.bhmaxheight/2 && this.pos.y > this.maxY-32)) {
			
			this.shadow.hp = 0;
			this.hp = 0;
			this.candie = true;
			
		}
    },
};