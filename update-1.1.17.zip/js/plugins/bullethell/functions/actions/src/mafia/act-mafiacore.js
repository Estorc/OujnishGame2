module.exports = {
		
    name: 'Mafia Core',
	id: 80,

    execute (index, _BH) {
		if(typeof this.begin === 'undefined') {
			this.timer = 1; 
			this.timerSpeed = 1; 
			this.begin = 0;
			this.dialogue = 0;
		}
		

		_BH.openBlackBars(this.timer == 120);
		
		
			if (this.timer == 180) {
				if (this.dialogue < 1) {
					$gameMessage.setFaceImage("Oujnish6", 7);
					$gameMessage.setSpeakerName("Louis Émile de Réac");
					$gameMessage.add("Des hologrammes de mafieux vont apparaître, essaie");
					$gameMessage.add("de résister le plus lontemps possible !");
					this.dialogue += 1;
				
				} 
				if ($gameMessage.isBusy())	{
					
					_BH.player.pos.x = _BH.player.lastX;
					_BH.player.pos.y = _BH.player.lastY;
					return 0;
					
				}
				
			_BH.closeBlackBars(true);
			}
			
			_BH.deleteBlackBars(this.timer == 240);		

			
			if (((this.timer / 500 >> 0) % 4 < 3 || this.timer > 5000) && this.timer % (Math.floor(240*this.timerSpeed)+1) == 0) {
			
				args = {};
				args.name = "";
				args.speed = 0;
				args.directioniscircle = "false";
				args.hp = 0;
				args.candie = "false";
				args.canbetouched = "false";
				args.deathaction = 0;
				args.isPlayerShot = "false";
				args.isBonus = "false";
				args.cantbeinstakill = "false";
				let random = Math.floor(Math.random()*2);
				args.action = (random) ? 81 : 82;
				args.sprite = (random) ? 'Mafia1@2' : 'Mafia2@2';
				args.width = 48;
				args.height = 96;
				args.offsety = 0;
				args.offsetx = 0;
				random = Math.floor(Math.random()*2);
				args.posx = 640+48*((random) ? -4 : 3) + $gameBulletHell.bhmaxwidth/2+((random) ? -20 : 20) + ((random) ? -1 : 1)*Math.floor(Math.random()*108);
				args.posy = 720;
				args.direction = 0;
				args.anchorAligned = false;
				_BH.createBHObject(args)
				
			}
			
			
			if (((this.timer / 1500  >> 0) % 2 == 0 || this.timer > 30000) && this.timer % (Math.floor(750*this.timerSpeed)+1) == 0) {
			
				args = {};
				args.name = "";
				args.speed = 5;
				args.directioniscircle = "false";
				args.hp = 0;
				args.candie = "false";
				args.canbetouched = "false";
				args.deathaction = 0;
				args.isPlayerShot = "false";
				args.isBonus = "false";
				args.cantbeinstakill = "false";
				args.action = 83;
				args.sprite = 'Mafia5@2';
				let random = Math.floor(Math.random()*2);
				args.scalex = (random) ? -1 : 1
				args.direction = (random) ? 270 : 90;
				args.posx = (random) ? _BH.bhworldwidth - _BH.xShift + _BH.bhmaxwidth/2 : -48+_BH.bhmaxwidth/2 - _BH.xShift;
				args.posy = 150+Math.floor(Math.random()*350);
				args.width = 48;
				args.height = 48;
				args.offsety = 0;
				args.offsetx = 0;
				args.zindex = 10;
				args.collision = [{}];
				args.anchorAligned = false;
				_BH.createBHObject(args)
				
			}
			
			if ((this.timer / 1500 + 1 >> 0) % 2 == 0 && this.timer % (Math.floor(400*this.timerSpeed)+1) == 0) {
			
				args = {};
				args.name = "";
				args.speed = 0;
				args.directioniscircle = "false";
				args.hp = 0;
				args.candie = "false";
				args.canbetouched = "false";
				args.deathaction = 0;
				args.isPlayerShot = "false";
				args.isBonus = "false";
				args.cantbeinstakill = "false";
				args.action = 88;
				args.sprite = 'Mafia4@2';
				args.direction = 180;
				args.posx = Math.random()*1328+_BH.bhmaxwidth/2-48;
				args.posy = -48 - _BH.yShift;
				args.width = 48;
				args.height = 48;
				args.offsety = 0;
				args.offsetx = 0;
				args.zindex = 10;
				args.collision = [{}];
				args.anchorAligned = false;
				_BH.createBHObject(args)
				
			}
			
				this.timerSpeed -= this.timer/1000000000
				if (this.timerSpeed < 0.4) {
					
					this.timerSpeed = 0.4
					
				}
			
			this.timer += 1;
    },
};