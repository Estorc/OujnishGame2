//-----------------------------------------------------------------------------
// BulletHell
//
// The main class of the Bullet Hell Engine.


BulletHell.prototype.easeOutSine = function (t, b, c, d) {
		return c * Math.sin(t / d * (Math.PI / 2)) + b;
};


BulletHell.prototype.getRandomInt = function(max) {
	  return Math.floor(Math.random() * max);
};


BulletHell.prototype.updateBHWaitFrames = function(a) {
	
	
	if (typeof a.BHWaitFrames !== 'undefined') {
		if ($gameVariables.value(48) >= 1) {
			return true;
		}
		
		a.BHWaitFrames = $BHWaitFrames;

		return (typeof a.BHWaitFrames !== 'undefined' && a.BHWaitFrames < a.BHWaitFramesEnd);
	} else {
		
		return false;
		
	}
	
};


BulletHell.prototype.openBlackBars = function (condition) {
	
	if (condition) {
				params = [8, "CutsceneBlacksBars", 1, 0, 640, 360, 150, 150, 0, 0]
				
				point = Game_Interpreter.prototype.picturePoint.call(null, params);
				// prettier-ignore
				$gameScreen.showPicture(
					params[0], params[1], params[2], point.x, point.y,
					params[6], params[7], params[8], params[9]
				);
				
				params = [8, 3, 1, 0, 640, 360, 100, 100, 255, 0, 60, false, 0]
				
				point = Game_Interpreter.prototype.picturePoint.call(null, params);
				
				$gameScreen.movePicture(
					params[0], params[2], point.x, point.y, params[6], params[7],
					params[8], params[9], params[10], params[12] || 0
				);
				if (params[11]) {
					thisTurn.wait(params[10]);
				}
	}
	
};


BulletHell.prototype.closeBlackBars = function (condition) {
	
	if (condition) {
				params = [8, 3, 1, 0, 640, 360, 150, 150, 0, 0, 60, false, 0]
				
				point = Game_Interpreter.prototype.picturePoint.call(null, params);
				
				$gameScreen.movePicture(
					params[0], params[2], point.x, point.y, params[6], params[7],
					params[8], params[9], params[10], params[12] || 0
				);
				if (params[11]) {
					thisTurn.wait(params[10]);
				}
	}
	
};


BulletHell.prototype.deleteBlackBars = function (condition) {
	
	if (condition) {
				params = [8, "CutsceneBlacksBars", 1, 1, 640, 360, 150, 150, 0, 0]
				
				point = Game_Interpreter.prototype.picturePoint.call(null, params);
				// prettier-ignore
				$gameScreen.showPicture(
					params[0], params[1], params[2], point.x, point.y,
					params[6], params[7], params[8], params[9]
				);
				$gameScreen.erasePicture(8);
	}
	
};


BulletHell.prototype.createFlash = function (type = 0) {
	
	switch (type) {
		
		case 0:
			AudioManager.playSe({name: 'Damage4', pan: 0, pitch: 150, volume: 90});
			$gameScreen.startFlash([255, 255, 255, 221], 20);
			break;
			
	}
	
	return 0;
	
};


BulletHell.prototype.onHitPlatform = function (obj) {
	
	if (this.player.lastY + 50 <= obj.pos.y-this.bhmaxheight/2 && this.player.lastY < this.player.pos.y) {
		this.player.pos.y = obj.pos.y-this.bhmaxheight/2-51;
		
		this.scenes.forEach(function(item) {
			
			item.soulGravity = 0;
			item.soulJumpPower = 0;
			
		})
		this.player.pos.x += obj.speed * obj.direction.x;
	}
	
};


//-----------------------------------------------------------------------------
// BulletHellScene
//
// The class of the Bullet Hell scenes (a sort of custom engine.).


BulletHellScene.prototype.swapSoul = function(type) {
	
	
	type = type || "none"
	
	AudioManager.playSe({name: 'ppg_soulchange', pan: 0, pitch: 100, volume: 100});
	
	if (type == "none") {
		
		type = this.isBlueSoul ? "yellow" : "blue";
		
	}
	
	if (type == "blue") {
		
		this.isBlueSoul = true;
		
	} else {
		
		this.isBlueSoul = false;
		this.soulGravity = 0;
		this.soulJumpPower = 0;
		
	}
	
};