module.exports = {
		
    name: 'PPG Battle',
	id: 1,


load (thisTurn, scene, parameters) {
	
	if (typeof scene.ppg_attackPaternID === 'undefined') {
		
		scene.ended = false;
		scene.ppg_attackPaternID = 0;
		scene.ppg_currentSubject = null;
		scene.ppg_lastdialogue = 0;
		scene.active = false;
		
		scene.isBlueSoul = false;
		scene.soulHasJump = false;
		scene.soulGravity = 0;
		scene.soulJumpPower = 0;
		scene.soulDirection = 8;
		scene.tempAniSpeed = 0;
		scene.karmaMode = true;
		
		this.movementsActive = false;
		
	}
	
	scene.ppg_attackPaternWillChange = scene.ppg_attackPaternWillChange || 0;
	
	
	
	let bgImage = "ppg_attackbg";
	
	if (parameters.skillParam > 0 ) {
	
		scene.ppg_attackPaternID = parameters.skillParam;
		bgImage = "ppg_attackbgonly";
	
	}
	
	if (!scene.tempAniSpeed) {
		scene.tempAniSpeed = ConfigManager["battleAniSpeed"]
	}
	ConfigManager["battleAniSpeed"] = 0


	if (scene.ppg_attackPaternID == 15 && scene.ppg_attackPaternWillChange == 1 && !$gameMessage.isBusy()) {
		
		scene.ppg_lastdialogue += 1;
		
	}

	if (scene.ppg_attackPaternID == 15 && scene.ppg_attackPaternWillChange == 1 && scene.ppg_lastdialogue == 1) {
		AudioManager.playBgm({name: null, pan: 0, pitch: 100, volume: 100});
		$gameMessage.setFaceImage("Oujnish7", 6);
		$gameMessage.setSpeakerName("Paper Professeur Genos");
		$gameMessage.add("It's not over yet kid !");
	}
	
	if (scene.ppg_attackPaternID == 15 && scene.ppg_attackPaternWillChange == 1 && scene.ppg_lastdialogue == 2) {
		$gameMessage.setFaceImage("Oujnish7", 6);
		$gameMessage.setSpeakerName("Paper Professeur Genos");
		$gameMessage.add("You ascended beyond our control, I shall");
		$gameMessage.add("demolish all of you.");
	}
	
	if (scene.ppg_attackPaternID == 15 && scene.ppg_attackPaternWillChange == 1 && scene.ppg_lastdialogue == 3) {
		$gameMessage.setFaceImage("Oujnish7", 6);
		$gameMessage.setSpeakerName("Paper Professeur Genos");
		$gameMessage.add("");
		$gameMessage.add("\\n\\{Y o u   g o n n a   g o   t o   h e l l .");
	}
	
	if (!$gameMessage.isBusy()) {
		
		// Do the actions
		if (!scene.active) {
			
			this.hitSFX = {name: 'ppg_soulhit', pan: 0, pitch: 100, volume: 120};
			this.active = true;
			
			if ((scene.ppg_attackPaternWillChange == 1 && scene.ppg_attackPaternID == 15) || scene.ppg_attackPaternID != 15) {
			
			if (scene.ppg_attackPaternID == 15) {
				
				AudioManager.playBgm({name: "stained-brutal-genophobia", pan: 0, pitch: 100, volume: 100});
				thisTurn._subject.dodgeCancelled = true;
				
			}
			
			scene.ppg_lastdialogue = 0;
			scene.soulDirection = 8;
			this.player.shotDelay = 2;
			this.player.collisionRect.x1 = 10;
			this.player.collisionRect.x2 = 24;
			this.player.collisionRect.y1 = 37;
			this.player.collisionRect.y2 = 52;
			$gameSwitches.setValue(514, false);
			
			AudioManager.playSe({name: 'ppg_noise', pan: 0, pitch: 100, volume: 100});
			
			this.objects = [];

			params = [2, bgImage, 0, 0, -320+($gameBulletHell.screenw-1280)/2, -180+($gameBulletHell.screenh-720)/2, 100, 100, 255, 0]
			
			let point = Game_Interpreter.prototype.picturePoint.call(null, params);
			// prettier-ignore
			$gameScreen.showPicture(
				params[0], params[1], params[2], point.x, point.y,
				params[6], params[7], params[8], params[9]
			);
			
			
			scene.active = true;
			this.showPictureBellow = true;
			const subject = thisTurn._subject;
			const action = subject.currentAction();
			
			let ppg_attackPaternDuration = [1000,1250,2000,1000,1250,10000,2000,2000,1500,15000,1250,20000,2200,2000,0,10000,1250]

				
			//_______________ ATTACK PATERN _____________________________

				if (scene.ppg_attackPaternID != 14) {
					
					ppg_attack15_timer = 0;
					
					args = {};
					args.posx = 0;args.posy = 0;args.offsetx = 0;args.offsety = 0;args.width = 0;args.height = 0;args.speed = 0;args.direction = 0;args.directioniscircle = "false";args.sprite = "null";args.candie = "true";args.canbetouched = "false";args.isPlayerShot = "false";args.isBonus = "false";
					
					args.name = "ppg_atk";
					args.hp = ppg_attackPaternDuration[scene.ppg_attackPaternID];
					args.action = 51 + scene.ppg_attackPaternID;
					args.deathaction = 50;
					args.scene = scene;
					
					Math.seedrandom('PPG_Seed' + scene.ppg_attackPaternID.toString())
					args.anchorAligned = false;
					this.createBHObject(args)
					
				} else {
					
					ppg_attack15_timer = 3000;
					
				}


			//___________________________________________________________	

			if (scene.ppg_attackPaternID == 999) {
				
				for (k = 0;k < 21; k++) {
					
					args = {};
					args.posx = 0;args.posy = 0;args.offsetx = 0;args.offsety = 0;args.width = 0;args.height = 0;args.speed = 0;args.direction = 0;args.directioniscircle = "false";args.sprite = "null";args.candie = "true";args.canbetouched = "false";args.isPlayerShot = "false";args.isBonus = "false";
					
					args.name = "ppg_atk";
					args.hp = ppg_attackPaternDuration[k];
					args.action = 51 + k;
					args.deathaction = 50;
					args.scene = scene;
					args.anchorAligned = false;
					
					this.createBHObject(args)
					
				}
				
			}
			
			} else {
				
				this.player.collisionRect.x1 = 0;
				this.player.collisionRect.x2 = 0;
				this.player.collisionRect.y1 = 0;
				this.player.collisionRect.y2 = 0;
				this.player.pos.x = -50;
				$gameScreen.erasePicture(2);
				$gameScreen.erasePicture(4);
				this.clearSpinningAttack();
				scene.active = false;
				thisTurn.endAction();
				thisTurn._subject = null;
				bhobjects = {object: new Array(0)};
				
			}

			if (scene.ppg_attackPaternWillChange == 1) {
				scene.ppg_attackPaternID += 1;
			}
			scene.ppg_attackPaternWillChange = 0;

		}
		
		
		let lastx = this.player.pos.x;
		let lasty = this.player.pos.y;
		
		this.player.canShot = !scene.isBlueSoul;
		this.player.shotType = scene.soulDirection;
		
		
		if (ppg_attack15_timer > 0 && ppg_attack15_timer % 600 == 0) {
			
			let attack15pattern = [4,2,8,7,14]
			
			this.clearSpinningAttack();
			
			this.player.collisionRect.x1 = 10;
			this.player.collisionRect.x2 = 24;
			this.player.collisionRect.y1 = 37;
			this.player.collisionRect.y2 = 52;
			
			AudioManager.playSe({name: 'ppg_noise', pan: 0, pitch: 100, volume: 100});
			this.objects = [];
			
			
			params = [2, bgImage, 0, 0, -320+($gameBulletHell.screenw-1280)/2, -180+($gameBulletHell.screenh-720)/2, 100, 100, 255, 0]
			
			point = Game_Interpreter.prototype.picturePoint.call(null, params);
			// prettier-ignore
			$gameScreen.showPicture(
				params[0], params[1], params[2], point.x, point.y,
				params[6], params[7], params[8], params[9]
			);
			
			
			
					args = {};
					args.posx = 0;args.posy = 0;args.offsetx = 0;args.offsety = 0;args.width = 0;args.height = 0;args.speed = 0;args.direction = 0;args.directioniscircle = "false";args.sprite = "null";args.candie = "true";args.canbetouched = "false";args.isPlayerShot = "false";args.isBonus = "false";
					
					args.name = "ppg_atk";
					args.hp = 1200;
					args.action = 51 + attack15pattern[5 - (ppg_attack15_timer/600)];
					args.deathaction = 50;
					args.scene = scene;
					
					args.anchorAligned = false;
					this.createBHObject(args)
			
		}
		
		ppg_attack15_timer -= 1;
		
		let gravModifier = 1;
		
		if (scene.isBlueSoul) {
			
			scene.soulGravity -= 0.25*gravModifier;
		}
		

			
			if ((BulletHellInput.isPressed("bh-Up") || BulletHellInput.isPressed("bh-Shot") || TouchInput.isPressed()) && scene.isBlueSoul && ((scene.soulJumpPower > 0 && scene.soulHasJump) || ((scene.soulJumpPower == 0 && Math.abs(scene.soulGravity) < 0.5) && !scene.soulHasJump))) {
				
				scene.soulHasJump = 1;
				
				scene.soulJumpPower = (scene.soulJumpPower == 0) ? 3 : scene.soulJumpPower;
				
				scene.soulJumpPower += 0.5*gravModifier;
				if (scene.soulJumpPower > 10*gravModifier) {
					
					scene.soulJumpPower = 10*gravModifier;
					
				}
			}
				
		if (BulletHellInput.isPressed("bh-Up") && !scene.isBlueSoul) {
			
				if (BulletHellInput.isPressed("bh-Slow") || TouchInput.isRightPressed()) {
					
					this.player.pos.y -= 2;
					
				} else {
					
					this.player.pos.y -= 5;
					
				}
				
		}
		
		
		if (!BulletHellInput.isPressed("bh-Up") && !BulletHellInput.isPressed("bh-Shot") || TouchInput.isPressed()) {
			
			scene.soulHasJump = 0;
			
		}

		if (BulletHellInput.isPressed("bh-Down") && !scene.isBlueSoul) {
			
			if (BulletHellInput.isPressed("bh-Slow") || TouchInput.isRightPressed()) {
				
				this.player.pos.y += 2;
				
			} else {
				
				this.player.pos.y += 5;
				
			}
			
		}
		
		if (BulletHellInput.isPressed("bh-Left")) {
			
			if (BulletHellInput.isPressed("bh-Slow") || TouchInput.isRightPressed()) {
				
				this.player.pos.x -= 2;
				
			} else {
				
				this.player.pos.x -= 5;
				
			}
			
		}

		if (BulletHellInput.isPressed("bh-Right")) {
			
			if (BulletHellInput.isPressed("bh-Slow") || TouchInput.isRightPressed()) {
				
				this.player.pos.x += 2;
				
			} else {
				
				this.player.pos.x += 5;
				
			}
			
		}
		
		
		if (scene.isBlueSoul) {
			this.player.pos.y -= scene.soulGravity + scene.soulJumpPower;
		}
		
		
		if (this.player.pos.x < 452-9) {
			
			this.player.pos.x = 452-9;
			
		}
		
		if (this.player.pos.x > 1280-452-27) {
			
			this.player.pos.x = 1280-452-27;
			
		}
		
		if (this.player.pos.y < 84-29-5) {
			
			this.player.pos.y = 84-29-5;
			if (scene.isBlueSoul) {
				
				scene.soulGravity = 0;
				scene.soulJumpPower = 0;
				
			}
			
		}
		
		if (this.player.pos.y > 720-260-47-5) {
			
			this.player.pos.y = 720-260-47-5;
			
			if (scene.isBlueSoul) {
				
				scene.soulGravity = 0;
				scene.soulJumpPower = 0;
				
			}
			
		}
		
		
		
		
		/*if (BulletHellInput.isPressed("cancel") && BulletHellInput.isPressed("bh-Down") && this.player.shotDelay <= 0) {
			
			createSmallPlatform(Math.random()*1280 + this.bhmaxwidth/2, Math.random()*600 + 100, 1)
			this.player.shotDelay = 3;
			
		}
		
		if (BulletHellInput.isPressed("cancel") && BulletHellInput.isPressed("bh-Up") && this.player.shotDelay <= 0) {
			
			swapSoul()
			this.player.shotDelay = 30;
			
		}


		if (BulletHellInput.isPressed("cancel") && !BulletHellInput.isPressed("bh-Up") && this.player.shotDelay <= 0) {
			
			//createGasterBlaster(Math.random()*1280 + this.bhmaxwidth/2, Math.random()*720 + this.bhmaxheight/2, 20, 60)
			//createTopHatLetter(Math.random()*1280 + this.bhmaxwidth/2,20,60)
			//createTopHatBunny(Math.random()*300 + this.bhmaxheight/2,Math.floor(Math.random()*2),20,60)
			//createDoomFinalLaser(3,10000);
			//createInvertVortex(640,272,2,43,vorid)


			
			
			this.player.shotDelay = 20;
			
		}*/
		
		if ($gameSwitches.value(517) == true) {
			
			AudioManager.playSe({name: 'Damage4', pan: 0, pitch: 150, volume: 90});
			$gameScreen.startFlash([255, 255, 255, 221], 20);
			$gameSwitches.setValue(517, false);
			
		}
		
		
		
		
		if ($gameSwitches.value(514) == true) {
			
			playerIsHit(1)
			
		}
		
		this.player.sprite = this.loadImages(scene.isBlueSoul ? "ppg_soul_bluesoul" : `ppg_soul${scene.soulDirection}`);
		this.karmaMode = true;
		
		
		if (scene.ended) {
			this.player.collisionRect.x1 = 0;
			this.player.collisionRect.x2 = 0;
			this.player.collisionRect.y1 = 0;
			this.player.collisionRect.y2 = 0;
			this.player.pos.x = -50;
			$gameScreen.erasePicture(2);
			$gameScreen.erasePicture(4);
			this.clearSpinningAttack();
			AudioManager.playSe({name: 'ppg_noise', pan: 0, pitch: 100, volume: 100});
			scene.active = false;
			thisTurn.endAction();
			thisTurn._subject = null;
			$gameScreen.erasePicture(3);
			this.objects = [];
			ConfigManager["battleAniSpeed"] = scene.tempAniSpeed;
			scene.tempAniSpeed = 0;
			scene.ended = false;
			this.hitSFX = {name: 'Darkness6', pan: 0, pitch: 150, volume: 90};
		}
	}
}
}