//-----------------------------------------------------------------------------
// BulletHell
//
// The main class of the Bullet Hell Engine.


BulletHell.prototype.rotatePoint = Feather_Core.rotatePoint;


BulletHell.prototype.rotateRect = Feather_Core.rotateRect;


BulletHell.prototype.getDirectionToPosition = Feather_Core.getDirectionToPosition;


BulletHell.prototype.getDistanceBetweenPoints = Feather_Core.getDistanceBetweenPoints;


BulletHell.prototype.changeDir = function(value,index) {
	
	let direction = 0;
	
	direction = (Math.atan2(this.objects[index].direction.y,this.objects[index].direction.x) * 180 / Math.PI);

	if (direction < 0) {
		direction += 360;
	}
	
	direction += value;
	
	if (direction < 0) {
		direction += 360;
	}
	
	if (direction > 360) {
		direction -= 360;
	}
	
	this.objects[index].direction.x = Math.cos(direction *Math.PI/180);
	this.objects[index].direction.y = Math.sin(direction *Math.PI/180);
	
};


BulletHell.prototype.getDirectionToPlayer = function(index,offsetx,offsety) {
	
	let direction = 0;
	offsetx = offsetx || 0;
	offsety = offsety || 0;
	
	direction = (Math.atan2(
	this.objects[index].pos.y + offsety - this.bhmaxheight/2 + this.objects[index].height/2 - 
	(this.player.pos.y + this.player.collisionRect.y1 + (this.player.collisionRect.y2 - this.player.collisionRect.y1)/2), 
	this.objects[index].pos.x + offsetx - this.bhmaxwidth/2 + this.objects[index].width/2 - 
	(this.player.pos.x + this.player.collisionRect.x1 + (this.player.collisionRect.x2 - this.player.collisionRect.x1)/2)) * 180 / Math.PI)-180;
	
	if (direction < 0) {
		direction += 360;
	}
	return direction;
	
};


BulletHell.prototype.getDirectionOfObject = function(index) {
	
	let direction = 0;
	
	direction = (Math.atan2(this.objects[index].direction.y,this.objects[index].direction.x) * 180 / Math.PI);
	if (direction < 0) {
		direction += 360;
	}
	return direction;
	
};


BulletHell.prototype.getDistanceToPlayer = function(index) {
	
	let distance = Math.sqrt(Math.pow((this.player.pos.x-this.objects[index].pos.x),2) + Math.pow((this.player.pos.y-this.objects[index].pos.y),2))
	return distance;
	
};


function rectangleCollision(rect1,rect2) {
	
	if (rect1.x1 < rect2.x2 &&
	rect1.x2 > rect2.x1 &&
	rect1.y1 < rect2.y2 &&
	rect1.y2 > rect2.y1) {
		
		return true;
		
	}
	
};


function rectangleCollisionWithPoint(point,rect) {
	
	if (point.x > rect.x1 &&
	point.x < rect.x2 &&
	point.y > rect.y1 &&
	point.y < rect.y2) {
		
		return true;
		
	}
	
};