module.exports = {
		
    name: 'Beast Big Laser Bullet',
	id: 16,

    execute (index, _BH) {
		this.speed -= 0.05;


		if (this.speed <= 0) {
			
			this.hp = 0;
			
		}
    },
};