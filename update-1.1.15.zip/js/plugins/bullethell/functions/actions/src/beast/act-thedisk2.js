module.exports = {
		
    name: 'THE DISK2',
	id: 19,

    execute (index, _BH) {
		this.hp -= 1;
    },
};