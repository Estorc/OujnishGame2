module.exports = {
		
    name: 'Explosive Bullet Warning',
	id: 806,

    execute (index, _BH) {
		if (this.frame >= 9 && this.frametimer >= 2) {
			
				if (this.name == "ForcedSpeed") {
					_BH.createTFExplosiveBullet(this.pos.x+8,this.hp,25);
				} else {
					_BH.createTFExplosiveBullet(this.pos.x+8,5+Math.random()*10,25);
				}
				AudioManager.playSe({name: 'Fire1', pan: 0, pitch: 150, volume: 100});
				this.hp = 0;
			
		}
    },
};