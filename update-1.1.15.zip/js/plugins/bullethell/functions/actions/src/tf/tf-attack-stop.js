module.exports = {
		
    name: 'TF Attack Stop',
	id: 700,

    execute (index, _BH) {
		
			_BH.objects.map(item => item.name === "ppgPlatform" && item.destroy() & _BH.remove(item) || item);
			SceneManager._scene._statusWindow.visible = true;
			this.scene.ended = true;
			
    },
};