module.exports = {
		
    name: 'Crystal Star Pointer',
	id: 810,

    execute (index, _BH) {
		if(typeof this.begin === 'undefined') {

			this.x = 0;
			this.y = 0;
			this.originx = this.pos.x;
			this.originy = this.pos.y;
			this.begin = 0;
			
		}
		
		this.hp -= 1;
			
		this.direction.x = Math.cos(_BH.getDirectionToPosition(this.x,this.y,_BH.player.pos.x+9+_BH.bhmaxwidth/2,_BH.player.pos.y+34+_BH.bhmaxheight/2) *Math.PI/180);
		this.direction.y = Math.sin(_BH.getDirectionToPosition(this.x,this.y,_BH.player.pos.x+9+_BH.bhmaxwidth/2,_BH.player.pos.y+34+_BH.bhmaxheight/2) *Math.PI/180);
		
		this.direction.x = (this.x == _BH.player.pos.x+9+_BH.bhmaxheight/2) ? 0 : this.direction.x
		this.direction.y = (this.y == _BH.player.pos.y+34+_BH.bhmaxheight/2) ? 0 : this.direction.y
		
		if (_BH.getDistanceBetweenPoints(this.x,this.y,_BH.player.pos.x+9+_BH.bhmaxwidth/2,_BH.player.pos.y+34+_BH.bhmaxheight/2) <= this.speed) {
			
			this.x = _BH.player.pos.x+9+_BH.bhmaxwidth/2;
			this.y = _BH.player.pos.y+34+_BH.bhmaxheight/2;
			
		} else {
			
		this.x += this.pos.x;
		this.y += this.pos.y;
		
		}
		
		
		this.offset.x = Math.ceil(this.x);
		this.offset.y = Math.ceil(this.y);
		
		this.pos.x = 0;
		this.pos.y = 0;
		
		if (this.hp <= 150 && this.hp % 30 == 0 && this.hp != 0) {
			
			AudioManager.playSe({name: 'ppg_soulchange', pan: 0, pitch: 70, volume: 80});
			this.sprite = "null";
			
		} else if (this.hp % 10 == 0) {
			
				if (this.name.contains("LaytonMobile")) {
					this.sprite = _BH.loadImages('crystalStarCursorLeft');
				} else {
					this.sprite = _BH.loadImages('crystalStarCursor');
				}
			
		}
		
		if (this.hp <= 0) {
			
			AudioManager.playSe({name: 'Ice2', pan: 0, pitch: 100, volume: 200});
			
			for (n=0;n<80;n++) {
				
				if (this.name.contains("LaytonMobile")) {
					_BH.createPositionDirigedBullet(
					this.originx+1,
					this.originy+1,
					this.offset.x+1+(Math.random()*5-5/2),
					this.offset.y+1+(Math.random()*5-5/2),
					'WarudoBullet',16,16,10+Math.random()*4,0,0);
				} else {
					_BH.createPositionDirigedBullet(
					this.originx+1,
					this.originy+1,
					this.offset.x+1+(Math.random()*5-5/2),
					this.offset.y+1+(Math.random()*5-5/2),
					'WarudoBullet',16,16,2+Math.random()*5,0,0);
				}
				
			}
				let nbBullet = 10;
				for (let n = 0; n<nbBullet; n++) {
					args = {};
					args.name = "";
					args.posx = this.originx+1;
					args.posy = this.originy+1;
					args.width = 16;
					args.height = 16;
					args.speed = 3;
					args.direction = n*(360/nbBullet);
					args.directioniscircle = "true";
					args.sprite = 'WarudoBullet';
					args.hp = 0;
					args.candie = "false";
					args.canbetouched = "false";
					args.action = 0;
					args.deathaction = 0;
					args.isPlayerShot = "false";
					args.isBonus = "false";
					args.anchorAligned = false;
					_BH.createBHObject(args)
				}
				for (let n = 0; n<nbBullet; n++) {
					args = {};
					args.name = "";
					args.posx = this.originx+1;
					args.posy = this.originy+1;
					args.width = 16;
					args.height = 16;
					args.speed = 2.5;
					args.direction = n*(360/nbBullet)+(360/nbBullet)*(1/3);
					args.directioniscircle = "true";
					args.sprite = 'WarudoBullet';
					args.hp = 0;
					args.candie = "false";
					args.canbetouched = "false";
					args.action = 0;
					args.deathaction = 0;
					args.isPlayerShot = "false";
					args.isBonus = "false";
					args.anchorAligned = false;
					_BH.createBHObject(args)
				}
				for (let n = 0; n<nbBullet; n++) {
					args = {};
					args.name = "";
					args.posx = this.originx+1;
					args.posy = this.originy+1;
					args.width = 16;
					args.height = 16;
					args.speed = 2;
					args.direction = n*(360/nbBullet)+(360/nbBullet)*(2/3);
					args.directioniscircle = "true";
					args.sprite = 'WarudoBullet';
					args.hp = 0;
					args.candie = "false";
					args.canbetouched = "false";
					args.action = 0;
					args.deathaction = 0;
					args.isPlayerShot = "false";
					args.isBonus = "false";
					args.anchorAligned = false;
					_BH.createBHObject(args)
				}
			
		args = {};
		if (this.name.contains("LaytonMobile")) {
			args.name = "268";
		} else {
			args.name = "2468";
		}
		args.speed = 10;
		args.directioniscircle = "true";
		args.hp = 12;
		args.candie = "true";
		args.canbetouched = "false";
		args.deathaction = 808;
		args.isPlayerShot = "false";
		args.isBonus = "false";
		args.cantbeinstakill = "true";
		args.action = 42;
		args.sprite = 'forceFieldCore@3';
		args.offsetx = -16;
		args.offsety = -16;
		args.width = 16;
		args.height = 16;
		args.posx = this.originx+1;
		args.posy = this.originy+1;
		args.direction = _BH.getDirectionToPosition(this.originx+1,this.originy+1,this.offset.x+1,this.offset.y+1);
		args.anchorAligned = false;
		_BH.createBHObject(args)
			
		}
    },
};