module.exports = {
		
    name: 'Crystyl Opening',
	id: 803,

    execute (index, _BH) {
		
		if (typeof this.originalAngle === 'undefined') {
			
			this.originalAngle = this.angle;
			
		}
		
		
		if (this.angle >= this.originalAngle+45 && this.frametimer >= 2) {
			
				this.candie = true;
				this.hp = 0;
				
				args = {};
				args.name = "";
				args.speed = 10;
				args.directioniscircle = "false";
				args.hp = 0;
				args.candie = "false";
				args.canbetouched = "false";
				args.deathaction = 0;
				args.isPlayerShot = "false";
				args.isBonus = "false";
				args.cantbeinstakill = "true";
				args.action = 804;
				args.sprite = 'tf_crystylblaster';
				args.width = 1470*2;
				args.height = 26*2;
				args.anchorx = 0;
				args.offsety = 0;
				args.offsetx = 0;
				args.opacity = 1;
				args.scaley = 0;
				args.collision_scaley = "scale";
				args.posx = this.pos.x+35;
				args.posy = this.pos.y;
				args.angle = this.originalAngle;
				args.collision_angle = "angle";
				args.direction = this.getDirection();
				args.anchorAligned = false;
				_BH.createBHObject(args)
				
				
				args = {};
				args.name = "";
				args.speed = 10;
				args.directioniscircle = "false";
				args.hp = 0;
				args.candie = "false";
				args.canbetouched = "false";
				args.deathaction = 0;
				args.isPlayerShot = "false";
				args.isBonus = "false";
				args.cantbeinstakill = "true";
				args.action = 805;
				args.sprite = this.sprite.name;
				args.width = 70;
				args.height = 70;
				args.posx = this.pos.x;
				args.posy = this.pos.y;
				args.angle = this.angle;
				args.direction = this.getDirection();
				args.anchorAligned = false;
				_BH.createBHObject(args)
			
		} else {
			
			this.angle += 3;
			
		}
    },
};