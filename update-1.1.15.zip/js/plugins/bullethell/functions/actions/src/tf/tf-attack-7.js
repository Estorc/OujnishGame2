module.exports = {
		
    name: 'PPG Attack 7',
	id: 57,

    execute (index, _BH) {
			if(typeof this.begin === 'undefined') {

				_BH.player.pos.x = 640-36/2;
				_BH.player.pos.y = 500;
				this.scene.swapSoul("yellow");
				this.maxhp = this.hp;
				this.begin = 0;
				_BH.player.collisionRect.x1 = 17;
				_BH.player.collisionRect.x2 = 19;
				_BH.player.collisionRect.y1 = 42;
				_BH.player.collisionRect.y2 = 44;

				
			}
			
			
			if (this.hp % 120 == 0) {
				
				args = {};
				args.name = "";
				if (Math.random() < 0.25) {
					args.posx = _BH.bhmaxwidth/2-32;
					args.posy = _BH.bhmaxheight/2+Math.random()*720;
				} else if (Math.random() < 0.5) {
					args.posx = _BH.bhmaxwidth/2+Math.random()*1280;
					args.posy = _BH.bhmaxheight/2-32;
				} else if (Math.random() < 0.75) {
					args.posx = _BH.bhmaxwidth/2+1280;
					args.posy = _BH.bhmaxheight/2+Math.random()*720;
				} else {
					args.posx = _BH.bhmaxwidth/2+Math.random()*1280;
					args.posy = _BH.bhmaxheight/2+720;
				}
				args.width = 16;
				args.height = 16;
				args.speed = 1.5;
				args.direction = 0;
				args.directioniscircle = "false";
				args.sprite = 'ppg_bigbullet';
				args.hp = 10;
				args.candie = "true";
				args.canbetouched = "false";
				args.cantbeinstakill = "true";
				args.action = 45;
				args.deathaction = 44;
				args.isPlayerShot = "false";
				args.isBonus = "false";
				args.anchorAligned = false;
				
				_BH.createBHObject(args)

			}
			
			
			if (this.hp % 8 == 0) {
				
				args = {};
				args.name = "";
				args.posx = _BH.bhmaxwidth/2-16;
				args.posy = _BH.bhmaxheight/2+Math.random()*720;
				args.width = 16;
				args.height = 16;
				args.speed = 1.5;
				args.direction = 90;
				args.directioniscircle = "false";
				args.sprite = 'ppg_commonbullet';
				args.hp = 0;
				args.candie = "false";
				args.canbetouched = "false";
				args.action = 0;
				args.deathaction = 0;
				args.isPlayerShot = "false";
				args.isBonus = "false";
				args.anchorAligned = false;
				
				_BH.createBHObject(args)
				
				args.posx = _BH.bhmaxwidth/2+Math.random()*1280;
				args.posy = _BH.bhmaxheight/2-16;
				args.direction = 180;
				
				_BH.createBHObject(args)
				
			}
			
			this.hp -= 1;
    },
};