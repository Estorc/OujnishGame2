module.exports = {
		
    name: 'PPG Attack 1',
	id: 51,

    execute (index, _BH) {
			if(typeof this.begin === 'undefined') {

				_BH.player.pos.x = 1280/2-17;
				_BH.player.pos.y = 720/2-31;
				this.scene.swapSoul("blue");
				this.maxhp = this.hp;
				this.begin = 0;
				
			}
			
			this.hp -= 1;
			
			if (this.hp % 40 == 0 && this.hp < this.maxhp-200) {
			_BH.createGasterBlaster(336-96/2 + _BH.bhmaxwidth/2, 406 + _BH.bhmaxheight/2, 20, 60)
			_BH.createGasterBlaster(1280-336-96/2 + _BH.bhmaxwidth/2, 406 + _BH.bhmaxheight/2, 20, 60)
			}
			
			if (this.hp % 80 == 0) {
			_BH.createSmallPlatform(-32 + _BH.bhmaxwidth/2, 338 + _BH.bhmaxheight/2, 3)
			_BH.createSmallPlatform(-64 + _BH.bhmaxwidth/2, 338 + _BH.bhmaxheight/2, 3)
			/*this.createSmallPlatform(1280 + this.bhmaxwidth/2, 338 + this.bhmaxheight/2, 3)
			this.createSmallPlatform(1280 +32 + this.bhmaxwidth/2, 338 + this.bhmaxheight/2, 3)*/
			}
			
			
			if (this.hp % 240 == 0) {
			
			_BH.createTopHatLetter(1280 - 494 + _BH.bhmaxwidth/2,20,60)
			
			}
			else if (this.hp % 120 == 0) {
			_BH.createTopHatLetter(494 + _BH.bhmaxwidth/2,20,60)
			/*this.createSmallPlatform(1280 + this.bhmaxwidth/2, 338 + this.bhmaxheight/2, 3)
			this.createSmallPlatform(1280 +32 + this.bhmaxwidth/2, 338 + this.bhmaxheight/2, 3)*/
			}
    },
};