module.exports = {
		
    name: 'PPG Attack 3',
	id: 53,

    execute (index, _BH) {
		
			if (_BH.player.hasMove()) Math.random();
		
			if(typeof this.begin === 'undefined') {

				_BH.player.pos.x = 640-36/2;
				_BH.player.pos.y = 500;
				this.scene.swapSoul("blue");
				this.maxhp = this.hp;
				this.begin = 0;
				
				
				for (n = 2; n < 10; n++) {
					_BH.createSmallPlatform(-4+_BH.bhmaxwidth/2+452+32*n, 460-70 + _BH.bhmaxheight/2, 0)
				}
				
			}

			
			this.hp -= 1;
			
			if (this.hp % 120 == 0) {
				AudioManager.playSe({name: 'Raise3', pan: 0, pitch: 150, volume: 80});
				
				args = {};
				args.name = "";
				args.speed = 0;
				args.directioniscircle = "false";
				args.hp = 1;
				args.candie = "true";
				args.canbetouched = "false";
				args.deathaction = 0;
				args.isPlayerShot = "false";
				args.isBonus = "false";
				args.cantbeinstakill = "true";
				args.action = 40;
				args.sprite = 'ppg_explosivebulletWarning@10@3';
				args.width = 0;
				args.height = 0;
				args.posx = _BH.bhmaxwidth/2+452+Math.random()*376-32;
				args.posy = 0;
				args.offsety = 84+_BH.bhmaxheight/2;
				args.direction = 0;
				args.anchorAligned = false;
				_BH.createBHObject(args)
			}
    },
};