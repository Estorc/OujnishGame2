module.exports = {
		
    name: 'PPG Attack 6',
	id: 56,

    execute (index, _BH) {
			if(typeof this.begin === 'undefined') {
				_BH.player.pos.x = 640-36/2;
				_BH.player.pos.y = 500;
				this.scene.swapSoul("yellow");
				this.maxhp = this.hp;
				this.begin = 0;
				_BH.createCrystalStar(_BH.bhmaxwidth/2+640-43,_BH.bhmaxheight/2-87,100)

				
			}
			
			
			if (!_BH.getObjectByName("CrystalStar")) {
				_BH.player.pos.y = -9000-47-5;
			
				if (this.hp > 30) {
					this.hp = 30;
				}
				
			}
			
			this.hp -= 1;
    },
};