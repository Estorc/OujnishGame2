module.exports = {
		
    name: 'Crystal Star',
	id: 43,

    execute (index, _BH) {
		if(typeof this.begin === 'undefined') {
			this.timer = 0; 
			this.btimer = 0;
			this.maxhp = this.hp;
			this.animt = 0; 
			this.animy = this.pos.y;
			this.begin = 0;
		}
		
		
		if (this.hp <= 0) {
						
			if (this.btimer == 0) {
			
				_BH.removeObjectByName(`${this.name + this.pos.x}`);
				
			}
			
			this.scale.x = 1 + this.btimer/30
			this.scale.y = 1 + this.btimer/30
			
					args = {};
					args.name = "";
					args.posx = this.pos.x;
					args.posy = this.pos.y;
					args.width = 0;
					args.height = 0;
					args.speed = 0;
					args.direction = 0;
					args.directioniscircle = "true";
					args.sprite = 'crystalStar';
					args.hp = 1;
					args.candie = "true";
					args.canbetouched = "true";
					args.action = 1;
					args.deathaction = 0;
					args.isPlayerShot = "false";
					args.scalex = this.scale.x + (this.btimer % 10)/10;
					args.scaley = this.scale.y + (this.btimer % 10)/10;
					args.opacity = 255-((this.btimer % 10)/10)*255
					args.isBonus = "false";
					args.anchorAligned = false;
					_BH.createBHObject(args)
			
						
			if (this.btimer % 10 == 0) {
				
				AudioManager.playSe({name: 'ppg_soulchange', pan: 0, pitch: 30, volume: 150});
				
			}
			this.btimer += 1;
						
			if (this.btimer >= 70) {
				AudioManager.playSe({name: 'Earth4', pan: 0, pitch: 150, volume: 200});
				AudioManager.playSe({name: 'Fire2', pan: 0, pitch: 100, volume: 200});
				for (n = 0; n<100; n++) {
					
					args = {};
					args.name = "";
					args.posx = this.pos.x + 43-8;
					args.posy = this.pos.y + 43-8;
					args.width = 16;
					args.height = 16;
					args.speed = 2+Math.random()*5;
					args.direction = Math.random()*360;
					args.directioniscircle = "true";
					args.sprite = 'ppg_commonbullet';
					args.hp = 0;
					args.candie = "false";
					args.canbetouched = "false";
					args.action = 0;
					args.deathaction = 0;
					args.isPlayerShot = "false";
					args.isBonus = "false";
					args.anchorAligned = false;
					_BH.createBHObject(args)
					
				}
				
				this.candie = true;
			}
			return 0;
			
		}
			
		
		if (this.animt <= 60) {
			this.animt += 1;
			this.pos.y = _BH.easeOutSine(this.animt,this.animy,272+44,60);
		} else {
			
			if (this.timer % 360 == 0) {
			
				_BH.createHeartPointer(_BH.bhmaxwidth/2+640-9,_BH.bhmaxwidth/2+272-9,3,360,`${this.name + this.pos.x}`);
				
			}
			
			this.timer += 1;
			
		}
		
    },
};