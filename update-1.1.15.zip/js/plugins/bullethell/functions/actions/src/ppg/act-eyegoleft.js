module.exports = {
		
    name: 'EyeGoLeft',
	id: 70,

    execute (index, _BH) {
		if(typeof this.begin === 'undefined') {

			this.begin = 0;
			this.timer = 0;
			this.originx = this.pos.x;
			this.originy = this.pos.y;
			
		}
		if (this.timer == 12) {
			
			this.sprite = _BH.loadImages('Phantasmal_Sphere@2@5');
			
		}
		
		if (this.name == "FinalRotate") {
			
			_BH.changeDir(-this.hp,index)
			this.pos.x = this.originx;
			this.pos.y = this.originy;
			this.speed = this.timer;
			this.pos.x += _BH.objects[i].speed*this.direction.x
			this.pos.y += _BH.objects[i].speed*this.direction.y
			this.speed = 0;
			
		} else {
		
			if (!(this.name == "RotateLock" && (this.timer * this.hp) > 180)) {
				_BH.changeDir(-this.hp,index)
			}
		
		}
		this.opacity -= 0.3;
		if (this.scale.x < 1) {
			this.scale.x += 0.05;
			this.scale.y += 0.05;
		}
		this.timer += 1;
    },
};