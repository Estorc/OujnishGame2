module.exports = {
		
    name: 'PPG Attack 8',
	id: 58,

    execute (index, _BH) {
				
			if (_BH.player.hasMove()) Math.random();

			if(typeof this.begin === 'undefined') {

				_BH.player.pos.x = 640-36/2;
				_BH.player.pos.y = 500;
				this.scene.swapSoul("yellow");
				this.maxhp = this.hp;
				this.begin = 0;
				_BH.player.collisionRect.x1 = 17;
				_BH.player.collisionRect.x2 = 19;
				_BH.player.collisionRect.y1 = 42;
				_BH.player.collisionRect.y2 = 44;
				this.hammer = [];
				
			}
			
			if (this.hp > this.maxhp-50 && this.hp % 4 == 0) {
				
				AudioManager.playSe({name: 'ppg_soulchange', pan: 0, pitch: 100, volume: 70});
				if ($gameScreen.picture(2)._name != "ppg_attackbgorange") {
					
					$gameScreen.picture(2)._name = "ppg_attackbgorange";
					
				} else {
					
					$gameScreen.picture(2)._name = "ppg_attackbgblue";
					
				}
				
			}
	
			if (this.hp == this.maxhp-50) {
				
				AudioManager.playSe({name: 'ppg_soulchange', pan: 0, pitch: 100, volume: 70});
				$gameScreen.picture(2)._name = "ppg_attackbg";
				
			}
			
			if (this.hp == this.maxhp-100) {
				
				$gameScreen.picture(2)._name = "ppg_attackbg";
				this.hammer[0] = _BH.createGiantHammer(4,this.maxhp,200,272,90,20)
				
			}
			
			if (this.hp == this.maxhp-145) {
				
				this.hammer[1] = _BH.createGiantHammer(-4,this.maxhp,1280-200,272,90,21)
				
			}


			if (typeof this.hammer[0] !== 'undefined' && typeof this.hammer[0].angle !== 'undefined' && typeof this.hammer[1] !== 'undefined' && typeof this.hammer[1].angle !== 'undefined' &&(
			this.hammer[0].angle - Math.floor(this.hammer[0].angle/360)*360 == 270+48 || 
				 this.hammer[1].angle - Math.floor(this.hammer[1].angle/360)*360 == 270-48 )) {
				
				AudioManager.playSe({name: 'Wind1', pan: 0, pitch: 50, volume: 70});
				
			}
			
			if (typeof this.hammer[0] !== 'undefined' && typeof this.hammer[0].angle !== 'undefined' &&(
			this.hammer[0].angle - Math.floor(this.hammer[0].angle/360)*360 == 270-96)) {
				
				AudioManager.playSe({name: 'ppg_soulchange', pan: 0, pitch: 100, volume: 70});
				
				if (Math.random() > 0.5) {
					this.hammer[0].sprite = _BH.loadImages("ppg_hammerorange");
					$gameScreen.picture(2)._name = "ppg_attackbgorange";
				} else {
					this.hammer[0].sprite = _BH.loadImages("ppg_hammerblue");
					$gameScreen.picture(2)._name = "ppg_attackbgblue";
				}
				
			}
			
			if (typeof this.hammer[1] !== 'undefined' && typeof this.hammer[1].angle !== 'undefined' &&(
			this.hammer[1].angle - Math.floor(this.hammer[1].angle/360)*360 == 6)) {
				
				AudioManager.playSe({name: 'ppg_soulchange', pan: 0, pitch: 100, volume: 70});
				
				if (Math.random() > 0.5) {
					this.hammer[1].sprite = _BH.loadImages("ppg_hammerorange");
					$gameScreen.picture(2)._name = "ppg_attackbgorange";
				} else {
					this.hammer[1].sprite = _BH.loadImages("ppg_hammerblue");
					$gameScreen.picture(2)._name = "ppg_attackbgblue";
				}
				
			}

			
			this.hp -= 1;
    },
};