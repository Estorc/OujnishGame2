module.exports = {
		
    name: 'KK Attack 1',
	id: 4201,

    execute (index, _BH) {
			if(typeof this.begin === 'undefined') {

				this.scene.swapSoul("yellow");
				this.maxhp = this.hp;
				_BH.player.pos.x = 640-36/2;
				_BH.player.pos.y = 272;
				this.begin = 0;
				
			}
			
			this.hp -= 1;

			if (this.hp % 25 == 0) {
				
			let angle = Math.random()*2*Math.PI;
			let x = 640-35 + Math.cos(angle)*350 + _BH.bhmaxwidth/2
			let y = 272-35 + Math.sin(angle)*350 + _BH.bhmaxheight/2
			_BH.createRotGasterBlaster(x, y, 20, 60, 
			_BH.getDirectionToPosition(x+96/2,y+96/2,_BH.player.pos.x+18+_BH.bhmaxwidth/2,_BH.player.pos.y+43+_BH.bhmaxheight/2));
			}


    },
};