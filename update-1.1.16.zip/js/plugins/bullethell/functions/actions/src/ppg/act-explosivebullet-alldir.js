module.exports = {
		
    name: 'Explosive Bullet All Direction',
	id: 42,

    execute (index, _BH) {
		this.explodePower = this.hp;

		if (this.pos.y-_BH.bhmaxheight/2+16 >=460 && this.name.contains("2")) {
			
			this.pos.y = 460+_BH.bhmaxheight/2-16;
			this.hp = 0;
			
		}
		if (this.pos.x-_BH.bhmaxwidth/2+16 >=828 && this.name.contains("6")) {
			
			this.pos.x = 828+_BH.bhmaxwidth/2-16;
			this.hp = 0;
			
		}
		if (this.pos.x-_BH.bhmaxwidth/2+16 <=452 && this.name.contains("4")) {
			
			this.pos.x = 452+_BH.bhmaxwidth/2+16;
			this.hp = 0;
			
		}
		if (this.pos.y-_BH.bhmaxheight/2+16 <=84 && this.name.contains("8")) {
			
			this.pos.y = 84+_BH.bhmaxheight/2+16;
			this.hp = 0;
			
		} 
		if (typeof this.collideWithPlayer !== 'undefined' && this.collideWithPlayer == 1) {
			
				this.hp = 0;
			
		}
    },
};