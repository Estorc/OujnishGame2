module.exports = {
		
    name: 'PPG Attack 5',
	id: 55,

    execute (index, _BH) {
		
			if (_BH.player.hasMove()) Math.random();

			if(typeof this.begin === 'undefined') {

				_BH.player.pos.x = 640-36/2;
				_BH.player.pos.y = 500;
				this.scene.swapSoul("blue");
				this.maxhp = this.hp;
				this.begin = 0;
				
			}
			
			
			if (this.hp % 40 == 0) {
			_BH.createSmallPlatform(-32 + _BH.bhmaxwidth/2, 338 + _BH.bhmaxheight/2, 3)
			_BH.createSmallPlatform(-64 + _BH.bhmaxwidth/2, 338 + _BH.bhmaxheight/2, 3)
			_BH.createSmallPlatform(1280 + _BH.bhmaxwidth/2, 200 + _BH.bhmaxheight/2, 3)
			_BH.createSmallPlatform(1280+32 + _BH.bhmaxwidth/2, 200 + _BH.bhmaxheight/2, 3)
			}
			
			if (this.hp % 60 == 0 && this.hp < this.maxhp-200) {
			let randomy = Math.floor(Math.random()*3);
			_BH.createGasterBlaster(1280-336-96/2 + _BH.bhmaxwidth/2, 406 + _BH.bhmaxheight/2-(138*randomy), 20, 60)
			_BH.createGasterBlaster(1280-336-96/2 + _BH.bhmaxwidth/2, 406-64 + _BH.bhmaxheight/2-(138*randomy), 20, 60)
			}

			
			this.hp -= 1;
    },
};