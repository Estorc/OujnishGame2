module.exports = {
		
    name: 'TF Attack 1',
	id: 701,

    execute (index, _BH) {
			if(typeof this.begin === 'undefined') {

				this.scene.swapSoul("blue");
				this.maxhp = this.hp;
				this.begin = 0;
				
			}
			
			this.hp -= 1;
			
			if (this.hp % 40 == 0 && this.hp < this.maxhp-200) {
			_BH.createTFBlaster(336-96/2 + _BH.bhmaxwidth/2, 406 + _BH.bhmaxheight/2, 20, 60, 0)
			_BH.createTFBlaster(1280-336-96/2 + _BH.bhmaxwidth/2, 406 + _BH.bhmaxheight/2, 20, 60, 180)
			}
			
			if (this.hp % 80 == 0) {
			_BH.createTFPlatform(-32 + _BH.bhmaxwidth/2, 338 + _BH.bhmaxheight/2, 3)
			_BH.createTFPlatform(-64 + _BH.bhmaxwidth/2, 338 + _BH.bhmaxheight/2, 3)
			/*this.createSmallPlatform(1280 + this.bhmaxwidth/2, 338 + this.bhmaxheight/2, 3)
			this.createSmallPlatform(1280 +32 + this.bhmaxwidth/2, 338 + this.bhmaxheight/2, 3)*/
			}
			
			
			if (this.hp % 240 == 0) {
			
			_BH.createFedofTopHat(1280 - 494 + _BH.bhmaxwidth/2,20,60)
			
			}
			else if (this.hp % 120 == 0) {
			_BH.createFedofTopHat(494 + _BH.bhmaxwidth/2,20,60)
			/*this.createSmallPlatform(1280 + this.bhmaxwidth/2, 338 + this.bhmaxheight/2, 3)
			this.createSmallPlatform(1280 +32 + this.bhmaxwidth/2, 338 + this.bhmaxheight/2, 3)*/
			}
    },
};