module.exports = {
		
    name: 'TF Attack 5',
	id: 705,

    execute (index, _BH) {
			if(typeof this.begin === 'undefined') {

				_BH.player.pos.x = 640-36/2;
				_BH.player.pos.y = 500;
				this.scene.swapSoul("yellow");
				this.maxhp = this.hp;
				this.begin = 0;
				_BH.createTFCrystalStar(_BH.bhmaxwidth/2+640-43,_BH.bhmaxheight/2-87,100)

				
			}
			
			
			if (!_BH.getObjectByName("CrystalStar") && this.hp > 30) {
				
				this.hp = 30;
				
			}
			
			this.hp -= 1;
    },
};