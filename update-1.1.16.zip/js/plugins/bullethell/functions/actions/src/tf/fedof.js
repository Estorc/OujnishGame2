module.exports = {
		
    name: 'Fedof',
	id: 750,

    execute (index, _BH) {
		if(typeof this.begin === 'undefined') {

			this.begin = 0;
			
		}
		
		if (this.direction.x > 0) {
			
			this.sprite = _BH.loadImages('FedofRight@4@7');
			_BH.collisionSprite = null;
			this.offset.x = -32;
			
		} else if (this.direction.x < 0) {
			
			this.sprite = _BH.loadImages('Fedof@4@7'); 
			_BH.collisionSprite = null;
			this.offset.x = -15;
			
		}
    },
};