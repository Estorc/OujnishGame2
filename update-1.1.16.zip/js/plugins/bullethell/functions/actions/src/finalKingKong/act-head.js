module.exports = {
		
    name: 'KK_Head',
	id: 1101,

    execute (index, _BH) {
		if(typeof this.begin === 'undefined') {

			this.begin = 0;
			this.timer = 0;
			this.originx = this.pos.x;
			this.originy = this.pos.y;
			this.stopTurning = false;
			
		}

		if (!this.stopTurning) {
			
			let x = this.pos.x+123
			let y = this.pos.y+82
			this.angle += ((_BH.getDirectionToPosition(x,y,_BH.player.pos.x+18+_BH.bhmaxwidth/2,_BH.player.pos.y+43+_BH.bhmaxheight/2)-90)-this.angle)/50;
			
		}
		
		
		if (_BH.objects[0].hp % 500 == 0) {
			
			AudioManager.playSe({name: 'Laser2', pan: 0, pitch: 100, volume: 200});
			
					args = {};
					args.name = "";
					args.posx = this.pos.x;
					args.posy = this.pos.y;
					args.width = 0;
					args.height = 0;
					args.speed = 0;
					args.direction = 0;
					args.directioniscircle = "false";
					args.sprite = 'KK-CannonLoading@8@8';
					args.hp = 0;
					args.candie = "false";
					args.canbetouched = "false";
					args.action = "KK_HeadLoading";
					args.deathaction = 0;
					args.isPlayerShot = "false";
					args.isBonus = "false";
					args.anchorAligned = false;
					let item = _BH.createBHObject(args)
					item.parent = this;
		}
		
		
		
	},
};