module.exports = {
		
    name: 'Eye Laser',
	id: 813,

    execute (index, _BH) {
		this.hp -= 1;

		this.opacity = Math.min(255,this.hp*(255/30));
		if (this.hp <= 30) {
			
			_BH.objects[_BH.getObjectByName(this.name.replace('Laser', ''))].action = BHactions.find(action => action.name == 'OTF_Eye').execute;
			this.collision = [{}];
			
		}
    },
};