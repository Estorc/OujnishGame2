module.exports = {
		
    name: 'KK_FinalCannonLaser',
	id: 1101,

    execute (index, _BH) {
		if(typeof this.begin === 'undefined') {

			AudioManager.playSe({name: 'ppg_gasterblaster', pan: 0, pitch: 50, volume: 100});
			AudioManager.playSe({name: 'ppg_gasterblasterlaser', pan: 0, pitch: 50, volume: 100});
			this.begin = 0;
			
		}
		this.angle = this.parent.angle+90;
		this.begin += 1;

		if (this.begin < 10) {
			
			this.scale.y += 1/10
			this.opacity += 255/10
			
		}
    },
};