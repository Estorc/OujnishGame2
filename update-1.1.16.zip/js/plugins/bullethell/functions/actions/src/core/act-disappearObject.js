module.exports = {
		
    name: 'Disappear Object',
	id: 299,

    execute (index, _BH) {
		if(typeof this.begin === 'undefined') {

			this.begin = 0;
			this.maxhp = this.hp;
			
		}
		
		this.hp -= 1;
		this.opacity = this.hp*(255/this.maxhp)
		
    },
};