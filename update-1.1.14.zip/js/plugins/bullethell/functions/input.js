//-----------------------------------------------------------------------------
// BulletHellInput
//
// The class of the Bullet Hell Inputs.


BulletHellInput = function() {
    throw new Error("This is a static class");
};


BulletHellInput.initialize = function() {		

	this.makeKeyMapper();
	this.clear();
	this._setupEventHandlers();

};


BulletHellInput.gamepadMapper = {
    0: 'bh-Shot', // A
    2: 'bh-Slow', // X
    12: 'bh-Up', // D-pad up
    13: 'bh-Down', // D-pad down
    14: 'bh-Left', // D-pad left
    15: 'bh-Right' // D-pad right
};


BulletHellInput.clear = function() {
    this._currentState = {};
	this._gamepadStates = [];
};


BulletHellInput.update = function() {	
	this._pollGamepads();
}


BulletHellInput._pollGamepads = function() {
    if (navigator.getGamepads) {
        const gamepads = navigator.getGamepads();
        if (gamepads) {
            for (const gamepad of gamepads) {
                if (gamepad && gamepad.connected) {
                    this._updateGamepadState(gamepad);
                }
            }
        }
    }
};


BulletHellInput._updateGamepadState = function(gamepad) {
    const lastState = this._gamepadStates[gamepad.index] || [];
    const newState = [];
    const buttons = gamepad.buttons;
    const axes = gamepad.axes;
    const threshold = 0.5;
    newState[12] = false;
    newState[13] = false;
    newState[14] = false;
    newState[15] = false;
    for (let i = 0; i < buttons.length; i++) {
        newState[i] = buttons[i].pressed;
    }
    if (axes[1] < -threshold) {
        newState[12] = true; // up
    } else if (axes[1] > threshold) {
        newState[13] = true; // down
    }
    if (axes[0] < -threshold) {
        newState[14] = true; // left
    } else if (axes[0] > threshold) {
        newState[15] = true; // right
    }
    for (let j = 0; j < newState.length; j++) {
        if (newState[j] !== lastState[j]) {
            const buttonName = this.gamepadMapper[j];
            if (buttonName) {
                this._currentState[buttonName] = newState[j];
            }
        }
    }
    this._gamepadStates[gamepad.index] = newState;
};


BulletHellInput.makeKeyMapper = function() {
	this.reversedKeyMapper = {
	'bh-Up':ConfigManager['FO_bh-Up'],
	'bh-Right':ConfigManager['FO_bh-Right'],
	'bh-Down':ConfigManager['FO_bh-Down'],
	'bh-Left':ConfigManager['FO_bh-Left'],
	'bh-Shot':ConfigManager['FO_bh-Shot'],
	'bh-Slow':ConfigManager['FO_bh-Slow']
	}
    this._currentState = {};
	this.keyMapper = {};
	for (const [symbol, keys] of Object.entries(this.reversedKeyMapper)) {
	  for (const key of keys) {
		BulletHellInput.keyMapper[key] = symbol;
	  }
	}
};


BulletHellInput._setupEventHandlers = function() {
    document.addEventListener("keydown", this._onKeyDown.bind(this));
	document.addEventListener("keyup", this._onKeyUp.bind(this));
	window.addEventListener("blur", this._onLostFocus.bind(this));
};


BulletHellInput._onKeyDown = function(event) {
    if (Input._shouldPreventDefault(event.keyCode)) {
        event.preventDefault();
    }
    if (event.keyCode === 144) {
        // Numlock
        this.clear();
    }
    const buttonName = this.keyMapper[event.keyCode];
    if (buttonName) {
        this._currentState[buttonName] = true;
    }
};


BulletHellInput._onKeyUp = function(event) {
    const buttonName = this.keyMapper[event.keyCode];
    if (buttonName) {
        this._currentState[buttonName] = false;
    }
};


BulletHellInput._onLostFocus = function() {
    this.clear();
};


BulletHellInput.isPressed = function(keyName) {
        return !!this._currentState[keyName];
};


//-----------------------------------------------------------------------------
// Input Config
//


Input.keyMapper[112] = 'collisionDebug';
ConfigManager['FO_bh-Up'] = [38,104];
ConfigManager['FO_bh-Right'] = [39,102];
ConfigManager['FO_bh-Down'] = [40,98];
ConfigManager['FO_bh-Left'] = [37,100];
ConfigManager['FO_bh-Shot'] = [90,32];
ConfigManager['FO_bh-Slow'] = [16,17];


//-----------------------------------------------------------------------------
// Classes Rewrite
//


___FeatherBH___ConfigManager_makeData = ConfigManager.makeData;
ConfigManager.makeData = function() {
	const config = ___FeatherBH___ConfigManager_makeData.call(this);
	config['FO_bh-Up'] = this['FO_bh-Up'];
	config['FO_bh-Down'] = this['FO_bh-Down'];
	config['FO_bh-Left'] = this['FO_bh-Left'];
	config['FO_bh-Right'] = this['FO_bh-Right'];
	config['FO_bh-Shot'] = this['FO_bh-Shot'];
	config['FO_bh-Slow'] = this['FO_bh-Slow'];
	return config;
};


___FeatherBH___ConfigManager_applyData = ConfigManager.applyData;
ConfigManager.applyData = function(config) {
	___FeatherBH___ConfigManager_applyData.call(this, config)
	this['FO_bh-Up'] = this.readKey(config, "FO_bh-Up");
	this['FO_bh-Right'] = this.readKey(config, "FO_bh-Right");
	this['FO_bh-Down'] = this.readKey(config, "FO_bh-Down");
	this['FO_bh-Left'] = this.readKey(config, "FO_bh-Left");
	this['FO_bh-Shot'] = this.readKey(config, "FO_bh-Shot");
	this['FO_bh-Slow'] = this.readKey(config, "FO_bh-Slow");
	BulletHellInput.makeKeyMapper();
};


ConfigManager.readKey = function(config, name) {
	if (name in config) {
		return config[name];
	} else {
		return ConfigManager[name]
	}
};


___FeatherBH___SceneManager_initInput = SceneManager.initInput;
SceneManager.initInput = function() {
    ___FeatherBH___SceneManager_initInput.call(this);
	BulletHellInput.initialize();
};


___FeatherBH___SceneManager_updateInputData = SceneManager.updateInputData;
SceneManager.updateInputData = function() {
    ___FeatherBH___SceneManager_updateInputData.call(this);
	BulletHellInput.update();
};