//-----------------------------------------------------------------------------
// BulletHell
//
// The main class of the Bullet Hell Engine.


BulletHell.prototype.doShot = function () {
	let item = {};
	switch (this.player.shotType) {
		case 0:
			AudioManager.playSe(this.shotSFX);
			
			item.name = "PlShot";
			item.posx = this.player.pos.x+14 + this.bhmaxwidth/2;
			item.posy = this.player.pos.y+8 + this.bhmaxheight/2;
			item.sprite = 'PlayerShot';
			item.width = 8;
			item.height = 16;
			item.speed = 8;
			item.offsetx = 0;
			item.offsety = 0;
			item.directioniscircle = "false";
			item.hp = 1;
			item.candie = "true";
			item.canbetouched = "false";
			item.action = 0;
			item.deathaction = 0;
			item.isPlayerShot = "true";
			item.isBonus = "false";
			args.anchorAligned = false;
					
			if (this.player.level >= 5) {
				

					item.direction = 0+30;
					item.angle = 30;
					this.createBHObject(item)
					item.direction = 0-30;
					item.angle = -30;
					this.createBHObject(item)
					item.angle = 0;
				
			}
			
			if (this.player.level >= 4) {
				
					item.direction = 0;
					item.posx -= 8;
					this.createBHObject(item)
					item.posx += 16;
					this.createBHObject(item)
				
			} else {
				item.direction = 0;
				this.createBHObject(item)
			}
			

			switch (this.player.level) {
				
				case 0:
					this.player.shotDelay = 10;
				break;
				case 1:
					this.player.shotDelay = 8;
				break;
				case 2:
					this.player.shotDelay = 5;
				break;
				default:
					this.player.shotDelay = 3;
				break;
			}
		
			break;
			
		case 2:
			AudioManager.playSe(this.shotSFX);
			
			item.name = "PlShot";

			item.posx = this.player.pos.x+14 + this.bhmaxwidth/2;
			item.posy = this.player.pos.y+16 + this.bhmaxheight/2;
			item.sprite = 'ppg_pshot';
			item.direction = 180;
			item.width = 8;
			item.height = 16;

			item.offsetx = 0;
			item.offsety = 0;
			item.speed = 8;
			item.directioniscircle = "false";
			item.hp = 1;
			item.candie = "true";
			item.canbetouched = "false";
			item.action = 0;
			item.deathaction = 0;
			item.isPlayerShot = "true";
			item.isBonus = "false";
			args.anchorAligned = false;
			this.createBHObject(item)
			
			this.player.shotDelay = 10;
			
			break;
			
			
		case 4:
			AudioManager.playSe(this.shotSFX);
			
			item.name = "PlShot";

			item.posx = this.player.pos.x-7 + this.bhmaxwidth/2;
			item.posy = this.player.pos.y+39 + this.bhmaxheight/2;
			item.sprite = 'ppg_leftpshot';
			item.direction = 270;
			item.width = 16;
			item.height = 8;

			item.offsetx = 0;
			item.offsety = 0;
			item.speed = 8;
			item.directioniscircle = "false";
			item.hp = 1;
			item.candie = "true";
			item.canbetouched = "false";
			item.action = 0;
			item.deathaction = 0;
			item.isPlayerShot = "true";
			item.isBonus = "false";
			args.anchorAligned = false;
			this.createBHObject(item)
			
			this.player.shotDelay = 10;
			
			break;
			
			
		case 8:
			AudioManager.playSe(this.shotSFX);
			
			item.name = "PlShot";

			item.posx = this.player.pos.x+14 + this.bhmaxwidth/2;
			item.posy = this.player.pos.y+16 + this.bhmaxheight/2;
			item.sprite = 'ppg_pshot';
			item.direction = 0;
			item.width = 8;
			item.height = 16;

			item.offsetx = 0;
			item.offsety = 0;
			item.speed = 8;
			item.directioniscircle = "false";
			item.hp = 1;
			item.candie = "true";
			item.canbetouched = "false";
			item.action = 0;
			item.deathaction = 0;
			item.isPlayerShot = "true";
			item.isBonus = "false";
			args.anchorAligned = false;
			this.createBHObject(item)
			
			this.player.shotDelay = 10;
			
			break;
			
			
	}
}