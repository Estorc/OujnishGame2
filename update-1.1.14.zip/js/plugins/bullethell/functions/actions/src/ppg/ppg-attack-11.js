module.exports = {
		
    name: 'PPG Attack 11',
	id: 61,

    execute (index, _BH) {
			if(typeof this.begin === 'undefined') {

				_BH.player.pos.x = 640-36/2;
				_BH.player.pos.y = 500;
				this.scene.swapSoul("yellow");
				this.maxhp = this.hp;
				this.begin = 0;
				_BH.player.collisionRect.x1 = 17;
				_BH.player.collisionRect.x2 = 19;
				_BH.player.collisionRect.y1 = 42;
				_BH.player.collisionRect.y2 = 44;
				this.hammer = [];
				
			}
			
			
			if (this.hp == this.maxhp-100) {
				
				this.hammer[0] = _BH.createGiantHammer(1.5,this.maxhp,120,272,270,20)
				this.hammer[1] = _BH.createGiantHammer(-1.5,this.maxhp,1280-120,272,90,21)
				
			}


			if (typeof this.hammer[0] !== 'undefined' && typeof this.hammer[0].angle !== 'undefined' &&(
			this.hammer[0].angle - Math.floor(this.hammer[0].angle/360)*360 == 270+45 || 
				 this.hammer[1].angle - Math.floor(this.hammer[1].angle/360)*360 == 270-45 )) {
				
				AudioManager.playSe({name: 'Wind1', pan: 0, pitch: 50, volume: 70});
				
			}

			
			this.hp -= 1;
			
			if (this.hp % 4 == 0) {
				let percent = (this.maxhp-this.hp)*6;
				while (percent > 100) {
					
					percent -= 100;
					
				}
				
				_BH.createInvertVortex(640,272,1.5,'ppg_commonbullet',percent);
			}
			
			if (this.hp % 4 == 0) {
				let percent = (this.maxhp-this.hp)*6;
				while (percent > 100) {
					
					percent -= 100;
					
				}
				
				_BH.createInvertVortex(640,272,1.5,'ppg_commonbullet',-percent);
			}
    },
};