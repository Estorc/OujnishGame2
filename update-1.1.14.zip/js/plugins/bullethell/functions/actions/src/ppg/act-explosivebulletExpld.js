module.exports = {
		
    name: 'Explosive Bullet Explosion',
	id: 39,

    execute (index, _BH) {
		AudioManager.playSe({name: 'Explosion4', pan: 0, pitch: 150, volume: 100});
		$gameScreen.startShake(5, 5, 10);
		
		
		let direction = (Math.atan2(this.direction.y,this.direction.x) * 180 / Math.PI)+90;
		
		
		for (n=0;n<this.explodePower;n++) {
			
			_BH.createGroundJumpingBullet(this.pos.x,this.pos.y,16,16,2+Math.random()*this.speed,direction-180 + 70-Math.random()*55,'ppg_commonbullet');
		}
		
		for (n=0;n<this.explodePower;n++) {
			
			_BH.createGroundJumpingBullet(this.pos.x,this.pos.y,16,16,2+Math.random()*this.speed,direction-180 + 290+Math.random()*55,'ppg_commonbullet');
		}
    },
};