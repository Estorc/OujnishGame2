module.exports = {
		
    name: 'Rot Gaster Blaster End',
	id: 955,

    execute (index, _BH) {
		if(typeof this.begin === 'undefined') {
					
				this.frame = 5;
				this.frametimer = 0;
		}
    },
};