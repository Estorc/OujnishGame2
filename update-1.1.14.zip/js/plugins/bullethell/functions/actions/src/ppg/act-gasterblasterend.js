module.exports = {
		
    name: 'Gaster Blaster End',
	id: 34,

    execute (index, _BH) {
		if(typeof this.begin === 'undefined') {
					
				this.frame = 5;
				this.frametimer = 0;
		}
    },
};