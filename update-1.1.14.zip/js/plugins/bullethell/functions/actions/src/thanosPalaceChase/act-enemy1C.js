module.exports = {
		
    name: 'Appear and Dispear Enemy 1 Type C',
	id: 9,

    execute (index, _BH) {
		if (this.pos.y > 500 && this.direction.y > 0) {
			
			if (this.pos.x < 640) {
				
				_BH.changeDir(1,index);
				
			} else {
				
				_BH.changeDir(-1,index);
				
			}
			
		}
		
		if (typeof this.timer === 'undefined') {
			this.timer = 0;
		}
		this.timer += 1;
		
		if (typeof this.timer !== 'undefined' && Number.isInteger(this.timer / 240)) {
			
			args = {};
			args.name = "";
			args.posx = this.pos.x + this.width/2 - 8;
			args.posy = this.pos.y + this.height/2 - 8;
			args.width = 16;
			args.height = 16;
			args.speed = 7;
			args.direction = _BH.getDirectionToPlayer(index);
			args.directioniscircle = "true";
			args.sprite = 'thanoscarbullet';
			args.hp = 0;
			args.candie = "false";
			args.canbetouched = "false";
			args.action = 0;
			args.deathaction = 0;
			args.isPlayerShot = "false";
			args.isBonus = "false";
			args.anchorAligned = false;
			_BH.createBHObject(args)
			
		}
    },
};