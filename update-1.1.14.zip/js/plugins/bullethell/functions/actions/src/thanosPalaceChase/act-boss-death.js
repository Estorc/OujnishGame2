module.exports = {
		
    name: 'Boss Death',
	id: 12,

    execute (index, _BH) {
		$gameVariables.setValue(96,0);
		this.candie = false;
    },
};