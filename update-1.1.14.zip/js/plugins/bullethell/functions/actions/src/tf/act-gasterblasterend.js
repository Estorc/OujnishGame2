module.exports = {
		
    name: 'Gaster Blaster End',
	id: 805,

    execute (index, _BH) {

    },
};