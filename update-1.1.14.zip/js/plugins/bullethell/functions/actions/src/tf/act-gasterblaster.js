module.exports = {
		
    name: 'Crystyl Blaster',
	id: 802,

    execute (index, _BH) {
		if(typeof this.begin === 'undefined') {
			

			AudioManager.playSe({name: 'Push', pan: 0, pitch: 100, volume: 100});
			this.sprite = _BH.loadImages('tf_crystyl');
			this.begin = 0;
			
		}

		this.speed /= 2;	
		if (this.speed < 1 && this.speed > 0)	 {
			
			this.speed = 0;
			this.pos.x = Math.ceil(this.pos.x);
			this.pos.y = Math.ceil(this.pos.y);
			
		}
		this.hp -= 1;

		if (this.hp == 0) {
			
				args = {};
				args.name = "";
				args.speed = 0;
				args.directioniscircle = "false";
				args.hp = 0;
				args.candie = "false";
				args.canbetouched = "false";
				args.deathaction = 0;
				args.isPlayerShot = "false";
				args.isBonus = "false";
				args.cantbeinstakill = "true";
				args.action = 803;
				args.sprite = 'tf_crystyl';
				args.width = 70;
				args.height = 70;
				args.posx = this.pos.x;
				args.posy = this.pos.y;
				args.angle = this.angle;
				let _direction = (Math.atan2(this.direction.y,this.direction.x) * 180 / Math.PI);
				if (_direction < 0) { _direction += 360; }
				args.direction = _direction;
				args.anchorAligned = false;
				_BH.createBHObject(args)
			
		}
    },
};