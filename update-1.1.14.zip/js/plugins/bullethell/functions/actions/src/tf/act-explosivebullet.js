module.exports = {
		
    name: 'Explosive Bullet',
	id: 807,

    execute (index, _BH) {
		this.explodePower = this.hp;

		if (this.pos.y-_BH.bhmaxheight/2+16 >=460) {
			
				this.pos.y = 460+_BH.bhmaxheight/2-16;
				this.hp = 0;
			
		} else if (typeof _BH.objects[i].collideWithPlayer !== 'undefined' && _BH.objects[i].collideWithPlayer == 1) {
			
				this.hp = 0;
			
		}
    },
};