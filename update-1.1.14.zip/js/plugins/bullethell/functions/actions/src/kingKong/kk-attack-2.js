module.exports = {
		
    name: 'KK Attack 2',
	id: 4202,

    execute (index, _BH) {
			if(typeof this.begin === 'undefined') {

				this.scene.swapSoul("yellow");
				this.maxhp = this.hp;
				_BH.player.pos.x = 640-18;
				_BH.player.pos.y = 272-43;
				this.begin = 0;
				this.bones = [[],[]];
				
			}


			if (this.hp == this.maxhp) {
			for (let i = 0; i<37; i++) {
				for (let j = 0; j<2; j++) {
					
					args = {};
					args.name = "";
					args.speed = 0;
					args.directioniscircle = "false";
					args.hp = 1;
					args.candie = "true";
					args.canbetouched = "false";
					args.deathaction = 0;
					args.isPlayerShot = "false";
					args.isBonus = "false";
					args.cantbeinstakill = "true";
					args.action = 2401;
					args.sprite = "bonepart1";
					args.width = 0;
					args.height = 0;
					args.collision = [{}];
					args.anchorx = 0;
					args.posx = 452+8 + i*10 + _BH.bhmaxwidth/2;
					args.posy = ((j == 0) ? 76 : 460) + _BH.bhmaxwidth/2;
					args.angle = (j == 0) ? 90 : 270;
					args.collision_angle = "angle";
					args.direction = args.angle-270;
					args.anchorAligned = false;
					this.bones[j][i] = _BH.createBHObject(args)
				
				}
			}
			
			}
			
			
			if (this.maxhp - this.hp < 60) {
				
				for (let i = 0; i<37; i++) {
					for (let j = 0; j<2; j++) {
						
						this.bones[j][i].hp = ((Math.sin((this.maxhp-this.hp)/15 + i/10 + j*(Math.PI))*(this.maxhp-this.hp)/300) * 5 + 0.1 + (this.maxhp - this.hp)/3);
					
					}
				}
				
			} else {
			
			
				for (let i = 0; i<37; i++) {
					for (let j = 0; j<2; j++) {
						
						this.bones[j][i].hp = (Math.sin((this.maxhp-this.hp)/15 + i/10 + j*(Math.PI))*(this.maxhp-this.hp)/300) * 5 + 20;
					
					}
				}
			
			}
			
			this.hp -= 1;


    },
};