module.exports = {
		
    name: 'DEATH',
	id: 22,

    execute (index, _BH) {
		this.hp -= 1;

		if (this.hp == 0) {
			
			_BH.createFlash();
			
		}
    },
};