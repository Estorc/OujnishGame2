module.exports = {
		
    name: 'Mafia Bullet',
	id: 87,

    execute (index, _BH) {
		if (this.scale.x < 1) {
			
			this.scale.x += (this.speed/64)
			
		}
		
		if (this.scale.x > 1) {
			
			this.scale.x = 1
			
		}
    },
};