module.exports = {
		
    name: 'Explosion',
	id: 90,

    execute (index, _BH) {
		this.hp -= 1;

		if (this.pos.y + this.offset.y < _BH.player.pos.y + 44) {
			
			this.zindex = 0.5;
			
		} else {
			
			this.zindex = 1.5;
			
		}

		if (this.frame < 9) {
			
			this.collision = [{type:'circle',x:24,y:24,radius:16}]
			
		} else {
			
			this.zindex = 1.5;
			this.collision = [{}]
			
		}
    },
};