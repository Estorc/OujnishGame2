const { readdirSync } = nw.require('fs');


//-----------------------------------------------------------------------------
// Classes Rewrite
//


___FeatherBHObjects___Scene_Boot_start = Scene_Boot.prototype.start;
Scene_Boot.prototype.start = function() {
	BHpreloadActions();
	BHpreloadScenes();
	BHpreloadImages();
	$gameBulletHell.player = new BulletHellPlayer()
	___FeatherBHObjects___Scene_Boot_start.call(this);
};


//-----------------------------------------------------------------------------
// BulletHell
//
// The main class of the Bullet Hell Engine.


BulletHell.prototype.update = function(Spriteset) {
	
	this.spriteset = Spriteset;	
	if (!this.paused) {
		this.clearSpriteset(Spriteset);
		this.updateInputs();
		this.updateCounters();
		this.updateObjects(Spriteset);
		this.updatePlayer(Spriteset);
		this.updateSpriteset(Spriteset);
	}
	
};


BulletHell.prototype.clearSpriteset = function(Spriteset) {
	
	Spriteset._bhSprite.children = [];
	Spriteset.sprites = [];
	
};


BulletHell.prototype.updateInputs = function() {

	if (Input.isTriggered("collisionDebug")) {
		
		this.showCollisions = this.showCollisions ? false : true;
		
	}
	
	if ((BulletHellInput.isPressed("bh-Shot") || TouchInput.isPressed()) && this.player.shotDelay <= 0 && this.player.canShot) {
		
		this.doShot();
		
	}
	
	this.movementsActive && this.updateMovements();

};

BulletHell.prototype.updateMovements = function() {
	
	if (BulletHellInput.isPressed("bh-Up")) {
		
		if (BulletHellInput.isPressed("bh-Slow") || TouchInput.isRightPressed()) {
			
			this.player.pos.y -= this.player.speed[0];
			
		} else {
			
			this.player.pos.y -= this.player.speed[1];
			
		}
			
	}
	

	if (BulletHellInput.isPressed("bh-Down")) {
		
		if (BulletHellInput.isPressed("bh-Slow") || TouchInput.isRightPressed()) {
			
			this.player.pos.y += this.player.speed[0];
			
		} else {
			
			this.player.pos.y += this.player.speed[1];
			
		}
		
	}
	
	if (BulletHellInput.isPressed("bh-Left")) {
		
		if (BulletHellInput.isPressed("bh-Slow") || TouchInput.isRightPressed()) {
			
			this.player.pos.x -= this.player.speed[0];
			
		} else {
			
			this.player.pos.x -= this.player.speed[1];
			
		}
		
	}

	if (BulletHellInput.isPressed("bh-Right")) {
		
		if (BulletHellInput.isPressed("bh-Slow") || TouchInput.isRightPressed()) {
			
			this.player.pos.x += this.player.speed[0];
			
		} else {
			
			this.player.pos.x += this.player.speed[1];
			
		}
		
	}
	
};


BulletHell.prototype.updateCounters = function() {

		$BHWaitFrames += 1;
		this.player.shotDelay -= 1;

};


BulletHell.prototype.updateObjects = function(Spriteset) {

	for (this.iteration = 0; this.iteration < this.objects.length; this.iteration++) {
		
		this.objects[this.iteration].update(Spriteset);
		
	}	
	
	 /*this.objects = this.objects.filter(function(n) {
	   return n
	 });*/

};


BulletHell.prototype.updatePlayer = function(Spriteset) {
	
	if (this.player.sprite && !(((this.player.iframes+3)/4<<0)%2)) {
		
		Spriteset.addPlayerSprite(this.player.sprite.bitmap,this.player.sprite.frames,this.player.angle);
		this.updatePlayerAnimation();
	}
	
	this.player.iframes = Math.max(this.player.iframes-1,0);
	

	this.player.canShot = false;
	this.player.lastX = this.player.pos.x;
	this.player.lastY = this.player.pos.y;
	
};


BulletHell.prototype.updatePlayerAnimation = function() {
	
	this.player.durationFrame +=1
	if (this.player.durationFrame >= this.player.sprite.frameDuration) {
		this.player.frame += 1
		this.player.durationFrame = 0;
	}
	
	if (this.player.frame > this.player.sprite.frames-1) {
		this.player.frame = 0;
	}
	
};


BulletHell.prototype.updateSpriteset = function(Spriteset) {
	
	Spriteset._bhSprite.children.sort((a, b) => a.zindex - b.zindex);
	

	for (const text of this.texts.filter(item => !item.isPlaying())) {
		this.destroyTextSprite(text);
	}
	for (const text of this.texts) {
		text.update();
		text._texture && Spriteset._bhTexts.addChild(text);
	}
	
};


BulletHell.prototype.createPopupAtPlayerPosition = function(type,value,color) {
	
	const sprite = new BulletHellText({type:type,value:value},color);
	sprite.x = this.player.pos.x + 17 - this.screenx + this.xShift;
	sprite.y = this.player.pos.y + 31 - this.screeny + this.yShift;
	sprite.setup();
	this.texts.push(sprite);
	this.spriteset._bhTexts.addChild(sprite);
	
};


BulletHell.prototype.destroyTextSprite = function(sprite) {
	this.spriteset._bhTexts.removeChild(sprite);
    this.texts.remove(sprite);
    sprite._texture && sprite.destroy();
};


BulletHell.prototype.playerIsHit = function(damage) {
	
		this.player.iframes = $gameParty.battleMembers().map(item => item.def).reduce((a,b) => a + b, 0)/($gameVariables.value(1000)*10);
	
		damage = this.onHit(damage);
		
		if (damage == "oneshot") {
				this.getHitDamage("oneshot");
				return 0;
		}
		
		damage *= this.modifier;
		damage += Math.random()*this.randomizer - this.randomizer/2;
		damage = damage >> 0;
		
		this.getHitDamage(damage);
	
};


BulletHell.prototype.getBonus = function(power) {
	
		AudioManager.playSe(this.xpSFX);
		$gameScreen.startFlash([119, 255, 119, 221], 20);
		
		let lastLevel = $gameBulletHell.player.level;
		$gameBulletHell.player.xp += power;
		this.player.level = Math.min(this.player.level+($gameBulletHell.player.xp/10)<<0,5);
		$gameBulletHell.player.xp = $gameBulletHell.player.xp%10

		let text = `+${power}XP`;
		
		if ($gameBulletHell.player.level > lastLevel) {
			
			if ($gameBulletHell.player.level == 5) {
				AudioManager.playSe(this.levelMaxSFX);
				text = "LEVEL MAX!"
			} else {
				AudioManager.playSe(this.levelUpSFX);
				text = "LEVEL UP!"
			}
			
		}
		
		this.createPopupAtPlayerPosition('text',text,4);
};


BulletHell.prototype.getHitDamage = function(damage) {
	
	
		AudioManager.playSe(this.hitSFX);
		//$gameScreen.startFlash([170, 0, 255, 221], 20);
	
		if (damage != "oneshot") {
			this.createPopupAtPlayerPosition('digits',(-damage),18);
		}
		
		let value;
		
		if (damage == "oneshot") {
			value = Game_Interpreter.prototype.operateValue(1, 0, 9999999);			
		} else {
			value = Game_Interpreter.prototype.operateValue(1, 0, damage);
		}
			Game_Interpreter.prototype.iterateActorEx(0, 0, actor => {
				Game_Interpreter.prototype.changeHp(actor, value, true);
			});
	
};