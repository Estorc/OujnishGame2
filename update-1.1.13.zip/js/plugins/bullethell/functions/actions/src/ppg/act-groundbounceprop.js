module.exports = {
		
    name: 'Ground Bounce Prop',
	id: 37,

    execute (index, _BH) {
			if (typeof this.gravity === 'undefined') { this.gravity = 0 }
			this.gravity -= 0.25;
			
			this.pos.y -= this.gravity;
			
		
		if (this.pos.y > 460+_BH.bhmaxheight/2-this.height && this.pos.x < 828 + _BH.bhmaxwidth/2 - this.width && this.pos.x > 452 + _BH.bhmaxwidth/2) {
			
				this.pos.y = 460+_BH.bhmaxheight/2-this.height;
				this.gravity = Math.abs(this.gravity*0.75);
				if (this.direction.y < 0) {
					this.gravity /= 1+Math.abs(this.direction.y);
				}
				this.direction.y = 0;
			
		}
    },
};