module.exports = {
		
    name: 'Layton Mobile',
	id: 46,

    execute (index, _BH) {
		if(typeof this.begin === 'undefined') {
			this.timer = 0; 
			this.subtimer = 0; 
			this.subtimer2 = 0; 
			this.maxhp = this.hp;
			this.animt = 0; 
			this.animx = this.pos.x;
			this.begin = 0;
		}
			
		
		if (this.animt <= 60) {
			this.animt += 1;
			this.pos.x = _BH.easeOutSine(this.animt,this.animx,242+_BH.bhmaxwidth/2,60);
		} else {
			
			if (this.timer % 360 == 0) {
			
				_BH.createHeartPointer(this.pos.x+246-8,this.pos.y+144-8,3,360,`${this.name + this.pos.y}`);
				
			}
			

			if (this.timer % 250 == 0) {
			
				AudioManager.playSe({name: 'Thunder10', pan: 0, pitch: 150, volume: 100});
				this.subtimer = 15;
				
				
			}
			
			if (this.timer % 230 == 0) {
			
				this.subtimer2 = 7;
				
			}
			
			
			if (this.subtimer > 0 && this.timer % 4 == 0) {
			
				this.subtimer -= 1;
				args = {};
				args.name = "";
				args.posx = this.pos.x + 90;
				args.posy = this.pos.y + 110-16;
				args.width = 32;
				args.height = 32;
				args.speed = 3;
				args.direction = 90;
				args.directioniscircle = "false";
				args.sprite = 'ppg_bigbullet';
				args.candie = "false";
				args.canbetouched = "false";
				args.action = 47;
				args.deathaction = 0;
				args.isPlayerShot = "false";
				args.isBonus = "false";
				args.anchorAligned = false;
				
				args.hp = 1;
				_BH.createBHObject(args)
				args.hp = 2;
				_BH.createBHObject(args)
				args.hp = 3;
				_BH.createBHObject(args)
				
				
			}
			
			if (this.subtimer2 > 0 && this.timer % 20 == 0) {
			
				AudioManager.playSe({name: 'Water1', pan: 0, pitch: 180, volume: 80});
				this.subtimer2 -= 1;
				args = {};
				args.name = "";
				args.posx = this.pos.x + 234;
				args.posy = this.pos.y + 215-8;
				args.width = 16;
				args.height = 16;
				args.speed = 5;
				args.direction = Math.random()*30-15;
				args.directioniscircle = "true";
				args.sprite = 'ppg_commonbullet';
				args.candie = "false";
				args.canbetouched = "false";
				args.action = 48;
				args.deathaction = 0;
				args.isPlayerShot = "false";
				args.isBonus = "false";
				args.hp = 0;
				args.anchorAligned = false;
				_BH.createBHObject(args)
				
				
			}
			
			this.timer += 1;
			
		}
		
		if (this.hp <= 0) {
						
			AudioManager.playSe({name: 'Earth4', pan: 0, pitch: 150, volume: 200});
			AudioManager.playSe({name: 'Fire2', pan: 0, pitch: 100, volume: 200});
			_BH.removeObjectByName(`${this.name + this.pos.y}`);
			for (n = 0; n<100; n++) {
				
				args = {};
				args.name = "";
				args.posx = this.pos.x + 242/2-8;
				args.posy = this.pos.y + 264/2-8;
				args.width = 16;
				args.height = 16;
				args.speed = 2+Math.random()*5;
				args.direction = Math.random()*360;
				args.directioniscircle = "true";
				args.sprite = 'ppg_commonbullet';
				args.hp = 0;
				args.candie = "false";
				args.canbetouched = "false";
				args.action = 0;
				args.deathaction = 0;
				args.isPlayerShot = "false";
				args.isBonus = "false";
				args.anchorAligned = false;
				_BH.createBHObject(args)
				
			}
			
			this.candie = true;
			
		}			
    },
};