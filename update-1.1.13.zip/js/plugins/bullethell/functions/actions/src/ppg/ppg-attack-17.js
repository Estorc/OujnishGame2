module.exports = {
		
    name: 'PPG Attack 17',
	id: 67,

    execute (index, _BH) {
			if(typeof this.begin === 'undefined') {

				this.scene.swapSoul("yellow");
				this.maxhp = this.hp;
				_BH.player.pos.x = 640-36/2;
				_BH.player.pos.y = 272;
				this.begin = 0;
				
			}
			
			this.hp -= 1;

			if (this.hp % 3 == 0) {
			_BH.createRotGasterBlaster(640-35 + Math.cos((this.hp*2.5 % 360)/180*Math.PI)*350 + _BH.bhmaxwidth/2, 
			272-35 + Math.sin((this.hp*2.5 % 360)/180*Math.PI)*350 + _BH.bhmaxheight/2, 
			20, 
			60, 
			(this.hp*2.5 % 360)+180)
			}


    },
};