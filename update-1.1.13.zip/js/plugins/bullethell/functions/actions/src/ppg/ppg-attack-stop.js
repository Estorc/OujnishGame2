module.exports = {
		
    name: 'PPG Attack Stop',
	id: 50,

    execute (index, _BH) {
		
			_BH.objects.map(item => item.name === "ppgPlatform" && item.destroy() & _BH.remove(item) || item);
			this.scene.ended = true;
			
    },
};