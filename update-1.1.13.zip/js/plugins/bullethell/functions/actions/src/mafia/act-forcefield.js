module.exports = {
		
    name: 'Force Field',
	id: 89,

    execute (index, _BH) {
			if (typeof this.timer === 'undefined') {
				this.timer = 0;
				this.FFframe = 0;
				this.connected = [];
				this.timerFF = []
			}
			
			this.forcesFields = _BH.objects.filter(object => object.actionid == 89);
			this.selfFFid = this.forcesFields.findIndex(item => item == this);
			

			this.timer += 1;
			
			if (this.timer % 4 == 0) {
				
				this.FFframe += 1;
				if (this.FFframe >= 3) {
					this.FFframe = 0;
				}
				
			}
			
				for (let z = 0; z<this.forcesFields.length; z++) {
					let selfID = this.selfFFid;
					let obj = this.forcesFields[z];
					if (obj !== this && typeof this.connected !== 'undefined' && (typeof this.connected[z] === 'undefined' || !this.connected[z]) && _BH.getDistanceBetweenPoints(this.pos.x,this.pos.y,obj.pos.x,obj.pos.y) < 200) {
						if (typeof obj.connected === 'undefined') {
							obj.connected = [];
							obj.timerFF = [];
						}
						if (typeof obj.connected[selfID] === 'undefined') {
							AudioManager.playSe({name: 'Paralyze2', pan: 0, pitch: 100, volume: 70});
							obj.connected[selfID] = true;
							obj.timerFF[selfID] = 100;
						}
						args = {};
						args.name = "";
						args.speed = 0;
						args.directioniscircle = "true";
						args.hp = 0;
						args.candie = "true";
						args.canbetouched = "false";
						args.deathaction = 0;
						args.isPlayerShot = "false";
						args.isBonus = "false";
						args.cantbeinstakill = "false";
						args.action = 0;
						args.sprite = 'forceField@3';
						args.width = 48;
						args.height = 32;
						args.offsety = 0;
						args.offsetx = 0;
						args.posx = this.pos.x+this.width/2;
						args.posy = this.pos.y-this.height/2;
						args.anchorx = 0;
						args.scalex = _BH.getDistanceBetweenPoints(this.pos.x,this.pos.y,obj.pos.x,obj.pos.y)/48
						args.angle = _BH.getDirectionToPosition(this.pos.x,this.pos.y,obj.pos.x,obj.pos.y+8);
						args.collision_scalex = 'scale';
						args.collision_angle = 'angle';
						args.zindex = -0.1;
						args.anchorAligned = false;
						let forceField = _BH.createBHObject(args)
						forceField.frame = this.FFframe;
					}
					else if (obj !== this && typeof this.connected !== 'undefined' && (typeof this.connected[z] !== 'undefined' && this.connected[z]) && _BH.getDistanceBetweenPoints(this.pos.x,this.pos.y,obj.pos.x,obj.pos.y) >= 200 && this.timerFF[z] > 0) {
						
						if (this.timerFF[z] == 100) {
							AudioManager.playSe({name: 'Paralyze1', pan: 0, pitch: 150, volume: 70});
						}
						this.timerFF[z] -= 10;
						args = {};
						args.name = "";
						args.speed = 0;
						args.directioniscircle = "true";
						args.hp = 0;
						args.candie = "true";
						args.canbetouched = "false";
						args.deathaction = 0;
						args.isPlayerShot = "false";
						args.isBonus = "false";
						args.cantbeinstakill = "false";
						args.action = 0;
						args.sprite = 'forceField@3';
						args.width = 48;
						args.height = 32;
						args.offsety = 0;
						args.offsetx = 0;
						args.posx = this.pos.x+this.width/2;
						args.posy = this.pos.y-this.height/2;
						args.anchorx = 0;
						args.scalex = _BH.getDistanceBetweenPoints(this.pos.x,this.pos.y,obj.pos.x,obj.pos.y)/48
						args.scaley = this.timerFF[z]/100
						args.opacity = (this.timerFF[z]/100)*255
						args.angle = _BH.getDirectionToPosition(this.pos.x,this.pos.y,obj.pos.x,obj.pos.y+8);
						args.collision_scalex = 'scale';
						args.collision_scaley = 0;
						args.collision_angle = 'angle';
						args.zindex = -0.1;
						args.anchorAligned = false;
						let forceField = _BH.createBHObject(args)
						forceField.frame = this.FFframe;
						
					}
				}
    },
};