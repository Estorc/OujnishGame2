module.exports = {
		
    name: 'Explosive Bullet',
	id: 84,

    execute (index, _BH) {
		if(typeof this.begin === 'undefined') {
			this.maxY = this.pos.y + 304-48;
			this.begin = 0;
			
			args = {};
			args.name = "";
			args.speed = 0;
			args.directioniscircle = "false";
			args.hp = 1;
			args.candie = "true";
			args.canbetouched = "false";
			args.deathaction = 0;
			args.isPlayerShot = "false";
			args.isBonus = "false";
			args.cantbeinstakill = "true";
			args.action = 0;
			args.sprite = 'BombShadow';
			args.width = 0;
			args.height = 0;
			args.offsety = 0;
			args.offsetx = 0;
			args.posx = this.pos.x;
			args.posy = this.maxY+10;
			args.direction = 0;
			args.zindex = -0.5;
			args.collision = [{}];
			args.anchorAligned = false;
			this.shadow = _BH.createBHObject(args)
		}

		this.explodePower = this.hp;

		if (this.pos.y >=this.maxY) {
			
				this.shadow.hp = 0;
				this.hp = 0;
			
		}
    },
};