module.exports = {
		
    name: 'Mafia 2',
	id: 82,

    execute (index, _BH) {
		if(typeof this.begin === 'undefined') {
			this.timer = 0; 
			this.maxhp = this.hp;
			this.animt = 0; 
			this.animy = this.pos.y;
			this.begin = 0;
			this.randomy = Math.random()*(-200);
		}
		
		if (typeof this.flash !== 'undefined') {
			
			
			this.flash.hp = 0;
			
		}
			
		
		if (this.animt <= 60) {
			this.animt += 1;
			this.pos.y = _BH.easeOutSine(this.animt,this.animy,this.randomy-72-44,60);
		} else {
			
			if (this.timer == 0) {
				
				this.pos.y = Math.floor(this.pos.y);
				
			}
			
			if (this.timer % 360 == 0 || this.timer % 360 == 30) {
			
				AudioManager.playSe({name: 'Gun2', pan: 0, pitch: 120+Math.random()*30, volume: 100});
				
			}
			if (this.timer % 360 < 60) {
				
				
				if (this.timer % 6 == 0) {
				
					args = {};
					args.name = "";
					args.speed = 10;
					args.directioniscircle = "true";
					args.hp = 0;
					args.candie = "false";
					args.canbetouched = "false";
					args.deathaction = 0;
					args.isPlayerShot = "false";
					args.isBonus = "false";
					args.cantbeinstakill = "false";
					args.action = 87;
					args.sprite = 'MafiaBullet';
					args.width = 2;
					args.height = 2;
					args.offsety = 0;
					args.offsetx = 0;
					args.anchorx = 1;
					args.scalex = 0;
					args.posx = this.pos.x - this.width/2-10;
					args.posy = this.pos.y + this.height/2+24;
					args.angle = _BH.getDirectionToPlayer(index,64 - this.width,24);
					args.direction = _BH.getDirectionToPlayer(index,64 - this.width-10,24);
					args.collision =[{type:'rect',x1:60,y1:0,x2:2,y2:2}];
					args.zindex = 10;
					args.anchorAligned = false;
					_BH.createBHObject(args)
					
					args = {};
					args.name = "";
					args.speed = 0;
					args.directioniscircle = "false";
					args.hp = 1;
					args.candie = "true";
					args.canbetouched = "false";
					args.deathaction = 0;
					args.isPlayerShot = "false";
					args.isBonus = "false";
					args.cantbeinstakill = "false";
					args.action = 0;
					args.sprite = 'MafiaBulletFlash';
					args.width = 0;
					args.height = 0;
					args.offsety = -80;
					args.offsetx = -16;
					args.posx = this.pos.x - this.width/2;
					args.posy = this.pos.y + this.height/2+24;
					args.collision = [{}];
					args.zindex = 15;
					args.anchorAligned = false;
					this.flash = _BH.createBHObject(args)
					
				}
				
			}
			
			if (this.timer == 500) {
			
				this.direction.x = 0;
				this.direction.y = 1;
				this.speed = 2;
				
			}
			
			this.timer += 1;
		}
			this.zindex = this.pos.y/10000
    },
};