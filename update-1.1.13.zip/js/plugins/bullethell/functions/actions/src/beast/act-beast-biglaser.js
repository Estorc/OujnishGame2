module.exports = {
		
    name: 'Beast Big Laser',
	id: 15,

    execute (index, _BH) {
		if (this.hp == 299) {

			args = {};
			args.name = "";
			args.posx = this.pos.x;
			args.posy = this.pos.y+this.height;
			args.offsetx = -8;
			args.offsety = 0;
			args.width = 64;
			args.height = 32;
			args.speed = 0;
			args.direction = 0;
			args.directioniscircle = "false";
			args.sprite = 'beastbiglaser2';
			args.hp = 300;
			args.candie = "true";
			args.canbetouched = "false";
			args.action = 15;
			args.deathaction = 0;
			args.isPlayerShot = "false";
			args.cantbeinstakill = "true";
			args.isBonus = "false";
			args.anchorAligned = false;
			_BH.createBHObject(args)

		}



			if (Number.isInteger(this.hp / 5) && _BH.getRandomInt(5) == 0) {
				
				args = {};
				args.name = "";
				args.posx = this.pos.x + this.width/2-8;
				args.posy = this.pos.y + Math.random()*this.height;
				args.width = 16;
				args.height = 16;
				args.speed = 6;
				args.direction = (Math.floor(Math.random()*2) * 180)-90;
				if (args.direction < 0) {
					args.direction += 360;
				}
				args.directioniscircle = "false";
				args.sprite = 'thanoscarbullet';
				args.hp = 1;
				args.candie = "true";
				args.canbetouched = "false";
				args.action = 16;
				args.deathaction = 0;
				args.isPlayerShot = "false";
				args.isBonus = "false";
				args.anchorAligned = false;
				_BH.createBHObject(args)
				
			}



		this.hp -= 1;
    },
};