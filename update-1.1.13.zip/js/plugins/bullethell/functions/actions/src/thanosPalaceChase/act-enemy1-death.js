module.exports = {
		
    name: 'Death Enemy 1',
	id: 4,

    execute (index, _BH) {
			
		_BH.createFlash();
		
		_BH.spawnBonus("MinusBonus", 
						this.pos.x + this.width/2 - 8, 
						this.pos.y + this.height/2 - 8, 
						12, 12, 'SmallBonus', 1)
	
    },
};