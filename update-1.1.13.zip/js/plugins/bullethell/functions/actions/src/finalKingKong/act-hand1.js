module.exports = {
		
    name: 'KK_Hand1',
	id: 1103,

    execute (index, _BH) {
		if(typeof this.begin === 'undefined') {
			
			switch (Math.floor(Math.random()*4)) {
				
				case 0:
				
					AudioManager.playSe({name: 'kk-1', pan: 0, pitch: 100, volume: 200});
				
				case 1:
				
					AudioManager.playSe({name: 'kk-2', pan: 0, pitch: 100, volume: 200});
				
				case 2:
				
					AudioManager.playSe({name: 'kk-3', pan: 0, pitch: 100, volume: 200});
				
				case 3:
				
					AudioManager.playSe({name: 'kk-4', pan: 0, pitch: 100, volume: 200});
				
			}

			this.begin = 0;
			this.timer = 0;
			this.originx = this.pos.x;
			this.originy = this.pos.y;
			this.noLimit = true;
			
			
			args = {};
			args.name = "";
			args.posx = (this.scale.x == 1) ? this.pos.x-388 : this.pos.x-70+365-458;
			args.posy = this.pos.y-44;
			args.direction = 0;
			args.width = 0;
			args.height = 0;
			args.collision = [{}];
			args.speed = 0;
			args.directioniscircle = "true";
			args.sprite = 'KK-ARM';
			args.hp = 1;
			args.scalex = this.scale.x;
			args.scaley = 1;
			args.candie = "true";
			args.canbetouched = "false";
			args.action = 0;
			args.deathaction = 0;
			args.isPlayerShot = "false";
			args.isBonus = "false";
			args.anchorx = 1;
			args.anchory = 0.65;
			args.zindex = -0.5;
			args.anchorAligned = false;
			args.motionblurFrames = this.motionblurFrames;
			
			if (this.direction.y == 1) {

				this.angle = (this.scale.x == 1) ? -5 : 5;
			
			}
			
			this.arm1 = _BH.createBHObject(args)
			this.arm1.noLimit = true;
			
			args.posy = this.pos.y-104;
			args.posx = (this.scale.x == 1) ? this.pos.x-388-400 : this.pos.x-70+365-458+400;
			
			args.zindex = -0.6;
			
			this.arm2 = _BH.createBHObject(args)
			this.arm2.noLimit = true;
			
			
		}
		
		this.arm1.pos.x = ((this.scale.x == 1) ? this.pos.x-388 : this.pos.x-70+365-458) + this.arm1.width;
		this.arm1.pos.y = this.pos.y-44 + this.arm1.height;
		this.arm1.opacity = this.opacity;
		
		this.arm2.pos.x = ((this.scale.x == 1) ? this.pos.x-388-400 : this.pos.x-70+365-458+400) + this.arm2.width;
		this.arm2.pos.y = this.pos.y-104 + this.arm2.height;
		this.arm2.opacity = this.opacity;
		
		
		if (this.opacity < 255) {
			
			this.opacity += 10;
			
			if (this.opacity > 255) {
			
				if (this.direction.y == 1) {
					this.speed = 2.5;
				} else {
					this.speed = 4;
				}
			
			}
			
		} else {
			
			
			if (this.direction.y != 0) {
				
				this.arm1.angle += ((this.scale.x == 1) ? 2 : -2)*this.direction.y;
				this.arm2.angle += ((this.scale.x == 1) ? 2.5 : -2.5)*this.direction.y;
				
				this.arm2.height -= 10*this.direction.y;
				this.arm2.width += ((this.scale.x == 1) ? 10 : -10)*this.direction.y;
				
			}
		
			
			if (this.hp != 45) {this.speed *= 1.1} else {this.speed *= 0.935};
		
		}
		
		
		if (this.hp == 45) {
			
			this.angle += (this.direction.x == 1) ? -1.5 : 1.5;
			this.pos.y -= 30-this.speed/2;
			this.arm1.angle += (this.direction.x == 1) ? -2 : 2;
			this.arm1.height -= 2;
			this.arm1.width += (this.direction.x == 1) ? -2 : 2;
			
			
			this.arm2.angle += (this.direction.x == 1) ? -4 : 4;
			this.arm2.height -= 10;
			this.arm2.width += (this.direction.x == 1) ? -10 : 10;
			
		}
		
		
		if ((this.direction.y == -1 || this.hp == 45) && this.pos.y < 0) {
			
				this.arm1.hp = 0;
				this.arm2.hp = 0;
				this.hp = 0;
			
		}
		
		
		if ((this.direction.x == 1 && this.pos.x > 1280) || (this.direction.x == -1 && this.pos.x < 0) || (this.direction.y == 1 && this.pos.y > 720)) {
			
			if (this.hp != 45) {

			
				AudioManager.playSe({name: 'Earth4', pan: 0, pitch: 150, volume: 200});
				AudioManager.playSe({name: 'Fire2', pan: 0, pitch: 100, volume: 200});
				$gameScreen.startShake(5, 5, 10);
				for (n = 0; n<10; n++) {
					
					args = {};
					args.name = "";
					if (this.direction.y == 1) {
						
						args.posx = (this.scale.x == 1) ? this.pos.x - 8+268 : this.pos.x + 385-360;
						
					} else {
						
						args.posx = (this.scale.x == 1) ? this.pos.x - 8+50 : this.pos.x + 385-175;
						
					}

					args.posy = this.pos.y + 101-8;
					args.width = 16;
					args.height = 16;
					args.speed = 2+Math.random()*5;
					args.direction = Math.random()*360;
					args.directioniscircle = "true";
					args.sprite = 'ppg_commonbullet';
					args.hp = 0;
					args.candie = "false";
					args.canbetouched = "false";
					args.action = 0;
					args.deathaction = 0;
					args.isPlayerShot = "false";
					args.damage = 0.25;
					args.isBonus = "false";
					args.anchorAligned = false;
					_BH.createBHObject(args)
					
				}
				

			}
				
				
			if (this.direction.y == 1) {
				
				this.direction.y *= -1;
				this.speed = 4;
				
			} else if (this.hp == 45) {
				this.arm1.hp = 0;
				this.arm2.hp = 0;
				this.hp = 0;
			} else {
				
				this.pos.x = (this.direction.x == 1) ? 1279 : 1;
				this.direction.x *= -1;
				this.hp = 45;
				this.speed = 80;
				this.collision = [{}];
				
			}
			
		}
		
	},
};