module.exports = {
		
    name: 'OTF_Arm1',
	id: 1102,

    execute (index, _BH) {
		if(typeof this.begin === 'undefined') {

			this.begin = 0;
			this.timer = 0;
			this.originx = this.pos.x;
			this.originy = this.pos.y;
			
		}
		
		this.timer += 0.1;
		this.scale.x = Math.sin(this.timer)/16+1.0625
		this.scale.y = Math.sin(this.timer)/16+1.0625
		
	},
};