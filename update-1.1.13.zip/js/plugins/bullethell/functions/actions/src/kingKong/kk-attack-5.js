module.exports = {
		
    name: 'KK Attack 5',
	id: 4205,

    execute (index, _BH) {
			if(typeof this.begin === 'undefined') {

				this.scene.swapSoul("blue");
				this.maxhp = this.hp;
				_BH.player.pos.x = 640-18;
				_BH.player.pos.y = 800;
				this.begin = 0;
				this.bones = [];
				this.circle = 0;
				this.maxCircle = 6;
				
			}

			
			
			if (this.hp % 20 == 0) {
			
			this.bones[this.circle] = [];
			
			for (let i = 0; i<this.maxCircle; i++) {
					
				args = {};
				args.name = "";
				args.speed = 0;
				args.directioniscircle = "false";
				args.hp = 5;
				args.candie = "true";
				args.canbetouched = "false";
				args.deathaction = 0;
				args.isPlayerShot = "false";
				args.isBonus = "false";
				args.cantbeinstakill = "true";
				args.action = 2401;
				args.sprite = "bonepart1";
				args.width = 0;
				args.height = 0;
				args.collision = [{}];
				args.anchorx = 0;
				args.posx = 640-5 + _BH.bhmaxwidth/2;
				args.posy = 272-5 + _BH.bhmaxwidth/2;
				args.angle = 0;
				args.collision_angle = "angle";
				args.direction = 0;
				args.anchorAligned = false;
				args.motionblurFrames = 4;
				this.bones[this.circle][i] = _BH.createBHObject(args)

			}
			
			this.bones[this.circle][this.maxCircle] = Math.random()*10;
			this.bones[this.circle][this.maxCircle+1] = 3;
			this.bones[this.circle][this.maxCircle+2] = Math.floor(Math.random()*2);
			
			this.circle++;
			
			}
			
			
			
			
			for (let j = 0; j<this.circle; j++) {
				for (let i = 0; i<this.maxCircle; i++) {
						
					this.bones[j][this.maxCircle] += (this.bones[j][this.maxCircle+2] == 0) ? 0.0025 : -0.0025;
					this.bones[j][this.maxCircle+1] *= 1.005;
					
					let x = 640-5 + Math.cos(this.bones[j][this.maxCircle] + ((2*Math.PI)/this.maxCircle)*i)*this.bones[j][this.maxCircle+1] + _BH.bhmaxwidth/2
					let y = 272-5 + Math.sin(this.bones[j][this.maxCircle] + ((2*Math.PI)/this.maxCircle)*i)*this.bones[j][this.maxCircle+1] + _BH.bhmaxheight/2
					this.bones[j][i].pos.x = x;
					this.bones[j][i].pos.y = y;
					this.bones[j][i].angle = this.bones[j][this.maxCircle]*180/Math.PI + ((360)/this.maxCircle)*i+90;
					
				}
			}
			
			
			this.hp -= 1;


    },
};