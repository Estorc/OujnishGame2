//-----------------------------------------------------------------------------
// Loading all scenes ['./functions/scene/']
//


const sceneDir = 'js/plugins/bullethell/functions/scene';
let BHscenes = {};


BulletHell.prototype.loadScene = function(scene, parameters = {}) {
	!$gameBulletHell.scenes.some(item => item.name == scene.name && item.id == scene.id) && ($gameBulletHell.scenes.push(new BulletHellScene(scene)));
	$gameBulletHell.activeScene = $gameBulletHell.scenes.find(item => item.name == scene.name && item.id == scene.id);
	scene.load.call($gameBulletHell, this, $gameBulletHell.activeScene, parameters);
};




//-----------------------------------------------------------------------------
// BulletHellScene
//
// The class of the Bullet Hell scenes (a sort of custom engine.).


BulletHellScene = function() {
	this.initialize(...arguments);	
}

BulletHellScene.prototype.initialize = function(scene) {		

	this.id = scene.id;
	this.name = scene.name;

};

BHpreloadScenes = function() {
	const scenes = readdirSync(`${sceneDir}`).filter(files => files.endsWith('.js'));

	for (const file of scenes) {
		let scene = require(`${sceneDir}/${file}`);
		console.log(`-> Loaded scene ${scene.name} (${file})`);
		eval('scene.load = function '+scene.load.toString().substr(4, scene.load.toString().length));
		BHscenes[scene.name] = scene;
	};
}
	
	
	
	
___FeatherBH___BattleManager_processTurn = BattleManager.processTurn
BattleManager.processTurn = function() {
	
	if (typeof this._subject._enemyId !== 'undefined' && typeof this._subject.currentAction() !== 'undefined' && $dataEnemies[this._subject._enemyId].meta.BHScene) {
		
		
		let BHscene = eval($dataEnemies[this._subject._enemyId].meta.BHScene);
		let skillParam = eval(this._subject.currentAction().item().meta.BHSceneSwitch);
		
		if (BHscene[1] || skillParam) {
			let scene = BHscenes[BHscene[0]];
			$gameBulletHell.loadScene.call(this,scene, parameters = {'skillParam':skillParam})
			return 0;
		}
		
		return ___FeatherBH___BattleManager_processTurn.call(this);
		
		
	}
	
	if (this._subject.currentAction() && this._subject.currentAction().item() && this._subject.currentAction().item().meta.BHScene) {
		
		
		let BHscene = eval(this._subject.currentAction().item().meta.BHScene);
		let skillParam = eval(this._subject.currentAction().item().meta.BHSceneSwitch);
		
		if (skillParam) {
			let scene = BHscenes[BHscene[0]];
			$gameBulletHell.loadScene.call(this,scene, parameters = {'skillParam':skillParam})
			return 0;
		}
		
		return ___FeatherBH___BattleManager_processTurn.call(this);
		
		
	} 
	
	return ___FeatherBH___BattleManager_processTurn.call(this);
	
};