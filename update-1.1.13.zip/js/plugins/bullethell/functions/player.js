//-----------------------------------------------------------------------------
// BulletHellPlayer
//
// The class of the Bullet Hell player.


BulletHellPlayer = function() {
	this.initialize(...arguments);	
};


BulletHellPlayer.prototype.initialize = function(args) {		

	this.sprite = null;
	this.frame = 0;
	this.durationFrame = 1;
	this.shotDelay = 0;
	this.speed = [2,5];
	
	this.iframes = 0;
	
	this.xp = 0;
	this.level = 0;
	
	this.pos = {x : 0, y : 0};
	this.angle = 0;
	
	this.lastX = 0;
	this.lastY = 0;
	
	this.canShot = false;
	this.shotType = 0;
	
	this.collisionRect = {x1 : 10, y1 : 37, x2 : 24, y2 : 52};

};


BulletHellPlayer.prototype.hasMove = function() {
	
	return this.lastX != this.pos.x || this.lastY != this.pos.y;
	
};


BulletHellPlayer.prototype.drawPlayerCollision = function() {
		
	if (typeof this.collisionSprite !== 'undefined' && this.collisionSprite[1] == this.collisionSprite) {
		
		return this.collisionSprite[0];
		
	}
		
	let gr = new PIXI.Graphics();
	gr.beginFill(0xFF0000);
	gr.drawRect(this.collisionRect.x1, this.collisionRect.y1 , this.collisionRect.x2-this.collisionRect.x1, this.collisionRect.y2-this.collisionRect.y1);
	gr.endFill();


	let bitmap = new Bitmap(gr.width, gr.height);
	let collisionTexture = Graphics.app.renderer.generateTexture(gr);
	const canvas = Graphics.app.renderer.extract.canvas(collisionTexture);
	let collisionBitmap = new Bitmap(collisionTexture.width,collisionTexture.height);
	bitmap.context.drawImage(canvas, 0, 0);
	canvas.width = 0;
	canvas.height = 0;
	bitmap.baseTexture.update();

	this.collisionSprite = [new Sprite(bitmap),this.collisionRect];

	return this.collisionSprite[0];
		
};


// Import player's shot file

BulletHell.loadScript("functions/playerShot")