//=============================================================================
// RPG Maker MZ - MiscCharacterMorph
//=============================================================================

/*:
 * @target MZ
 * @plugindesc Misc Character Morph system plugin.
 * @author Feather
 *
 * @help 
 * Misc Character Morph system plugin.
 *
 */
 

(() => {
    const pluginName = "MiscCharacterMorph";

	
})();
