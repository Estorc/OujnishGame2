//-----------------------------------------------------------------------------
// Loading all actions ['./functions/actions/']
//


const actionDir = 'js/plugins/bullethell/functions/actions/src';
let BHactions = [];


BHpreloadActions = function() {
	readdirSync(`${actionDir}/`).forEach(dirs => {
		const actions = readdirSync(`${actionDir}/${dirs}`).filter(files => files.endsWith('.js'));

		for (const file of actions) {
			let action = require(`${actionDir}/${dirs}/${file}`);
			console.log(`-> Loaded action ${action.name}`);
			eval('action.execute = function '+action.execute.toString().substr(7, action.execute.toString().length));
			BHactions.push(action);
		};
	});
};




//-----------------------------------------------------------------------------
// BulletHell
//
// The main class of the Bullet Hell Engine.


BulletHell.prototype.getAction = function(index) {

	this.objects[index].action.call(this.objects[index],index,this);

};


BulletHell.prototype.getDeathAction = function(index) {

	this.objects[index].deathaction.call(this.objects[index],index,this);

};