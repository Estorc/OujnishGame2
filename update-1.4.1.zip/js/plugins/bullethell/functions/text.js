//-----------------------------------------------------------------------------
// BulletHellText
//
// The sprite for displaying a popup.


BulletHellText = function() {
	this.initialize(...arguments);	
};


BulletHellText.prototype = Object.create(Sprite.prototype);
BulletHellText.prototype.constructor = BulletHellText;


BulletHellText.prototype.initialize = function(text, color) {		
    Sprite.prototype.initialize.call(this);
	this._text = text;
    this._duration = 90;
    this._color = color;
};


BulletHellText.prototype.destroy = function(options) {
    for (const child of this.children) {
        if (child.bitmap) {
            child.bitmap.destroy();
        }
    }
    Sprite.prototype.destroy.call(this, options);
};


BulletHellText.prototype.setup = function(target) {
	
	switch (this._text.type) {
		case 'text':
			this.createText(this._text.value);
			break;
		case 'digits':
			this.createDigits(this._text.value);
			break;
	};
};


BulletHellText.prototype.fontFace = function() {
    return $gameSystem.numberFontFace();
};


BulletHellText.prototype.fontSize = function() {
    return 20;
};


BulletHellText.prototype.fontColor = function() {
    return ColorManager.textColor(this._color);
};


BulletHellText.prototype.outlineColor = function() {
    return "rgba(0, 0, 0, 0.7)";
};


BulletHellText.prototype.outlineWidth = function() {
    return 4;
};


BulletHellText.prototype.createText = function(text) {
    const h = this.fontSize();
    const w = Math.floor(h * text.length/2);
    const sprite = this.createChildSprite(w, h);
    sprite.bitmap.drawText(text, 0, 0, w, h, "center");
    sprite.dy = 0;
};


BulletHellText.prototype.createDigits = function(value) {
    const string = value.toString();
    const h = this.fontSize();
    const w = Math.floor(h * 0.75);
    for (let i = 0; i < string.length; i++) {
        const sprite = this.createChildSprite(w, h);
        sprite.bitmap.drawText(string[i], 0, 0, w, h, "center");
        sprite.x = (i - (string.length - 1) / 2) * w;
    }
};


BulletHellText.prototype.createChildSprite = function(width, height) {
    const sprite = new Sprite();
    sprite.bitmap = this.createBitmap(width, height);
    sprite.anchor.x = 0.5;
    sprite.anchor.y = 0.5;
	sprite.y = 10;
    this.addChild(sprite);
    return sprite;
};


BulletHellText.prototype.createBitmap = function(width, height) {
    const bitmap = new Bitmap(width, height);
    bitmap.fontFace = this.fontFace();
    bitmap.fontSize = this.fontSize();
    bitmap.textColor = this.fontColor();
    bitmap.outlineColor = this.outlineColor();
    bitmap.outlineWidth = this.outlineWidth();
    return bitmap;
};


BulletHellText.prototype.update = function() {
    Sprite.prototype.update.call(this);
    if (this._duration > 0) {
        this._duration--;
        for (const child of this.children) {
            this.updateChild(child);
        }
    }
    this.updateOpacity();
};


BulletHellText.prototype.updateChild = function(sprite) {
    sprite.y -= 1;
};


BulletHellText.prototype.updateOpacity = function() {
    if (this._duration < 10) {
        this.opacity = (255 * this._duration) / 10;
    }
};


BulletHellText.prototype.isPlaying = function() {
    return this._duration > 0;
};