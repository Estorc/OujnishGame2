module.exports = {
		
    name: 'Gaster Blaster Laser',
	id: 804,

    execute (index, _BH) {
		if(typeof this.begin === 'undefined') {

			this.pos.x += -25*this.direction.x
			this.pos.y += -25*this.direction.y
			AudioManager.playSe({name: 'Battle4', pan: 0, pitch: 150, volume: 100});
			AudioManager.playSe({name: 'DevourerAttack', pan: 0, pitch: 80, volume: 100});
			this.begin = 0;
			
		}

		this.begin += 1;

		if (this.begin < 10) {
			
			this.scale.y += 1/10
			this.opacity += 255/10
			
		}
					
		if (this.begin > 18) {
			
			this.collision = [{}];
			this.scale.y -= 1/20
			this.opacity -= 255/10
			
			if (this.opacity <= 0) {
			
				this.candie = true;
				this.hp = 0;
				
			}
			
		}
    },
};