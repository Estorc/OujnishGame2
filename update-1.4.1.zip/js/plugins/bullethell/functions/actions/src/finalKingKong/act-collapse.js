module.exports = {
		
    name: 'OTF_Collapse',
	id: 1105,

    execute (index, _BH) {
		if(typeof this.begin === 'undefined') {
			
			AudioManager.playSe({name: 'Collapse2', pan: 0, pitch: 100, volume: 100});
			this.hp = 1;
			this.begin = 0;
			_BH.objects.map(x => x.action = 0);
			_BH.objects.map(x => x.collision = [{}]);
			_BH.objects.map(x => x.opacity /= 2);
			this.action = BHactions.find(action => action.id == 1105).execute;
			
		}
		
		this.hp += 1;
		
		_BH.objects.map(x => x.pos.y += 1);
		_BH.objects.map(x => x.pos.x += Math.cos(this.hp*2)*5);
		_BH.objects.map(x => x.opacity -= 0.2);
		
		if (this.hp % 20 == 0) {
			
			AudioManager.playSe({name: 'Collapse3', pan: 0, pitch: 100, volume: 100});
			
		}
		
		if (this.opacity <= 0) {
			
			_BH.objects[0].hp = 0;
		}
		
	},
};