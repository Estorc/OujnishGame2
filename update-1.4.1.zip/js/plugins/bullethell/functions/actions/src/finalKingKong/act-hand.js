module.exports = {
		
    name: 'OTF_Hand',
	id: 1103,

    execute (index, _BH) {
		if(typeof this.begin === 'undefined') {

			this.begin = 0;
			this.timer = 0;
			this.originx = this.pos.x;
			this.originy = this.pos.y;
			
		}
		
		this.timer += 0.05;
		
		if (this.name == "HandLeft") {
			
			this.angle = _BH.getDirectionToPlayer(index,132,110)-37.60 + Math.sin(this.timer)*10
		
		} else {
			 
			this.angle = _BH.getDirectionToPlayer(index,187,110)+180+37.60 + -Math.sin(this.timer)*10
		
		}
		
		this.pos.y = this.originy + Math.sin(this.timer*2)*10+10
		
	},
};