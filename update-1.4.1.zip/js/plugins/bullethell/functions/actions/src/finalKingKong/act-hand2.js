module.exports = {
		
    name: 'KK_Hand2',
	id: 1103,

    execute (index, _BH) {
		if(typeof this.begin === 'undefined') {

			this.begin = 0;
			this.timer = 0;
			this.originx = this.pos.x;
			this.originy = this.pos.y;
			
		}
		
		if (this.opacity < 255) {
			
			this.opacity += 10;
			
		} else {
		
			this.timer += 1;
			
			if (this.timer == 60) {
				
				this.angle -= 20;
				
				AudioManager.playSe({name: 'Earth4', pan: 0, pitch: 150, volume: 200});
				AudioManager.playSe({name: 'Fire2', pan: 0, pitch: 100, volume: 200});
				args = {};
				args.name = "";
				args.posx = (this.pos.x > 640) ? this.pos.x + 55-124 : this.pos.x + 450;
				args.posy = this.pos.y + 14;
				args.width = 124;
				args.height = 41;
				args.speed = 40;
				args.direction = (this.pos.x > 640) ? -90 : 90;
				args.directioniscircle = "false";
				args.sprite = 'KK-Bullet';
				args.hp = 0;
				args.damage = 3;
				args.candie = "false";
				args.canbetouched = "false";
				args.cantbeinstakill = "true";
				args.action = 0;
				args.scalex = (this.pos.x > 640) ? -1 : 1;
				args.deathaction = 0;
				args.isPlayerShot = "false";
				args.isBonus = "false";
				args.anchorAligned = false;
				args.motionblurFrames = 5;
				_BH.createBHObject(args)
				
			}
			
			if (this.timer == 180) {
				
				this.angle -= 20;
				
				AudioManager.playSe({name: 'Earth4', pan: 0, pitch: 150, volume: 200});
				AudioManager.playSe({name: 'Fire2', pan: 0, pitch: 100, volume: 200});
				args = {};
				args.name = "";
				args.posx = (this.pos.x > 640) ? this.pos.x + 27-124 : this.pos.x + 478;
				args.posy = this.pos.y + 65;
				args.width = 124;
				args.height = 41;
				args.speed = 40;
				args.direction = (this.pos.x > 640) ? -90 : 90;
				args.directioniscircle = "false";
				args.sprite = 'KK-Bullet';
				args.hp = 0;
				args.damage = 3;
				args.candie = "false";
				args.canbetouched = "false";
				args.cantbeinstakill = "true";
				args.action = 0;
				args.scalex = (this.pos.x > 640) ? -1 : 1;
				args.deathaction = 0;
				args.isPlayerShot = "false";
				args.isBonus = "false";
				args.anchorAligned = false;
				args.motionblurFrames = 5;
				_BH.createBHObject(args)
				
			}
		
		}
		
			if (this.timer > 180) {
				
				this.opacity -= 20;
				
				if (this.opacity <= 0) {
					
					this.hp = 0;
					
				}
				
			}
			
		if (this.angle != 0) {
			
			this.angle += 2;
			
		}
		
		if (this.timer <= 60) {
			this.pos.y += ((_BH.player.pos.y+43+_BH.bhmaxheight/2 - 30) - this.pos.y)/5;
		} else {
			this.pos.y += ((_BH.player.pos.y+43+_BH.bhmaxheight/2 - 30 - 51) - this.pos.y)/5;
		}
		
		
	},
};