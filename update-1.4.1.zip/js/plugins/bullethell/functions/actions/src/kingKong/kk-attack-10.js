module.exports = {
		
    name: 'KK Attack 10',
	id: 4210,

    execute (index, _BH) {
			if(typeof this.begin === 'undefined') {

				this.scene.swapSoul("blue");
				this.maxhp = this.hp;
				_BH.player.pos.x = 640-18;
				_BH.player.pos.y = 800;
				this.begin = 0;
				this.bones = [[],[]];
				
			}

			_BH.gravModifier = 1.5;
			
			if (this.hp % 2 == 0) {
				
				args = {};
				args.name = "";
				args.speed = 0;
				args.directioniscircle = "false";
				args.hp = 20;
				args.candie = "true";
				args.canbetouched = "false";
				args.deathaction = 0;
				args.isPlayerShot = "false";
				args.isBonus = "false";
				args.cantbeinstakill = "true";
				args.action = 'Wind';
				args.sprite = "bonepart2";
				
				args.scalex = 0.5;
				args.scaley = 0.66;
				
				args.width = 0;
				args.height = 0;
				args.collision = [{}];
				
				args.posx = 452+8 + 370*Math.random() + _BH.bhmaxwidth/2;
				args.posy = 76 + 290*Math.random() + _BH.bhmaxwidth/2;
				args.angle = this.angle;
				args.direction = this.direction;
				
				args.anchorAligned = false;
				_BH.createBHObject(args);
				
			}
			
			if (this.hp % 70 == 0 && this.maxhp - this.hp > 50) {
				
				let random = Math.random()*10
				
				for (let i = 0; i<2; i++) {
					for (let j = 0; j<2; j++) {
						
						args = {};
						args.name = "";
						args.speed = 3+random/10;
						args.directioniscircle = "false";
						args.hp = (j == 0) ? 45-random : 2+random;
						args.candie = "true";
						args.canbetouched = "false";
						args.deathaction = 0;
						args.isPlayerShot = "false";
						args.isBonus = "false";
						args.cantbeinstakill = "true";
						args.action = 2401;
						args.sprite = "bonepart1";
						args.width = 0;
						args.height = 0;
						args.collision = [{}];
						args.anchorx = 0;
						args.posx = ((i == 0) ? 370 : 0) + 452+8 + _BH.bhmaxwidth/2;
						args.posy = ((j == 0) ? 76 : 460) + _BH.bhmaxwidth/2;
						args.angle = (j == 0) ? 90 : 270;
						args.collision_angle = "angle";
						args.direction = ((i == 0) ? -90 : 90);
						args.anchorAligned = false;
						this.bones[i].push(_BH.createBHObject(args));
					
					}
				}
			
			}
			
			this.bones[0].filter(x => x.pos.x < 452+8+_BH.bhmaxwidth/2).forEach(x => x.hp = 0);
			this.bones[1].filter(x => x.pos.x > 452+8+370+_BH.bhmaxwidth/2).forEach(x => x.hp = 0);
			
			this.hp -= 1;


    },
};