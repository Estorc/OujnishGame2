module.exports = {
		
    name: 'Wind',
	id: 2647,

    execute (index, _BH) {
		
		
		if (this.begin === 0) {
			
			this.begin = 1;
			
			args = {};
			args.name = "";
			args.speed = 0;
			args.directioniscircle = "false";
			args.hp = this.hp-1;
			args.candie = "true";
			args.canbetouched = "false";
			args.deathaction = 0;
			args.isPlayerShot = "false";
			args.isBonus = "false";
			args.cantbeinstakill = "true";
			args.action = 'Wind';
			args.sprite = "bonepart2";
			
			args.scalex = this.scale.x;
			args.scaley = this.scale.y;
			
			args.width = 0;
			args.height = 0;
			args.collision = [{}];
			
			args.posx = this.pos.x;
			args.posy = this.pos.y+2.5;
			args.angle = this.angle;
			args.direction = this.direction;
			
			args.anchorAligned = false;
			_BH.createBHObject(args);
			
		}
		
		if(typeof this.begin === 'undefined') {
			
			this.begin = 0;
			
		}
		
		this.opacity -= 255/30;
		
		if (this.opacity <= 0) this.hp = 0;

    },
};