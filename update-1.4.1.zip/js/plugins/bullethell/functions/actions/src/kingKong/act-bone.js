module.exports = {
		
    name: 'Bone',
	id: 2402,

    execute (index, _BH) {
		
		
		if(typeof this.begin === 'undefined') {
			
			this.begin = 0;
			
			args = {};
			args.name = "";
			args.speed = 0;
			args.directioniscircle = "false";
			args.hp = this.scale.x;
			args.candie = "true";
			args.canbetouched = "false";
			args.deathaction = 0;
			args.isPlayerShot = "false";
			args.isBonus = "false";
			args.cantbeinstakill = "true";
			args.action = 0;
			args.anchorx = 0;
			args.sprite = "bonepart3";
			
			args.width = 0;
			args.height = 0;
			args.collision = [{}];
			
			args.posx = this.pos.x;
			args.posy = this.pos.y-2;
			args.angle = this.angle;
			args.direction = this.angle-270;
			args.anchorAligned = false;
			args.damage = this.damage;
			args.motionblurFrames = this.motionblurFrames;
			this.bone = _BH.createBHObject(args)
			
		}
		
		this.bone.pos.x = this.pos.x + Math.cos(this.angle * Math.PI / 180)*(6*this.scale.x-3)
		this.bone.pos.y = this.pos.y-2 + Math.sin(this.angle * Math.PI / 180)*(6*this.scale.x-3)
		this.bone.angle = this.angle;
		
		if (this.hp <= 0) this.bone.hp = 0;

    },
};