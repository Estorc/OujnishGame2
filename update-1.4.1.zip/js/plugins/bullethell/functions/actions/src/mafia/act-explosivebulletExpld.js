module.exports = {
		
    name: 'Explosive Bullet Explosion',
	id: 85,

    execute (index, _BH) {
		AudioManager.playSe({name: 'Explosion4', pan: 0, pitch: 150, volume: 100});
		$gameScreen.startShake(5, 5, 10);
		
			args = {};
			args.name = "";
			args.speed = 0;
			args.directioniscircle = "false";
			args.hp = 29;
			args.candie = "true";
			args.canbetouched = "false";
			args.deathaction = 0;
			args.isPlayerShot = "false";
			args.isBonus = "false";
			args.cantbeinstakill = "true";
			args.action = 90;
			args.sprite = 'Explosion@29@1';
			args.width = 0;
			args.height = 0;
			args.offsety = -75+24;
			args.offsetx = -45+24;
			args.posx = this.pos.x;
			args.posy = this.pos.y;
			args.direction = 0;
			args.zindex = 0.5;
			args.collision = [{}];
			args.anchorAligned = false;
			_BH.createBHObject(args)
			
			args = {};
			args.name = "";
			args.speed = 0;
			args.directioniscircle = "false";
			args.hp = 2;
			args.candie = "true";
			args.canbetouched = "false";
			args.deathaction = 0;
			args.isPlayerShot = "false";
			args.isBonus = "false";
			args.cantbeinstakill = "false";
			args.action = 1;
			args.sprite = 'MafiaBulletFlash';
			args.width = 0;
			args.height = 0;
			args.offsety = -64+24;
			args.offsetx = -64+24;
			args.posx = this.pos.x;
			args.posy = this.pos.y;
			args.collision = [{}];
			args.zindex = 15;
			args.anchorAligned = false;
			_BH.createBHObject(args)
		
		this.directionS = (Math.atan2(this.direction.y,this.direction.x) * 180 / Math.PI)+90;
		
		
		for (n=0;n<this.explodePower;n++) {
			
			_BH.createGroundJumpingBullet(this.pos.x,this.pos.y,16,16,2+Math.random()*this.speed,this.directionS-180 + 70-Math.random()*55,'BombBullet',-8,-8,null,86);
		}
		
		for (n=0;n<this.explodePower;n++) {
			
			_BH.createGroundJumpingBullet(this.pos.x,this.pos.y,16,16,2+Math.random()*this.speed,this.directionS-180 + 290+Math.random()*55,'BombBullet',-8,-8,null,86);
		}
    },
};