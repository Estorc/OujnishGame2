module.exports = {
		
    name: 'Mafia 3',
	id: 83,

    execute (index, _BH) {
		if(typeof this.begin === 'undefined') {
			this.timer = 0; 
			this.begin = 0;
		}
			
		
		if (this.pos.x < 640 + 160-48 + $gameBulletHell.bhmaxwidth/2 && this.pos.x > 640 - 160 + $gameBulletHell.bhmaxwidth/2) {
			
				if (this.timer % 20 == 0) {
				
					args = {};
					args.name = "";
					args.speed = 5;
					args.directioniscircle = "false";
					args.hp = 25;
					args.candie = "true";
					args.canbetouched = "false";
					args.deathaction = 85;
					args.isPlayerShot = "false";
					args.isBonus = "false";
					args.cantbeinstakill = "true";
					args.action = 84;
					args.sprite = 'Bomb@4';
					args.width = 48;
					args.height = 48;
					args.offsety = 0;
					args.offsetx = 0;
					args.posx = this.pos.x;
					args.posy = this.pos.y;
					args.direction = 180;
					args.zindex = 5;
					args.collision = [{}];
					args.anchorAligned = false;
					_BH.createBHObject(args)
					
				}
			
			this.timer += 1;
		}
    },
};