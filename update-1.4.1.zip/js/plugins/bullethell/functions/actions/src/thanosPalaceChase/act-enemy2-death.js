module.exports = {
		
    name: 'Death Enemy 2',
	id: 6,

    execute (index, _BH) {
			
		_BH.createFlash();
		
		_BH.spawnBonus("BigBonus", 
						this.pos.x + this.width/2 - 8, 
						this.pos.y + this.height/2 - 8, 
						16, 16, 'BigBonus', 3)
	
    },
};