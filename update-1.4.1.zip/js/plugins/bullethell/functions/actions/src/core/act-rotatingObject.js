module.exports = {
		
    name: 'Rotating Appear Disappear Object',
	id: 71,

    execute (index, _BH) {
		if(typeof this.begin === 'undefined') {

			this.begin = 0;
			this.maxhp = this.hp;
			this.oldCollision = this.collision
			
		}
		
		this.hp -= 1;
		
		if (this.maxhp - this.hp <= 60) {
			
			this.opacity += 255/60;
			if(this.name == 'ppg_finalDoomLaser') {
				this.scale.y += 1/60;
			}
			
		}
		
		if (this.sprite.name == 'ppg_hammerorange' || this.sprite.name == 'tf_hammerorange') {
			switch (_BH.player.hasMove()) {
				
				case true:

					this.collision = [{}];
				
				break;
				
				case false:
				
					this.collision = this.oldCollision;
				
				break;
				
			}
		}
		
		if (this.sprite.name == 'ppg_hammerblue' || this.sprite.name == 'tf_hammerblue') {
			switch (_BH.player.hasMove()) {
			
				case true:

					this.collision = this.oldCollision;
				
				break;
				
				case false:
				
					this.collision = [{}];
				
				break;
			
			}
		}
		
		if (this.hp <= 60) {
			
			this.opacity -= 255/60;
			if(this.name == 'ppg_finalDoomLaser') {
				this.scale.y -= 1/60;
			}
			
		}
    },
};