module.exports = {
		
    name: 'Lose Life progressively',
	id: 1,

    execute (index, _BH) {
		this.hp -= 1;
    },
};