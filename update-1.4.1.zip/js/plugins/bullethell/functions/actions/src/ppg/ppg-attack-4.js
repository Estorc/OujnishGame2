module.exports = {
		
    name: 'PPG Attack 4',
	id: 54,

    execute (index, _BH) {
		
			if (_BH.player.hasMove()) Math.random();
		
			if(typeof this.begin === 'undefined') {

				_BH.player.pos.x = 640-36/2;
				_BH.player.pos.y = 500;
				this.scene.swapSoul("blue");
				this.maxhp = this.hp;
				this.begin = 0;
				
			}

			
			this.hp -= 1;
			
			if (this.hp % 60 == 0) {
				
				AudioManager.playSe({name: 'Raise3', pan: 0, pitch: 150, volume: 100});
				
				_BH.createTopHatBunny(Math.random()*300 + _BH.bhmaxheight/2,Math.floor(Math.random()*2),20,60)
				
			}
			
			if (this.hp % 480 == 0) {
			
			_BH.createTopHatLetter(1280 - 494 + _BH.bhmaxwidth/2,20,60)
			
			}
			else if (this.hp % 240 == 0) {
				
			_BH.createTopHatLetter(494 + _BH.bhmaxwidth/2,20,60)
			
			}
    },
};