module.exports = {
		
    name: 'PPG Attack 12',
	id: 62,

    execute (index, _BH) {
				
			if (_BH.player.hasMove()) Math.random();

			if(typeof this.begin === 'undefined') {

				_BH.player.pos.x = 640-36/2;
				_BH.player.pos.y = 500;
				this.scene.swapSoul("yellow");
				this.maxhp = this.hp;
				this.begin = 0;
				this.scene.soulDirection = 4;
				_BH.createLaytonMobile(_BH.bhmaxheight/2+200,100)

				
			}
			
			
			if (!_BH.getObjectByName("LaytonMobile") && this.hp > 120) {
				
				this.hp = 120;
				
			}
			
			
			this.hp -= 1;
    },
};