module.exports = {
		
    name: 'Gaster Blaster Laser',
	id: 33,

    execute (index, _BH) {
		if(typeof this.begin === 'undefined') {

			AudioManager.playSe({name: 'ppg_gasterblasterlaser', pan: 0, pitch: 100, volume: 100});
			this.begin = 0;
			
		}

		this.begin += 1;

		if (this.begin < 10) {
			
			this.scale.y += 1/10
			this.opacity += 255/10
			
		}
					
		if (this.begin > 18) {
			
			this.scale.y -= 1/20
			this.opacity -= 255/10
			
			if (this.opacity <= 0) {
			
				this.candie = true;
				this.hp = 0;
				
			}
			
		}
    },
};