//=============================================================================
// RPG Maker MZ - EnemiesMoreMetas
//=============================================================================

/*:
 * @target MZ
 * @plugindesc Enemies More Metas system plugin.
 * @author Feather
 *
 * @help 
 * Enemies More Metas system plugin.
 *
 */
 

(() => {
    const pluginName = "EnemiesMoreMetas";
	
	
	___FeatherEMM___Game_Battler_refresh = Game_Battler.prototype.refresh;
	Game_Battler.prototype.refresh = function() {

		if(this.isEnemy() && this.enemy().meta.InfTP || this.isActor() && this.actor().meta.InfTP) {
			this._tp = 100;
		}	
		
		if(this.isEnemy() && this.enemy().meta.InfUT || this.isActor() && this.actor().meta.InfUT) {
			this._ut = 20;
		}

		
		___FeatherEMM___Game_Battler_refresh.call(this);
	};

})();
