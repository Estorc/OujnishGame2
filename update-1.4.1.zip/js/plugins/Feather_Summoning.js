//=============================================================================
// RPG Maker MZ - Summoning
//=============================================================================

/*:
 * @target MZ
 * @plugindesc Summoning system plugin.
 * @author Feather
 *
 * @help 
 * Summoning system plugin.
 *
 */
 

(() => {
    const pluginName = "Feather_Summoning";
	
	___FeatherS___Sprite_Battler_checkBattler = Sprite_Battler.prototype.checkBattler;
	Sprite_Battler.prototype.checkBattler = function(battler) {
		if (battler.hasSummons()) {
			return this._battler === battler || this._battler === battler._summoner || battler._summons.array.some(a => a === this._battler);
		}
		else return ___FeatherS___Sprite_Battler_checkBattler.call(this, battler);
	};
	
	___FeatherS___Game_Action_applyItemEffect = Game_Action.prototype.applyItemEffect;
	Game_Action.prototype.applyItemEffect = function(target, effect) {
		___FeatherS___Game_Action_applyItemEffect.call(this,target,effect);
		switch (effect.code) {
			case 'spawnSummon':
				this.itemEffectSpawnSummon(target, effect);
				break;
		}
	};
	
	
	Game_Action.prototype.itemEffectSpawnSummon = function(target, effect) {
		target.addSummon($gameActors.actor(effect.dataId), 0, false, effect.value1, false, effect.value2);
	};
	
	
	Game_BattlerBase.prototype.spMax = function() {
		return eval(this.currentClass && this.currentClass().meta.MaxSummons || 0) + eval(this.actor && this.actor().meta.MaxSummons || 0) + this.allTraits().reduce((a,b) => a + (b.code === 'increaseMaxSummons') * b.value, 0);
	};
	
	Game_BattlerBase.prototype.setSp = function(sp) {
		this._sp = sp;
		this.refresh();
	};
	
	Game_BattlerBase.prototype.SpCost = function(skill) {
		// Declare Variables
		const user = this;
		let cost = 0;

		// Calculations
		const note = skill.note;
		if (note.match(/<SP COST:[ ](\d+)>/i)) {
			cost += Number(RegExp.$1);
		}
		if (note.match(/<SP COST:[ ](\d+)([%％])>/i)) {
			cost += Math.ceil(Number(RegExp.$1) * user._sp / 100);
		}
		if (note.match(/<JS SP COST>\s*([\s\S]*)\s*<\/JS SP COST>/i)) {
			const code = String(RegExp.$1);
			eval(code);
		}

		// Apply Trait Cost Alterations
		if (cost > 0) {
			const rateNote = /<SP COST:[ ](\d+\.?\d*)([%％])>/i;
			const rates = user.traitObjects().map((obj) => (obj && obj.note.match(rateNote) ? Number(RegExp.$1) / 100 : 1));
			const flatNote = /<SP COST:[ ]([\+\-]\d+)>/i;
			const flats = user.traitObjects().map((obj) => (obj && obj.note.match(flatNote) ? Number(RegExp.$1) : 0));
			cost = rates.reduce((r, rate) => r * rate, cost);
			cost = flats.reduce((r, flat) => r + flat, cost);
			cost = Math.max(1, cost);
		}

		// Set Cost Limits
		if (note.match(/<SP COST MAX:[ ](\d+)>/i)) {
			cost = Math.min(cost, Number(RegExp.$1));
		}
		if (note.match(/<SP COST MIN:[ ](\d+)>/i)) {
			cost = Math.max(cost, Number(RegExp.$1));
		}

		// Return cost value
		return Math.round(Math.max(0, cost));
	}
	
	
	
	
	___FeatherS___Game_Battler_onBattleStart = Game_Battler.prototype.onBattleStart;
	Game_Battler.prototype.onBattleStart = function(advantageous) {
		___FeatherS___Game_Battler_onBattleStart.call(this, advantageous);
		this.setSp(this.spMax());
		this._summons = {array:[],index:-1};
		this._summoner = null;
	};
	
	___FeatherS___Game_Battler_onBattleEnd = Game_Battler.prototype.onBattleEnd;
	Game_Battler.prototype.onBattleEnd = function() {
		___FeatherS___Game_Battler_onBattleEnd.call(this);
		this._summons.array = [];
	};
	
	Game_Battler.prototype.hasSummons = function() {
		return this._summons && this._summons.array.length;
	};
	
	Game_Battler.prototype.isSummon = function() {
		return this._summons.index >= 0;
	}
	
	Game_Battler.prototype.summoner = function() {
		return this._summoner || this;
	}
	
	Game_Battler.prototype.getSummon = function() {
		if (!this.isSummon()) return this.summoner();
		return this._summons.array[this._summons.index];
	}
	
	Game_Battler.prototype.addSummon = function(summon, stateId, protectOthers, cost, permanent, callback) {
		if (!this._summons.array.some(a => a._actorId === summon._actorId)) {
			summon = new Game_Actor(summon._actorId);
			/*summon._actions = [];
			summon._skills = [];
			summon._equips = [];
			summon._states = [];
			summon.setup(summon._actorId);*/
			summon.changeLevel(this.level);
			summon.recoverAll();
			Game_Battler.prototype.onBattleStart.call(summon);
			summon._summons = this._summons;
			summon._summoner = this.summoner();
			summon._isSummon = true;
			summon._summonStateId = stateId;
			summon._protectOthers = protectOthers;
			summon._cost = cost;
			summon._isPermanent = permanent;
			if (callback) summon = callback(summon);
			this._summons.array.push(summon);
		}
	}
	
	Game_Battler.prototype.removeSummon = function(summon) {
		const foundSummon = this._summons.array.find(a => a._summonId === summon._summonId);
		if (foundSummon && !foundSummon._isPermanent) {
			this._sp += foundSummon._cost;
			this._summons.array = this._summons.array.filter(a => a._summonId !== summon._summonId);
			this.removeState(foundSummon._summonStateId);
		}
	}
	
	Game_Battler.prototype.removeAllSummons = function() {
		this._summons.array.forEach(item => this.removeSummon(item), this);
	}
	
	___FeatherS___Game_BattlerBase_isDeathStateAffected = Game_BattlerBase.prototype.isDeathStateAffected;
	Game_BattlerBase.prototype.isDeathStateAffected = function() {
		return ___FeatherS___Game_BattlerBase_isDeathStateAffected.call(this) && !this._isSummon;
	};
	
	___FeatherS___BattleManager_changeCurrentActor = BattleManager.changeCurrentActor;
	BattleManager.changeCurrentActor = function(forward) {
		const members = $gameParty.battleMembers();
		const actor = this._currentActor;
		const currentIndex = members.indexOf(actor);
		//if (!forward) members[currentIndex-1]._summons.index = members[currentIndex-1]._summons.array.length;
		if (actor && actor.hasSummons()) {
			const actorId = actor.index();
			const switchedToSummoner = actor.switchSummon(forward);
			this._currentActor = $gameParty.battleMembers()[actorId];
			this.startActorInput();
			BattleManager._spriteset._actorSprites.forEach(a => a.update());
			if (!switchedToSummoner) return 0;
		}
		return ___FeatherS___BattleManager_changeCurrentActor.call(this,forward);
	};
	
	___FeatherS___Game_Action_setSubject = Game_Action.prototype.setSubject;
	Game_Action.prototype.setSubject = function(subject) {
		this._summonSubject = (subject._isSummon ? subject : null)
		___FeatherS___Game_Action_setSubject.call(this, subject);
	};
	
	___FeatherS___Game_Action_subject = Game_Action.prototype.subject;
	Game_Action.prototype.subject = function() {
		return (this._summonSubject ? this._summonSubject : ___FeatherS___Game_Action_subject.call(this));
	};
	
	
	___FeatherS___Game_Action_repeatTargets = Game_Action.prototype.repeatTargets;
	Game_Action.prototype.repeatTargets = function(targets) {
		const newTargets = targets.map(a => {
			if (a && a.hasSummons()) {
				if (this.isForFriend()) return a;
				if (a._summons.array.some(b => b._protectOthers)) return a.filter(b => b._protectOthers)[(Math.random()*a.filter(b => b._protectOthers).length)<<0];
				if (Math.random() < 0.5) return a;
				return a._summons.array[(Math.random()*a._summons.array.length)<<0];
			}
			return a;
		}, this);
		return ___FeatherS___Game_Action_repeatTargets.call(this,newTargets);
	};
	
	___FeatherS___Window_BattleLog_showAnimation = Window_BattleLog.prototype.showAnimation;
	Window_BattleLog.prototype.showAnimation = function(
		subject, targets, animationId
	) {
		targets.forEach(target => {
			if (target.hasSummons()) {
				console.log(target._summons.index);
				$gameParty._actors[target.getSummon().index()] = target;
				target._summons.index = target._summons.array.indexOf(target);
				BattleManager._spriteset._actorSprites.forEach(a => a.update());
				//BattleManager.displayBattlerStatus(target, true);
				$gameTemp.requestBattleRefresh();
				console.log(target._summons.index);
			}
		})
		___FeatherS___Window_BattleLog_showAnimation.call(this, subject, targets, animationId);
	};
	
	/*___FeatherS___Game_Action_testApply = Game_Action.prototype.testApply;
	Game_Action.prototype.testApply = function(target) {
		if (target._isSummon && this.testApply(target._summoner)) {
			target._summons.index = target._summons.array.indexOf(target);
			$gameParty._actors[target._summoner.index()] = target;
			BattleManager._spriteset._actorSprites.forEach(a => a.update());
			BattleManager.displayBattlerStatus(target, true);
		}
		return ___FeatherS___Game_Action_testApply.call(this,target);
	};*/
	
	___FeatherS___Sprite_Battler_update = Sprite_Battler.prototype.update;
	Sprite_Battler.prototype.update = function() {
		if (this._battler && this._battler.hasSummons())
			if (this._battler._summons.index >= 0) this.setBattler(this._battler._summons.array[this._battler._summons.index]);
			else this.setBattler(this._battler._summoner);
		___FeatherS___Sprite_Battler_update.call(this);
	};
	
	___FeatherS___Game_Actors_actor = Game_Actors.prototype.actor;
	Game_Actors.prototype.actor = function(actor) {
		if (typeof actor !== 'number') return actor;
		return ___FeatherS___Game_Actors_actor.call(this, actor);
	};
	
	Game_Actor.prototype.switchToSummoner = function() {
		$gameParty._actors[this.index()] = this.summoner().actorId();
		this.summoner()._summons.index = -1;
	}
	
	Game_Actor.prototype.switchSummon = function(forward) {
		this._summons.index += forward ? 1 : -1;
		if (this._summons.index >= 0 && this._summons.index < this._summons.array.length)
			$gameParty._actors[this.index()] = this._summons.array[this._summons.index];
		else this.switchToSummoner();
		return this._summons.index == -1;
	}
	
	___FeatherS___BattleManager_endAction = BattleManager.endAction;
	BattleManager.endAction = function() {
		const subject = this._subject;
		___FeatherS___BattleManager_endAction.call(this);
		if (subject.hasSummons() && subject.numActions() === 0) {
			if (subject._summons.index < subject._summons.array.length-1)
				this._subject = subject;
			else {
				subject._summons.index = -1;
				subject.switchToSummoner();
				this.displayBattlerStatus(subject, true);
				$gameTemp.requestBattleRefresh();
			}
		}
	};
	
	___FeatherS___BattleManager_processTurn = BattleManager.processTurn
	BattleManager.processTurn = function() {
		let subject = this._subject;
		while (!subject.currentAction() && subject.hasSummons() && subject._summons.index < subject._summons.array.length-1) {
			subject._summons.index++;
			const index = subject.index();
			$gameParty._actors[index] = subject._summons.array[subject._summons.index];
			this._subject = $gameActors.actor($gameParty._actors[index]);
			$gameTemp.requestBattleRefresh();
			subject = this._subject;
		}
		___FeatherS___BattleManager_processTurn.call(this);
	};

	___FeatherS___BattleManager_endTurn = BattleManager.endTurn
	BattleManager.endTurn = function() {
		___FeatherS___BattleManager_endTurn.call(this);
		$gameParty._actors.forEach(actor => {
			
			if (typeof actor !== 'number') {
				if (actor.hasSummons()) {
					actor.switchToSummoner();
					actor._summons.array.forEach(a => a.isStateAffected(a.deathStateId()) && a._summoner.removeSummon(a));
				}
			} else {
				const _actor = $gameActors.actor(actor)
				if (_actor.hasSummons()) _actor._summons.array.forEach(a => a.isStateAffected(a.deathStateId()) && a._summoner.removeSummon(a));
			}
			$gameTemp.requestBattleRefresh();
				
		})
	};

})();
