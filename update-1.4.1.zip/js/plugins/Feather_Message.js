//=============================================================================
// RPG Maker MZ - Message
//=============================================================================

/*:
 * @target MZ
 * @plugindesc Message system plugin.
 * @author Feather
 *
 * @help 
 * Message system plugin.
 *
 */
 

(() => {
    const pluginName = "Feather_Message";
	NUMBER_OF_MAP = 349;
	
	FeatherMessage = function() {
		throw new Error("This is a static class");
	};
	
	
	FeatherMessage.allMessages = {};
	
	FeatherMessage.searchForMessage = function(_map,_mapID,src) {
		
		for (const item of _map.events.filter(a => a && a.pages)) {   
			for (let lists of item.pages) {
				let _list = lists.list.filter(a => a.code == 401 || a.code == 101);
				
				let lastID = 0;
				let nextTextID = _list.findIndex(a => a.code == 101);
				
				while (nextTextID != -1) {
				
					let nextText = _list.find(a => a.code == 101);
					_list.splice(_list.indexOf(nextText), 1);
					
					nextTextID = _list.findIndex(a => a.code == 101);
					
					let _text = ((nextTextID == -1) ? _list.slice(lastID) : _list.slice(lastID,nextTextID)).map(a => a.parameters);
					if (_text.length > 0) {
						this.allMessages[`M${_mapID}/E${item.id}N${item.pages.indexOf(lists)}UN${lastID}`] = {name:nextText.parameters[4],text:_text};
						
						let id = lists.list.indexOf(nextText)+1;
						
						lists.list[id].parameters = [`\\TextSymbol{M${_mapID}/E${item.id}N${item.pages.indexOf(lists)}UN${lastID}}`];
						console.log(lists.list[id-1].code);
						while (lists.list[id+1] && lists.list[id+1].code == 401) { 
							console.log(lists.list.splice(id + 1, 1));
						}
					}
					
					lastID = nextTextID;
					
				}
				
			}
			for (let lists of item.pages) {
			for (let indent = 0; indent < 20; indent++) {
				
				let _list = lists.list.filter(a => (a.code == 402 || a.code == 102) && a.indent == indent);
				
				let lastID = 0;
				let nextTextID = _list.findIndex(a => a.code == 102);
				
				while (nextTextID != -1) {
				
					let nextText = _list.find(a => a.code == 102);
					_list.splice(_list.indexOf(nextText), 1);
					
					nextTextID = _list.findIndex(a => a.code == 102);
					
					let _text = ((nextTextID == -1) ? _list.slice(lastID) : _list.slice(lastID,nextTextID)).map(a => a.parameters);
					console.log(_text);
					if (_text.length > 0) {
						for (const choice of nextText.parameters[0]) {
							
							this.allMessages[`CHOICEID${nextText.parameters[0].indexOf(choice)}/M${_mapID}/E${item.id}N${item.pages.indexOf(lists)}UN${lastID}`] = choice;
							let index = nextText.parameters[0].indexOf(choice);
							nextText.parameters[0][index] = `\\TextSymbol{CHOICEID${nextText.parameters[0].indexOf(choice)}/M${_mapID}/E${item.id}N${item.pages.indexOf(lists)}UN${lastID}}`
							lists.list[lists.list.indexOf(_list[lastID+index])].parameters[1] = nextText.parameters[0][index];
						
						}
					}
					
					lastID = nextTextID;
					
				}
				
			}
			}
		}

		this.saveMap(_map,src);
		
	}
	
	
	FeatherMessage.searchForMessageCommonEvent = function() {
		
		for (const item of $dataCommonEvents.filter(a => a)) {   
			let _list = item.list.filter(a => a.code == 401 || a.code == 101);
			
			let lastID = 0;
			let nextTextID = _list.findIndex(a => a.code == 101);
			
			while (nextTextID != -1) {
			
				let nextText = _list.find(a => a.code == 101);
				_list.splice(_list.indexOf(nextText), 1);
				
				nextTextID = _list.findIndex(a => a.code == 101);
				
				let _text = ((nextTextID == -1) ? _list.slice(lastID) : _list.slice(lastID,nextTextID)).map(a => a.parameters);
				if (_text.length > 0) {
					this.allMessages[`CME${$dataCommonEvents.indexOf(item)}UN${lastID}`] = {name:nextText.parameters[4],text:_text};
					
					let id = item.list.indexOf(nextText)+1;
					
					item.list[id].parameters = [`\\TextSymbol{CME${$dataCommonEvents.indexOf(item)}UN${lastID}}`];
					console.log(item.list[id-1].code);
					while (item.list[id+1] && item.list[id+1].code == 401) { 
						console.log(item.list.splice(id + 1, 1));
					}
				}
				
				lastID = nextTextID;
				
			}
			
			
			
			for (let indent = 0; indent < 20; indent++) {
				
				let _list = item.list.filter(a => (a.code == 402 || a.code == 102) && a.indent == indent);
				
				let lastID = 0;
				let nextTextID = _list.findIndex(a => a.code == 102);
				
				while (nextTextID != -1) {
				
					let nextText = _list.find(a => a.code == 102);
					_list.splice(_list.indexOf(nextText), 1);
					
					nextTextID = _list.findIndex(a => a.code == 102);
					
					let _text = ((nextTextID == -1) ? _list.slice(lastID) : _list.slice(lastID,nextTextID)).map(a => a.parameters);
					console.log(_text);
					if (_text.length > 0) {
						for (const choice of nextText.parameters[0]) {
							
							this.allMessages[`CHOICEID${nextText.parameters[0].indexOf(choice)}/CME${$dataCommonEvents.indexOf(item)}UN${lastID}`] = choice;
							let index = nextText.parameters[0].indexOf(choice);
							nextText.parameters[0][index] = `\\TextSymbol{CHOICEID${nextText.parameters[0].indexOf(choice)}/CME${$dataCommonEvents.indexOf(item)}UN${lastID}}`
							item.list[item.list.indexOf(_list[lastID+index])].parameters[1] = nextText.parameters[0][index];
						}
					}
					
					lastID = nextTextID;
					
				}
				
			}
		}
	
		fs.writeFile("newMap/CommonEvents.json", JSON.stringify($dataCommonEvents), function(err) {
			if (err) {
				console.log(err);
			}
		});
		
	}
	
	
	FeatherMessage.searchForMessageTroops = function() {
		
		for (const item of $dataTroops.filter(a => a)) {   
			for (let lists of item.pages) {
				let _list = lists.list.filter(a => a.code == 401 || a.code == 101);
				
				let lastID = 0;
				let nextTextID = _list.findIndex(a => a.code == 101);
				
				while (nextTextID != -1) {
				
					let nextText = _list.find(a => a.code == 101);
					_list.splice(_list.indexOf(nextText), 1);
					
					nextTextID = _list.findIndex(a => a.code == 101);
					
					let _text = ((nextTextID == -1) ? _list.slice(lastID) : _list.slice(lastID,nextTextID)).map(a => a.parameters);
					if (_text.length > 0) {
						this.allMessages[`T${item.id}N${item.pages.indexOf(lists)}UN${lastID}`] = {name:nextText.parameters[4],text:_text};
						
						let id = lists.list.indexOf(nextText)+1;
						
						lists.list[id].parameters = [`\\TextSymbol{T${item.id}N${item.pages.indexOf(lists)}UN${lastID}}`];
						console.log(lists.list[id-1].code);
						while (lists.list[id+1] && lists.list[id+1].code == 401) { 
							console.log(lists.list.splice(id + 1, 1));
						}
					}
					
					lastID = nextTextID;
					
				}
				
			}
			for (let lists of item.pages) {
			for (let indent = 0; indent < 20; indent++) {
				
				let _list = lists.list.filter(a => (a.code == 402 || a.code == 102) && a.indent == indent);
				
				let lastID = 0;
				let nextTextID = _list.findIndex(a => a.code == 102);
				
				while (nextTextID != -1) {
				
					let nextText = _list.find(a => a.code == 102);
					_list.splice(_list.indexOf(nextText), 1);
					
					nextTextID = _list.findIndex(a => a.code == 102);
					
					let _text = ((nextTextID == -1) ? _list.slice(lastID) : _list.slice(lastID,nextTextID)).map(a => a.parameters);
					console.log(_text);
					if (_text.length > 0) {
						for (const choice of nextText.parameters[0]) {
							
							this.allMessages[`CHOICEID${nextText.parameters[0].indexOf(choice)}/T${item.id}N${item.pages.indexOf(lists)}UN${lastID}`] = choice;
							let index = nextText.parameters[0].indexOf(choice);
							nextText.parameters[0][index] = `\\TextSymbol{CHOICEID${nextText.parameters[0].indexOf(choice)}/T${item.id}N${item.pages.indexOf(lists)}UN${lastID}}`
							lists.list[lists.list.indexOf(_list[lastID+index])].parameters[1] = nextText.parameters[0][index];
						
						}
					}
					
					lastID = nextTextID;
					
				}
				
			}
			}
		}
	
		fs.writeFile("newMap/Troops.json", JSON.stringify($dataTroops), function(err) {
			if (err) {
				console.log(err);
			}
		});
		
	}
	
	
	FeatherMessage.saveMap = function(_map,src) {
		
		fs.writeFile("newMap/"+src, JSON.stringify(_map), function(err) {
			if (err) {
				console.log(err);
			}
		});
		
	}
	
	
	FeatherMessage.onGetAllMessageLoad = function(xhr, name, src, url,id) {
		if (xhr.status < 400) {
			window[name] = JSON.parse(xhr.responseText);
			DataManager.extractMetadata(window[name]);
			DataManager.extractArrayMetadata(window[name].events);
			this.searchForMessage(window[name],id,src);
		} else {
			DataManager.onXhrError(name, src, url);
		}
	}
	
	
	FeatherMessage.getAllMessage = function() {

		for (let i = 1; i<=NUMBER_OF_MAP; i++) {

			const xhr = new XMLHttpRequest();
			const src = "Map%1.json".format((i).padZero(3));
			const url = "data/" + src;
			window["mapExplore"] = null;
			xhr.open("GET", url);
			xhr.overrideMimeType("application/json");
			xhr.onload = () => this.onGetAllMessageLoad(xhr, "mapExplore", src, url,i);
			xhr.onerror = () => DataManager.onXhrError("mapExplore", src, url);
			xhr.send();

		}
		
		this.searchForMessageCommonEvent();
		this.searchForMessageTroops();

	}
	
	
	FeatherMessage.LangXHRonLoad = function(xhr) {
		
		if (xhr.status < 400) {
			
			this.allMessages = JSON.parse(xhr.responseText);
			
		}
		
	}
	
	
	FeatherMessage.loadLang = function(lang) {

			const xhr = new XMLHttpRequest();
			const src = `languages/${lang}.json`;
			const url = "data/" + src;
			xhr.open("GET", url);
			xhr.overrideMimeType("application/json");
			xhr.onload = () => this.LangXHRonLoad(xhr);
			xhr.send();

	}
	
	
	FeatherMessage.replaceChoice = function(text) {
		
		return text.map(a => a.replace(/\\TextSymbol\{(.*?)\}/g, (s, n) => this.allMessages[n]));
		
	}
	
	FeatherMessage.replaceText = function(text, id = 0) {
		
		return text.replace(/\\TextSymbol\{(.*?)\}/g, (s, n) => {
	
			text = this.replaceTextArray(this.allMessages[n]);
			console.log(text);
			return text
		
		});
		
	}
	
	FeatherMessage.replaceTextArray = function(textsArray, id = 0) {
		console.log(textsArray);
		if (!textsArray || !textsArray.text) {
			return "IAM ERROR"
		}
		let text = textsArray.text;
		if (id+1 < text.length) {
			return text[id][0] + "\n" + this.replaceTextArray(textsArray,id+1);
		} else {
			if (textsArray.name) {
				FeatherMessage.replaceText(textsArray.name);
			}
			return text[id][0]
		}
		
	}
	
	
	___FeatherM___Game_Message_add = Game_Message.prototype.add;
	Game_Message.prototype.add = function(text) {
		
		return ___FeatherM___Game_Message_add.call(this,FeatherMessage.replaceText(text));
		
	}
	
	___FeatherM___Game_Message_setChoices = Game_Message.prototype.setChoices;
	Game_Message.prototype.setChoices = function(choices, defaultType, cancelType) {
		
		return ___FeatherM___Game_Message_setChoices.call(this,FeatherMessage.replaceChoice(choices),defaultType, cancelType);
		
	}
	
	FeatherMessage.loadLang("original_fr");


})();
