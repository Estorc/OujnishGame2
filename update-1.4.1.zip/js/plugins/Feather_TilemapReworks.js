//=============================================================================
// RPG Maker MZ - TileMapReworks
//=============================================================================

/*:
 * @target MZ
 * @plugindesc Tile Map Reworks system plugin.
 * @author Feather
 *
 * @help 
 * Tile Map Reworks system plugin.
 *
 */
 

(() => {
    const pluginName = "Feather_TileMapReworks";
	const ADAPTATIVE_STARTILE_REGION = 248;
	const BRIDGE_OFF_REGION = 249;
	const BRIDGE_ON_REGION = 250;
	const BRIDGE_REGION = 251;
	
	$dataMap = {};
	
	
	
	Tilemap.prototype._getUpperLayersLength = function() {
		
		return Graphics.height/this.tileHeight+2;
		
	}
	
	Tilemap.prototype._createLayers = function() {
		/*
		 * [Z coordinate]
		 *  0 : Lower tiles
		 *  1 : Lower characters
		 *  3 : Normal characters
		 *  4 : Upper tiles
		 *  5 : Upper characters
		 *  6 : Airship shadow
		 *  7 : Balloon
		 *  8 : Animation
		 *  9 : Destination
		 */
		this._lowerLayer = new Tilemap.Layer();
		this._lowerLayer.z = 0;
		this.addChild(this._lowerLayer);
		this._upperLayers = [];
		for (let i = 0; i < this._getUpperLayersLength();i++) {
			let layer = new Tilemap.Layer();
			layer.z = 3;
			this._upperLayers.push(layer);
			this.addChild(layer);
		}
		this._needsRepaint = true;
	};
	
	
	Tilemap.prototype._addAllSpots = function(startX, startY) {
		this._lowerLayer.clear();
		this._upperLayers.forEach(item => item.clear());
		const widthWithMatgin = this.width + this._margin * 2;
		const heightWithMatgin = this.height + this._margin * 2;
		const tileCols = Math.ceil(widthWithMatgin / this.tileWidth) + 1;
		const tileRows = Math.ceil(heightWithMatgin / this.tileHeight) + 1;
		for (let y = 0; y < tileRows; y++) {
			for (let x = 0; x < tileCols; x++) {
				this._addSpot(startX, startY, x, y);
			}
		}
	};
	
	
	Tilemap.prototype._addSpot = function(startX, startY, x, y) {
		const mx = startX + x;
		const my = startY + y;
		const dx = x * this.tileWidth;
		const dy = y * this.tileHeight;
		const tileId0 = this._readMapData(mx, my, 0);
		const tileId1 = this._readMapData(mx, my, 1);
		const tileId2 = this._readMapData(mx, my, 2);
		const tileId3 = this._readMapData(mx, my, 3);
		const shadowBits = this._readMapData(mx, my, 4);
		const upperTileId1 = this._readMapData(mx, my - 1, 1);
		
		this._upperLayers[(dy / this.tileWidth<<0)].z = 3 + my / 1000;

		this._addSpotTile(tileId0, dx, dy, mx, my, 0);
		this._addSpotTile(tileId1, dx, dy, mx, my, 1);
		this._addShadow(this._lowerLayer, shadowBits, dx, dy);
		if (this._isTableTile(upperTileId1) && !this._isTableTile(tileId1)) {
			if (!Tilemap.isShadowingTile(tileId0)) {
				this._addTableEdge(this._lowerLayer, upperTileId1, dx, dy);
			}
		}
		if (this._isOverpassPosition(mx, my)) {
			if (this._readMapData(mx,my,5) === ADAPTATIVE_STARTILE_REGION) {
				let i = 0;
				while (this._readMapData(mx,my+i+1,5) === ADAPTATIVE_STARTILE_REGION) i++;
				this._addTile(this._upperLayers[Math.min((dy / this.tileWidth<<0)+i, this._getUpperLayersLength()-1)], tileId2, dx, dy);
				this._addTile(this._upperLayers[Math.min((dy / this.tileWidth<<0)+i, this._getUpperLayersLength()-1)], tileId3, dx, dy);
			} else {
				this._addTile(this._upperLayers[this._getUpperLayersLength()-1], tileId2, dx, dy);
				this._addTile(this._upperLayers[this._getUpperLayersLength()-1], tileId3, dx, dy);
			}
		} else {
			this._addSpotTile(tileId2, dx, dy, mx, my, 2);
			this._addSpotTile(tileId3, dx, dy, mx, my, 3);
		}
	};
	
	
	Tilemap.prototype._addSpotTile = function(tileId, dx, dy, mx, my, id) {
		
		if ($gameMap.bridgeActive() && this._readMapData(mx,my,5) === BRIDGE_REGION+id) {
			this._addTile(this._upperLayers[this._getUpperLayersLength()-1], tileId, dx, dy);
		} else {
			if (this._isHigherTile(tileId)) {
				if (this._readMapData(mx,my,5) === ADAPTATIVE_STARTILE_REGION) {
					let i = 0;
					while (this._readMapData(mx,my+i+1,5) === ADAPTATIVE_STARTILE_REGION) i++;
					this._addTile(this._upperLayers[Math.min((dy / this.tileWidth<<0)+i, this._getUpperLayersLength()-1)], tileId, dx, dy);
				}
				else
					this._addTile(this._upperLayers[this._getUpperLayersLength()-1], tileId, dx, dy);
			} else {
				this._addTile(this._lowerLayer, tileId, dx, dy);
			}
		}
	}
	
	
	Tilemap.prototype.updateTransform = function() {
		const ox = Math.ceil(this.origin.x);
		const oy = Math.ceil(this.origin.y);
		const startX = Math.floor((ox - this._margin) / this.tileWidth);
		const startY = Math.floor((oy - this._margin) / this.tileHeight);
		this._lowerLayer.x = startX * this.tileWidth - ox;
		this._lowerLayer.y = startY * this.tileHeight - oy;
		this._upperLayers.forEach(item => {
			item.x = startX * this.tileWidth - ox;
			item.y = startY * this.tileHeight - oy;
		});
		if (
			this._needsRepaint ||
			this._lastAnimationFrame !== this.animationFrame ||
			this._lastStartX !== startX ||
			this._lastStartY !== startY
		) {
			this._lastAnimationFrame = this.animationFrame;
			this._lastStartX = startX;
			this._lastStartY = startY;
			this._addAllSpots(startX, startY);
			this._needsRepaint = false;
		}
		this._sortChildren();
		PIXI.Container.prototype.updateTransform.call(this);
	};
	
	
	Game_CharacterBase.prototype.screenZ = function() {
		return this._priorityType * 2 + 1 + (this._priorityType === 1 ? (this.y-1)/1000 : 0);
	};
	
	
	___FeatherTR___Game_Map_initialize = Game_Map.prototype.initialize;
	Game_Map.prototype.initialize = function() {
		___FeatherTR___Game_Map_initialize.call(this);
		this._bridgeActive = false;
	}
	
	Game_Map.prototype.bridgeActive = function() {
		return this._bridgeActive;
	};
	
	___FeatherTR___Game_Player_executeMove = Game_Player.prototype.executeMove;
	Game_Player.prototype.executeMove = function(direction) {
		___FeatherTR___Game_Player_executeMove.call(this, direction);
		if ($gameMap.tileId(this.x, this.y, 5) === BRIDGE_ON_REGION) $gameMap._bridgeActive = true;
		if ($gameMap.tileId(this.x, this.y, 5) === BRIDGE_OFF_REGION) $gameMap._bridgeActive = false;
	}
	
	Game_Map.prototype.checkPassage = function(x, y, bit) {
		const flags = this.tilesetFlags();
		const tiles = this.allTiles(x, y);
		for (const tile of tiles) {
			const flag = flags[tile];
			if (this.bridgeActive() && this.tileId(x, y, 5) === BRIDGE_REGION+3-tiles.indexOf(tile)) {
				// [-] Bridge
				continue;
			}
			if ((flag & 0x10) !== 0) {
				// [*] No effect on passage
				continue;
			}
			if ((flag & bit) === 0) {
				// [o] Passable
				return true;
			}
			if ((flag & bit) === bit) {
				// [x] Impassable
				return false;
			}
		}
		return false;
	};


	
})();
