//=============================================================================
// RPG Maker MZ - VisibleEquipment
//=============================================================================

/*:
 * @target MZ
 * @plugindesc Visible Equipment system plugin.
 * @author Feather
 *
 * @help 
 * Visible Equipment system plugin.
 *
 */
 

(() => {
    const pluginName = "Visible Equipment";
	
	
	___FeatherVE___Sprite_Character_updateCharacterFrame = Sprite_Character.prototype.updateCharacterFrame
	Sprite_Character.prototype.updateCharacterFrame = function() {
			
		const haveEquip = this._character.getActor() && !(this._character.getActor().actor().meta.EquipmentSpritePrefix && this._character.getActor().actor().meta.EquipmentSpritePrefix.trim() === 'null');
			
		if (haveEquip) {
			this.createBackCostumeSprite();
		}
		
		___FeatherVE___Sprite_Character_updateCharacterFrame.call(this);
		
		if (haveEquip) {
			
			const pw = this._frame.width;
			const ph = this._frame.height;
			const sx = this._frame.x;
			const sy = this._frame.y;
			
			this.setFrame(sx, sy, 0, ph);
			
			if (!this.lastEquip || this.lastEquip !== this._character.getActor()._equips) this.updateCostumeSprite();
			if (this.featherSprite.bitmap !== this.bitmap) this.updateFeatherSprite();
			this.lastEquip = this._character.getActor()._equips;
			if (this._bushDepth > 0) {
				this.featherSprite.setFrame(sx, sy, 0, ph);
			} else {
				this.featherSprite.setFrame(sx, sy, pw, ph);
			}
			this.featherSprite.mask = (this.Mask.bitmap && this.Mask.bitmap.isReady()) ? this.Mask : null;
			for (let i = 0; i<this._costume.length; i++) {
				if (this._costume[i].bitmap) {
					const equipMask = (this._character.getActor()._equips[i].object() && this._character.getActor()._equips[i].object().meta.MapMask) || 0;
					const pw = this._costume[i].bitmap.width / 3;
					const ph = this._costume[i].bitmap.height / 4;
					const sx = (0 + this.characterPatternX()) * pw;
					const sy = (0 + this.characterPatternY()) * ph;
					this._costume[i].setFrame(sx, sy, pw, ph);
					if (this._bCostume[i].bitmap) this._bCostume[i].setFrame(sx, sy, pw, ph);
					if (equipMask) this.Mask.setFrame(sx, sy, pw, ph);
				}
			}
		}
	};
	
	Sprite_Character.prototype.createBackCostumeSprite = function() {
		if (!this._bCostume) {
			this._bCostume = [];
			for (let i = 0; i<this._character.getActor()._equips.length; i++) {
				this._bCostume[i] = new Sprite();
				this._bCostume[i].anchor.x = 0.5;
				this._bCostume[i].anchor.y = 1;
				this.addChild(this._bCostume[i]);
			}
			this.featherSprite = new Sprite();
			this.featherSprite.anchor.x = 0.5;
			this.featherSprite.anchor.y = 1;
			this.addChild(this.featherSprite);
		}
	};
	
	
	Sprite_Character.prototype.updateCostumeSprite = function() {
		this.createCostumeSprite();
		const length = this._character.getActor()._equips.length;
		this.Mask.bitmap = null;
		for (let i = 0; i<length; i++) {
			let actorSpritePrefix = this._character.getActor().actor().meta.EquipmentSpritePrefix ? this._character.getActor().actor().meta.EquipmentSpritePrefix.trim() : "default";
			const actorSpriteSelectivePrefix = this._character.getActor().actor().longMeta.EquipmentSpriteSelectivePrefix && this._character.getActor().actor().longMeta.EquipmentSpriteSelectivePrefix;
			const equipSprite = this._character.getActor()._equips[i].object() && this._character.getActor()._equips[i].object().meta.MapSprite;
			const equipBackSprite = this._character.getActor()._equips[i].object() && this._character.getActor()._equips[i].object().meta.MapBackSprite;
			const equipMask = (this._character.getActor()._equips[i].object() && this._character.getActor()._equips[i].object().meta.MapMask) || 0;
			const equipBlendMode = (this._character.getActor()._equips[i].object() && this._character.getActor()._equips[i].object().meta.MapBlendMode) || 0;
			const equipZIndex = (this._character.getActor()._equips[i].object() && this._character.getActor()._equips[i].object().meta.MapZIndex) || 0;
			if (equipSprite) {
				if (actorSpriteSelectivePrefix && actorSpriteSelectivePrefix[equipSprite.trim()]) {
					actorSpritePrefix = actorSpriteSelectivePrefix[equipSprite.trim()];
				}
				let costume = ImageManager.loadCharacter(`costumes/${actorSpritePrefix}-${equipSprite.trim()}`);
				if (equipMask) this.Mask.bitmap = ImageManager.loadCharacter(`costumes/${actorSpritePrefix}-${equipMask.trim()}`);
				this._costume[i].bitmap = costume;
				this._costume[i].visible = true;
				this._costume[i].setBlendColor(this.getBlendColor());
				this._costume[i].setColorTone(this.getColorTone());
				this._costume[i].zIndex = equipZIndex || this._costume[i].defaultZIndex;
				if (equipBlendMode) this._costume[i].blendMode = eval(equipBlendMode);
				else this._costume[i].blendMode = this.blendMode;
				
				if (equipBackSprite) {
					let backCostume = ImageManager.loadCharacter(`costumes/${actorSpritePrefix}-${equipBackSprite.trim()}`);
					this._bCostume[i].bitmap = backCostume;
					this._bCostume[i].visible = true;
					this._bCostume[i].setBlendColor(this.getBlendColor());
					this._bCostume[i].setColorTone(this.getColorTone());
					if (equipBlendMode) this._bCostume[i].blendMode = eval(equipBlendMode);
					else this._bCostume[i].blendMode = this.blendMode;
				}
			}
		}
		
		this.Mask.visible = true;
		this.Mask.setBlendColor(this.getBlendColor());
		this.Mask.setColorTone(this.getColorTone());
		this.Mask.blendMode = this.blendMode;
		this.sortChildren();
	};
	
	
	Sprite_Character.prototype.updateHalfBodySprites = function() {
		this.createHalfBodySprites();
		if (this._bushDepth > 0) {
			this._upperBody.bitmap = this.bitmap;
			this._upperBody.visible = true;
			this._upperBody.y = -this._bushDepth;
			this._lowerBody.bitmap = this.bitmap;
			this._lowerBody.visible = true;
			this._upperBody.setBlendColor(this.getBlendColor());
			this._lowerBody.setBlendColor(this.getBlendColor());
			this._upperBody.setColorTone(this.getColorTone());
			this._lowerBody.setColorTone(this.getColorTone());
			this._upperBody.blendMode = this.blendMode;
			this._lowerBody.blendMode = this.blendMode;
		} else if (this._upperBody) {
			this._upperBody.visible = false;
			this._lowerBody.visible = false;
		}
	};
	
	
	Sprite_Character.prototype.updateFeatherSprite = function() {
		this.featherSprite.bitmap = this.bitmap;
		this.featherSprite.visible = true;
		this.featherSprite.setBlendColor(this.getBlendColor());
		this.featherSprite.setColorTone(this.getColorTone());
		this.featherSprite.blendMode = this.blendMode;
	};
	
	Sprite_Character.prototype.createCostumeSprite = function() {
		if (!this._costume) {
			this.Mask = new Sprite();
			this.Mask.anchor.x = 0.5;
			this.Mask.anchor.y = 1;
			this._costume = [];
			for (let i = 0; i<this._character.getActor()._equips.length; i++) {
				this._costume[i] = new Sprite();
				this._costume[i].anchor.x = 0.5;
				this._costume[i].anchor.y = 1;
				if (i > 0) this._costume[i].defaultZIndex = 0;
				else this._costume[i].defaultZIndex = 1;
				this.addChild(this._costume[i]);
			}
			this.addChild(this.Mask);
		}
	};
	

})();
