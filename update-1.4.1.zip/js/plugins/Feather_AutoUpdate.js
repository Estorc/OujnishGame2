//=============================================================================
// RPG Maker MZ - AutoUpdate
//=============================================================================

/*:
 * @target MZ
 * @plugindesc Auto Update system plugin.
 * @author Feather
 *
 * @help 
 * Auto Update system plugin.
 *
 */
 

(() => {
    const pluginName = "AutoUpdate";
	
	http = nw.require('https');
	decompress = nw.require('decompress');
	FeatherDLVER = ""
	
	function Scene_AutoUpdate() {
		this.initialize.apply(this, arguments);
	}
	
	var options = {
	  host: 'raw.githubusercontent.com',
	  port: 443,
	  path: '/Estorc/OujnishGame2/main/versions.txt'
	};
	

	http.get(options, function(res) {
	  
	  res.setEncoding('utf8');
	  let rawData = '';
	  res.on('data', (chunk) => { rawData += chunk; });
	  res.on('end', () => {
		try {
		  
			const regExp = /<([^<>:]+)(:?)([^>]*)>/g;
			http.meta = {};
			for (;;) {
				const match = regExp.exec(rawData);
				if (match) {
					if (match[2] === ":") {
						http.meta[match[1]] = match[3];
					} else {
						http.meta[match[1]] = true;
					}
				} else {
					break;
				}
			}
		  
		  let webData = Object.entries(http.meta);
		  
			fs.readFile('save/version', 'utf8', (err, data) => {
			  if (err) {
				console.error(err);
				return;
			  }
			  if (data !== eval(webData[webData.length-1][0])) {
				  
				  const updateFile = fs.createWriteStream("update.zip");
				  Scene_Boot.prototype.start = function(){SceneManager.goto(Scene_AutoUpdate);this.resizeScreen();this.updateDocumentTitle();};
				  console.log("UpdateRequired!")
				  
				  FeatherDLVER = eval(webData[webData.findIndex(x => eval(x[0]) === data)+1][0]);
				  
				  	var optionsUpdate = {
					  host: eval(webData[webData.findIndex(x => eval(x[0]) === data)+1][1])[0],
					  port: 443,
					  path: eval(webData[webData.findIndex(x => eval(x[0]) === data)+1][1])[1]
					};
				  
					http.get(optionsUpdate, function(response) {
					   response.pipe(updateFile);

					   // after download completed close filestream
					   updateFile.on("finish", () => {
						   updateFile.close();
						   console.log("Download Completed!");
							decompress("update.zip", ".")
							  .then((files) => {
								
								fs.writeFile('save/version', eval(webData[webData.findIndex(x => eval(x[0]) === data)+1][0]), (err) => {
								  if (err)
									console.log(err);
								  else {
									console.log("Version updated!");
									location.reload();
								  }
								});
								
							  })
							  .catch((error) => {
								console.log(error);
							  });
					   });
					});
				  
			  } else {
				  
				  console.log('Already Updated.')
				  
			  }
			});
		  
		  
		} catch (e) {
		  console.error(e.message);
		}
	  });
	  
	  
	}).on('error', function(e) {
	  console.log("Got error: " + e.message);
	});
	
	
	
	
	
	
	
	
	
	
Scene_AutoUpdate.prototype = Object.create(Scene_Base.prototype);
Scene_AutoUpdate.prototype.constructor = Scene_AutoUpdate;

Scene_AutoUpdate.prototype.initialize = function() {
	Scene_Base.prototype.initialize.call(this);
};

Scene_AutoUpdate.prototype.create = function() {
	Scene_Base.prototype.create.call(this);
};

Scene_AutoUpdate.prototype.setupImages = function() {
	this.setupParallax();
	this.setupText();
	this.setupVersionText();
	this.setupFade();
};

Scene_AutoUpdate.prototype.setupParallax = function() {
	this._parallax1 = new TilingSprite();
	this._parallax1.move(0, 0, Graphics.width + (Graphics.width * 10 / 100 * 2), Graphics.height + (Graphics.height * 10 / 100 * 2));
	this._parallax1.bitmap = ImageManager.loadBitmap('img/titles1/', "Layer1");
	this._parallax2 = new TilingSprite();
	this._parallax2.move(0, 0, Graphics.width + (Graphics.width * 10 / 100 * 2), Graphics.height + (Graphics.height * 10 / 100 * 2));
	this._parallax2.bitmap = ImageManager.loadBitmap('img/titles1/', "Layer2");
	this._parallax3 = new TilingSprite();
	this._parallax3.move(0, 0, Graphics.width + (Graphics.width * 10 / 100 * 2), Graphics.height + (Graphics.height * 10 / 100 * 2));
	this._parallax3.bitmap = ImageManager.loadBitmap('img/titles1/', "Layer3");
	this._parallax4 = new TilingSprite();
	this._parallax4.move(0, 0, Graphics.width , Graphics.height + (Graphics.height * 10 / 100 * 2));
	this._parallax4.bitmap = ImageManager.loadBitmap('img/titles1/', "Layer4")
	this._parallax4.scale.x = 720/624;
	this._parallax4.scale.y = 720/624;
	this.addChild(this._parallax1);
	this.addChild(this._parallax2);
	this.addChild(this._parallax3);
	this.addChild(this._parallax4);
};

Scene_AutoUpdate.prototype.setupText = function() {
	this._text1 = new Sprite(new Bitmap(Graphics.width/2, Graphics.height/4));
	this._text1.bitmap.outlineColor = 'black';
	this._text1.bitmap.outlineWidth = 4;
	this._text1.bitmap.fontSize = 72;
	this._text1._myText = 'Mise à jour';
	this._text1.bitmap.drawText(this._text1._myText, 0, 0, this._text1.bitmap.width, this._text1.bitmap.height, 'center');
	this._text1.anchor.x = 0.5;
	this._text1.anchor.y = 0.5;
	this._text1.x = Graphics.boxWidth/2;
	this._text1.y = Graphics.boxHeight/2;
	this._text1._rotationSpeed = 0.01;
	this._text1._dotDotDotSpeed = 0;
	this.addChild(this._text1);
};

Scene_AutoUpdate.prototype.setupVersionText = function() {
	this._text2 = new Sprite(new Bitmap(Graphics.width/2, Graphics.height/8));
	this._text2.bitmap.outlineColor = 'black';
	this._text2.bitmap.outlineWidth = 3;
	this._text2.bitmap.fontSize = 24;
	this._text2.anchor.x = 0.5;
	this._text2.anchor.y = 0.5;
	this._text2.x = Graphics.boxWidth/2;
	this._text2.y = Graphics.boxHeight * (19/20);
	this.addChild(this._text2);
};

Scene_AutoUpdate.prototype.updateVersionText = function() {
	this._text2.bitmap.clear();
	this._text2._myText = '(Téléchargement de la version : ' + FeatherDLVER + ')';
	this._text2.bitmap.drawText(this._text2._myText, 0, 0, this._text2.bitmap.width, this._text2.bitmap.height, 'center');
	this._currentDownloading = FeatherDLVER;
};

Scene_AutoUpdate.prototype.setupFade = function() {
	this._blackPic = new Sprite(new Bitmap(Graphics.width, Graphics.height));
	this._blackPic.bitmap.fillRect(0, 0, Graphics.width, Graphics.height, "#000000");
	this.addChild(this._blackPic);
};


Scene_AutoUpdate.prototype.update = function() {
	Scene_Base.prototype.update.call(this);
	this.updateTheLoading();
};

Scene_AutoUpdate.prototype.updateTheLoading = function() {
		if(!this._areImagesSetUp) {
			this.setupImages();
			this._areImagesSetUp = true;
		}
		this.updateImages();
		if(this._currentDownloading !== FeatherDLVER) {
			this.updateVersionText();
		}
};

Scene_AutoUpdate.prototype.updateImages = function() {
	if(this._parallax1 && this._blackPic) {
		if(this._blackPic.opacity > 0) {
			this._blackPic.opacity -= 5;
		}
		this._parallax1.origin.x += 1;
		this._parallax2.origin.x -= 1;
		this._parallax4.origin.x -= 1;
		this._text1.rotation += this._text1._rotationSpeed;
		if(Math.abs(this._text1.rotation) > 0.2) this._text1._rotationSpeed *= (-1);
		if(this._text1._dotDotDotSpeed < 30) {
			this._text1._dotDotDotSpeed++;
		} else {
			if(this._text1._myText === 'Mise à jour...') {
				this._text1._myText = 'Mise à jour';
			} else {
				this._text1._myText = this._text1._myText + '.';
			}
			this._text1.bitmap.clear();
			this._text1.bitmap.drawText(this._text1._myText, 0, 0, this._text1.bitmap.width, this._text1.bitmap.height, 'center');
			this._text1._dotDotDotSpeed = 0;
		}
	}
};

	
	

})();
