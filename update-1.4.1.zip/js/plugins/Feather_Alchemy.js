//=============================================================================
// RPG Maker MZ - Alchemy
//=============================================================================

/*:
 * @target MZ
 * @plugindesc Alchemy system plugin.
 * @author Feather
 *
 * @help 
 * Alchemy system plugin.
 *
 * @param Circles:arraystruct
 * @text Alchemy Circles
 * @type struct<Circles>[]
 * @desc Settings for Alchemy Circles.
 * @default ["{\"name:str\":\"Natural Basic Circle\",\"img:str\":\"natural-basic-circle\",\"space:number\":\"228\",\"size:number\":\"3\",\"costMultiplier:number\":\"0.80\",\"mpcost:number\":\"0\",\"tpcost:number\":\"0\",\"utcost:number\":\"0\",\"target:number\":\"15\",\"targetJS:str\":\"return this.checkUniqueElement()*1 + this.checkBalance()*7 + this.checkMajorant()*4\",\"prefix:str\":\"\",\"category:str\":\"\"}"]
 *
 * @param Elements:arraystruct
 * @text Alchemy Elements
 * @type struct<Elements>[]
 * @desc Settings for Alchemy Elements.
 * @default ["{\"elemId:number\":\"2\",\"name:str\":\"\",\"icon:number\":\"64\",\"utcost:energy\":\"4\",\"hidden:number\":\"false\",\"ressource:number\":\"true\",\"mpcost:number\":\"20\",\"tpcost:number\":\"0\",\"utcost:number\":\"0\",\"animations:struct\":\"{\\\"normalAnim:number\\\":\\\"66\\\",\\\"strongAnim:number\\\":\\\"67\\\",\\\"weakGroupAnim:number\\\":\\\"68\\\",\\\"groupAnim:number\\\":\\\"69\\\",\\\"strongGroupAnim:number\\\":\\\"70\\\"}\"}","{\"elemId:number\":\"3\",\"name:str\":\"\",\"icon:number\":\"65\",\"utcost:energy\":\"2\",\"hidden:number\":\"false\",\"ressource:number\":\"true\",\"mpcost:number\":\"20\",\"tpcost:number\":\"0\",\"utcost:number\":\"0\",\"animations:struct\":\"{\\\"normalAnim:number\\\":\\\"71\\\",\\\"strongAnim:number\\\":\\\"72\\\",\\\"weakGroupAnim:number\\\":\\\"73\\\",\\\"groupAnim:number\\\":\\\"74\\\",\\\"strongGroupAnim:number\\\":\\\"75\\\"}\"}","{\"elemId:number\":\"4\",\"name:str\":\"\",\"icon:number\":\"66\",\"utcost:energy\":\"8\",\"hidden:number\":\"false\",\"ressource:number\":\"true\",\"mpcost:number\":\"20\",\"tpcost:number\":\"0\",\"utcost:number\":\"0\",\"animations:struct\":\"{\\\"normalAnim:number\\\":\\\"76\\\",\\\"strongAnim:number\\\":\\\"77\\\",\\\"weakGroupAnim:number\\\":\\\"78\\\",\\\"groupAnim:number\\\":\\\"79\\\",\\\"strongGroupAnim:number\\\":\\\"80\\\"}\"}","{\"elemId:number\":\"5\",\"name:str\":\"\",\"icon:number\":\"67\",\"utcost:energy\":\"6\",\"hidden:number\":\"false\",\"ressource:number\":\"true\",\"mpcost:number\":\"20\",\"tpcost:number\":\"0\",\"utcost:number\":\"0\",\"animations:struct\":\"{\\\"normalAnim:number\\\":\\\"81\\\",\\\"strongAnim:number\\\":\\\"82\\\",\\\"weakGroupAnim:number\\\":\\\"83\\\",\\\"groupAnim:number\\\":\\\"84\\\",\\\"strongGroupAnim:number\\\":\\\"85\\\"}\"}","{\"elemId:number\":\"6\",\"name:str\":\"\",\"icon:number\":\"68\",\"utcost:energy\":\"1\",\"hidden:number\":\"false\",\"ressource:number\":\"true\",\"mpcost:number\":\"20\",\"tpcost:number\":\"0\",\"utcost:number\":\"0\",\"animations:struct\":\"{\\\"normalAnim:number\\\":\\\"86\\\",\\\"strongAnim:number\\\":\\\"87\\\",\\\"weakGroupAnim:number\\\":\\\"88\\\",\\\"groupAnim:number\\\":\\\"89\\\",\\\"strongGroupAnim:number\\\":\\\"90\\\"}\"}","{\"elemId:number\":\"7\",\"name:str\":\"\",\"icon:number\":\"69\",\"utcost:energy\":\"5\",\"hidden:number\":\"false\",\"ressource:number\":\"true\",\"mpcost:number\":\"20\",\"tpcost:number\":\"0\",\"utcost:number\":\"0\",\"animations:struct\":\"{\\\"normalAnim:number\\\":\\\"91\\\",\\\"strongAnim:number\\\":\\\"92\\\",\\\"weakGroupAnim:number\\\":\\\"93\\\",\\\"groupAnim:number\\\":\\\"94\\\",\\\"strongGroupAnim:number\\\":\\\"95\\\"}\"}","{\"elemId:number\":\"8\",\"name:str\":\"\",\"icon:number\":\"70\",\"utcost:energy\":\"7\",\"hidden:number\":\"false\",\"ressource:number\":\"true\",\"mpcost:number\":\"20\",\"tpcost:number\":\"0\",\"utcost:number\":\"0\",\"animations:struct\":\"{\\\"normalAnim:number\\\":\\\"96\\\",\\\"strongAnim:number\\\":\\\"97\\\",\\\"weakGroupAnim:number\\\":\\\"98\\\",\\\"groupAnim:number\\\":\\\"99\\\",\\\"strongGroupAnim:number\\\":\\\"100\\\"}\"}","{\"elemId:number\":\"9\",\"name:str\":\"\",\"icon:number\":\"71\",\"utcost:energy\":\"3\",\"hidden:number\":\"false\",\"ressource:number\":\"true\",\"mpcost:number\":\"20\",\"tpcost:number\":\"0\",\"utcost:number\":\"0\",\"animations:struct\":\"{\\\"normalAnim:number\\\":\\\"101\\\",\\\"strongAnim:number\\\":\\\"102\\\",\\\"weakGroupAnim:number\\\":\\\"103\\\",\\\"groupAnim:number\\\":\\\"104\\\",\\\"strongGroupAnim:number\\\":\\\"105\\\"}\"}"]
 *
 * @param Reactions:arraystruct
 * @text Alchemy Reactions
 * @type struct<Reactions>[]
 * @desc Settings for Alchemy Reactions.
 * @default ["{\"name:str\":\"cureHp\",\"prefix:str\":\"vita\",\"results:arraystruct\":\"[\\\"{\\\\\\\"result:number\\\\\\\":\\\\\\\"{\\\\\\\\\\\\\\\"code\\\\\\\\\\\\\\\":11,\\\\\\\\\\\\\\\"dataId\\\\\\\\\\\\\\\":0,\\\\\\\\\\\\\\\"value1\\\\\\\\\\\\\\\":\\\\\\\\\\\\\\\"thisCount*param1\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\"value2\\\\\\\\\\\\\\\":\\\\\\\\\\\\\\\"thisCount*thisCount*param2\\\\\\\\\\\\\\\"},\\\\\\\",\\\\\\\"id:number\\\\\\\":\\\\\\\"0\\\\\\\",\\\\\\\"param1:number\\\\\\\":\\\\\\\"0.01\\\\\\\",\\\\\\\"param2:number\\\\\\\":\\\\\\\"300.00\\\\\\\",\\\\\\\"resultJS:str\\\\\\\":\\\\\\\"\\\\\\\"}\\\"]\"}","{\"name:str\":\"cureMp\",\"prefix:str\":\"lux\",\"results:arraystruct\":\"[\\\"{\\\\\\\"result:number\\\\\\\":\\\\\\\"{\\\\\\\\\\\\\\\"code\\\\\\\\\\\\\\\":12,\\\\\\\\\\\\\\\"dataId\\\\\\\\\\\\\\\":0,\\\\\\\\\\\\\\\"value1\\\\\\\\\\\\\\\":\\\\\\\\\\\\\\\"thisCount*param1\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\"value2\\\\\\\\\\\\\\\":\\\\\\\\\\\\\\\"thisCount*thisCount*param2\\\\\\\\\\\\\\\"},\\\\\\\",\\\\\\\"id:number\\\\\\\":\\\\\\\"0\\\\\\\",\\\\\\\"param1:number\\\\\\\":\\\\\\\"0.01\\\\\\\",\\\\\\\"param2:number\\\\\\\":\\\\\\\"75.00\\\\\\\",\\\\\\\"resultJS:str\\\\\\\":\\\\\\\"\\\\\\\"}\\\"]\"}","{\"name:str\":\"cureTp\",\"prefix:str\":\"vi\",\"results:arraystruct\":\"[\\\"{\\\\\\\"result:number\\\\\\\":\\\\\\\"{\\\\\\\\\\\\\\\"code\\\\\\\\\\\\\\\":11,\\\\\\\\\\\\\\\"dataId\\\\\\\\\\\\\\\":0,\\\\\\\\\\\\\\\"value1\\\\\\\\\\\\\\\":\\\\\\\\\\\\\\\"thisCount*param1\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\"value2\\\\\\\\\\\\\\\":\\\\\\\\\\\\\\\"thisCount*thisCount*param2\\\\\\\\\\\\\\\"},\\\\\\\",\\\\\\\"id:number\\\\\\\":\\\\\\\"0\\\\\\\",\\\\\\\"param1:number\\\\\\\":\\\\\\\"5.00\\\\\\\",\\\\\\\"param2:number\\\\\\\":\\\\\\\"0.00\\\\\\\",\\\\\\\"resultJS:str\\\\\\\":\\\\\\\"\\\\\\\"}\\\"]\"}","{\"name:str\":\"regenHp\",\"prefix:str\":\"advita\",\"results:arraystruct\":\"[\\\"{\\\\\\\"result:number\\\\\\\":\\\\\\\"{\\\\\\\\\\\\\\\"code\\\\\\\\\\\\\\\":21,\\\\\\\\\\\\\\\"dataId\\\\\\\\\\\\\\\":\\\\\\\\\\\\\\\"id\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\"value1\\\\\\\\\\\\\\\":\\\\\\\\\\\\\\\"thisCount*param1\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\"value2\\\\\\\\\\\\\\\":0},\\\\\\\",\\\\\\\"id:number\\\\\\\":\\\\\\\"15\\\\\\\",\\\\\\\"param1:number\\\\\\\":\\\\\\\"0.50\\\\\\\",\\\\\\\"param2:number\\\\\\\":\\\\\\\"0.00\\\\\\\",\\\\\\\"resultJS:str\\\\\\\":\\\\\\\"\\\\\\\"}\\\"]\"}","{\"name:str\":\"regenMp\",\"prefix:str\":\"adlux\",\"results:arraystruct\":\"[\\\"{\\\\\\\"result:number\\\\\\\":\\\\\\\"{\\\\\\\\\\\\\\\"code\\\\\\\\\\\\\\\":21,\\\\\\\\\\\\\\\"dataId\\\\\\\\\\\\\\\":\\\\\\\\\\\\\\\"id\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\"value1\\\\\\\\\\\\\\\":\\\\\\\\\\\\\\\"thisCount*param1\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\"value2\\\\\\\\\\\\\\\":0},\\\\\\\",\\\\\\\"id:number\\\\\\\":\\\\\\\"16\\\\\\\",\\\\\\\"param1:number\\\\\\\":\\\\\\\"0.50\\\\\\\",\\\\\\\"param2:number\\\\\\\":\\\\\\\"0.00\\\\\\\",\\\\\\\"resultJS:str\\\\\\\":\\\\\\\"\\\\\\\"}\\\"]\"}","{\"name:str\":\"regenTp\",\"prefix:str\":\"advi\",\"results:arraystruct\":\"[\\\"{\\\\\\\"result:number\\\\\\\":\\\\\\\"{\\\\\\\\\\\\\\\"code\\\\\\\\\\\\\\\":21,\\\\\\\\\\\\\\\"dataId\\\\\\\\\\\\\\\":\\\\\\\\\\\\\\\"id\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\"value1\\\\\\\\\\\\\\\":\\\\\\\\\\\\\\\"thisCount*param1\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\"value2\\\\\\\\\\\\\\\":0},\\\\\\\",\\\\\\\"id:number\\\\\\\":\\\\\\\"17\\\\\\\",\\\\\\\"param1:number\\\\\\\":\\\\\\\"0.50\\\\\\\",\\\\\\\"param2:number\\\\\\\":\\\\\\\"0.00\\\\\\\",\\\\\\\"resultJS:str\\\\\\\":\\\\\\\"\\\\\\\"}\\\"]\"}","{\"name:str\":\"poison\",\"prefix:str\":\"venenum\",\"results:arraystruct\":\"[\\\"{\\\\\\\"result:number\\\\\\\":\\\\\\\"{\\\\\\\\\\\\\\\"code\\\\\\\\\\\\\\\":21,\\\\\\\\\\\\\\\"dataId\\\\\\\\\\\\\\\":\\\\\\\\\\\\\\\"id\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\"value1\\\\\\\\\\\\\\\":\\\\\\\\\\\\\\\"thisCount*param1\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\"value2\\\\\\\\\\\\\\\":0},\\\\\\\",\\\\\\\"id:number\\\\\\\":\\\\\\\"4\\\\\\\",\\\\\\\"param1:number\\\\\\\":\\\\\\\"0.33\\\\\\\",\\\\\\\"param2:number\\\\\\\":\\\\\\\"0.00\\\\\\\",\\\\\\\"resultJS:str\\\\\\\":\\\\\\\"\\\\\\\"}\\\"]\"}","{\"name:str\":\"blindness\",\"prefix:str\":\"nox\",\"results:arraystruct\":\"[\\\"{\\\\\\\"result:number\\\\\\\":\\\\\\\"{\\\\\\\\\\\\\\\"code\\\\\\\\\\\\\\\":21,\\\\\\\\\\\\\\\"dataId\\\\\\\\\\\\\\\":\\\\\\\\\\\\\\\"id\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\"value1\\\\\\\\\\\\\\\":\\\\\\\\\\\\\\\"thisCount*param1\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\"value2\\\\\\\\\\\\\\\":0},\\\\\\\",\\\\\\\"id:number\\\\\\\":\\\\\\\"5\\\\\\\",\\\\\\\"param1:number\\\\\\\":\\\\\\\"0.33\\\\\\\",\\\\\\\"param2:number\\\\\\\":\\\\\\\"0.00\\\\\\\",\\\\\\\"resultJS:str\\\\\\\":\\\\\\\"\\\\\\\"}\\\"]\"}","{\"name:str\":\"silence\",\"prefix:str\":\"nihil\",\"results:arraystruct\":\"[\\\"{\\\\\\\"result:number\\\\\\\":\\\\\\\"{\\\\\\\\\\\\\\\"code\\\\\\\\\\\\\\\":21,\\\\\\\\\\\\\\\"dataId\\\\\\\\\\\\\\\":\\\\\\\\\\\\\\\"id\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\"value1\\\\\\\\\\\\\\\":\\\\\\\\\\\\\\\"thisCount*param1\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\"value2\\\\\\\\\\\\\\\":0},\\\\\\\",\\\\\\\"id:number\\\\\\\":\\\\\\\"6\\\\\\\",\\\\\\\"param1:number\\\\\\\":\\\\\\\"0.33\\\\\\\",\\\\\\\"param2:number\\\\\\\":\\\\\\\"0.00\\\\\\\",\\\\\\\"resultJS:str\\\\\\\":\\\\\\\"\\\\\\\"}\\\"]\"}","{\"name:str\":\"paralysis\",\"prefix:str\":\"fulgur\",\"results:arraystruct\":\"[\\\"{\\\\\\\"result:number\\\\\\\":\\\\\\\"{\\\\\\\\\\\\\\\"code\\\\\\\\\\\\\\\":21,\\\\\\\\\\\\\\\"dataId\\\\\\\\\\\\\\\":\\\\\\\\\\\\\\\"id\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\"value1\\\\\\\\\\\\\\\":\\\\\\\\\\\\\\\"thisCount*param1\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\"value2\\\\\\\\\\\\\\\":0},\\\\\\\",\\\\\\\"id:number\\\\\\\":\\\\\\\"12\\\\\\\",\\\\\\\"param1:number\\\\\\\":\\\\\\\"0.33\\\\\\\",\\\\\\\"param2:number\\\\\\\":\\\\\\\"0.00\\\\\\\",\\\\\\\"resultJS:str\\\\\\\":\\\\\\\"\\\\\\\"}\\\"]\"}","{\"name:str\":\"rest\",\"prefix:str\":\"somnum\",\"results:arraystruct\":\"[\\\"{\\\\\\\"result:number\\\\\\\":\\\\\\\"{\\\\\\\\\\\\\\\"code\\\\\\\\\\\\\\\":21,\\\\\\\\\\\\\\\"dataId\\\\\\\\\\\\\\\":\\\\\\\\\\\\\\\"id\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\"value1\\\\\\\\\\\\\\\":\\\\\\\\\\\\\\\"thisCount*param1\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\"value2\\\\\\\\\\\\\\\":0},\\\\\\\",\\\\\\\"id:number\\\\\\\":\\\\\\\"10\\\\\\\",\\\\\\\"param1:number\\\\\\\":\\\\\\\"0.33\\\\\\\",\\\\\\\"param2:number\\\\\\\":\\\\\\\"0.00\\\\\\\",\\\\\\\"resultJS:str\\\\\\\":\\\\\\\"\\\\\\\"}\\\"]\"}"]
 *
 *
 * @param RecipesCategories:arraystruct
 * @text Alchemy Recipes Categories
 * @desc Settings for Alchemy Recipes Categories
 * @type struct<RecipesCategory>[]
 * @default ["{\"name:str\":\"default\",\"recipes:arraystruct\":\"[\\\"{\\\\\\\"ingredients:number[]\\\\\\\":\\\\\\\"[\\\\\\\\\\\\\\\"6\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\"4\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\"7\\\\\\\\\\\\\\\"]\\\\\\\",\\\\\\\"results:string[]\\\\\\\":\\\\\\\"[\\\\\\\\\\\\\\\"regenHp\\\\\\\\\\\\\\\"]\\\\\\\",\\\\\\\"priority:number\\\\\\\":\\\\\\\"3.00\\\\\\\"}\\\",\\\"{\\\\\\\"ingredients:number[]\\\\\\\":\\\\\\\"[\\\\\\\\\\\\\\\"5\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\"3\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\"7\\\\\\\\\\\\\\\"]\\\\\\\",\\\\\\\"results:string[]\\\\\\\":\\\\\\\"[\\\\\\\\\\\\\\\"regenTp\\\\\\\\\\\\\\\"]\\\\\\\",\\\\\\\"priority:number\\\\\\\":\\\\\\\"3.00\\\\\\\"}\\\",\\\"{\\\\\\\"ingredients:number[]\\\\\\\":\\\\\\\"[\\\\\\\\\\\\\\\"4\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\"2\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\"7\\\\\\\\\\\\\\\"]\\\\\\\",\\\\\\\"results:string[]\\\\\\\":\\\\\\\"[\\\\\\\\\\\\\\\"regenMp\\\\\\\\\\\\\\\"]\\\\\\\",\\\\\\\"priority:number\\\\\\\":\\\\\\\"3.00\\\\\\\"}\\\",\\\"{\\\\\\\"ingredients:number[]\\\\\\\":\\\\\\\"[\\\\\\\\\\\\\\\"4\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\"1\\\\\\\\\\\\\\\"]\\\\\\\",\\\\\\\"results:string[]\\\\\\\":\\\\\\\"[\\\\\\\\\\\\\\\"rest\\\\\\\\\\\\\\\"]\\\\\\\",\\\\\\\"priority:number\\\\\\\":\\\\\\\"2.00\\\\\\\"}\\\",\\\"{\\\\\\\"ingredients:number[]\\\\\\\":\\\\\\\"[\\\\\\\\\\\\\\\"5\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\"1\\\\\\\\\\\\\\\"]\\\\\\\",\\\\\\\"results:string[]\\\\\\\":\\\\\\\"[\\\\\\\\\\\\\\\"blindness\\\\\\\\\\\\\\\"]\\\\\\\",\\\\\\\"priority:number\\\\\\\":\\\\\\\"2.00\\\\\\\"}\\\",\\\"{\\\\\\\"ingredients:number[]\\\\\\\":\\\\\\\"[\\\\\\\\\\\\\\\"3\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\"2\\\\\\\\\\\\\\\"]\\\\\\\",\\\\\\\"results:string[]\\\\\\\":\\\\\\\"[\\\\\\\\\\\\\\\"silence\\\\\\\\\\\\\\\"]\\\\\\\",\\\\\\\"priority:number\\\\\\\":\\\\\\\"2.00\\\\\\\"}\\\",\\\"{\\\\\\\"ingredients:number[]\\\\\\\":\\\\\\\"[\\\\\\\\\\\\\\\"4\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\"2\\\\\\\\\\\\\\\"]\\\\\\\",\\\\\\\"results:string[]\\\\\\\":\\\\\\\"[\\\\\\\\\\\\\\\"cureMp\\\\\\\\\\\\\\\"]\\\\\\\",\\\\\\\"priority:number\\\\\\\":\\\\\\\"2.00\\\\\\\"}\\\",\\\"{\\\\\\\"ingredients:number[]\\\\\\\":\\\\\\\"[\\\\\\\\\\\\\\\"7\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\"2\\\\\\\\\\\\\\\"]\\\\\\\",\\\\\\\"results:string[]\\\\\\\":\\\\\\\"[\\\\\\\\\\\\\\\"blindness\\\\\\\\\\\\\\\"]\\\\\\\",\\\\\\\"priority:number\\\\\\\":\\\\\\\"2.00\\\\\\\"}\\\",\\\"{\\\\\\\"ingredients:number[]\\\\\\\":\\\\\\\"[\\\\\\\\\\\\\\\"4\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\"3\\\\\\\\\\\\\\\"]\\\\\\\",\\\\\\\"results:string[]\\\\\\\":\\\\\\\"[\\\\\\\\\\\\\\\"paralysis\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\"paralysis\\\\\\\\\\\\\\\"]\\\\\\\",\\\\\\\"priority:number\\\\\\\":\\\\\\\"2.00\\\\\\\"}\\\",\\\"{\\\\\\\"ingredients:number[]\\\\\\\":\\\\\\\"[\\\\\\\\\\\\\\\"5\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\"3\\\\\\\\\\\\\\\"]\\\\\\\",\\\\\\\"results:string[]\\\\\\\":\\\\\\\"[\\\\\\\\\\\\\\\"cureTp\\\\\\\\\\\\\\\"]\\\\\\\",\\\\\\\"priority:number\\\\\\\":\\\\\\\"2.00\\\\\\\"}\\\",\\\"{\\\\\\\"ingredients:number[]\\\\\\\":\\\\\\\"[\\\\\\\\\\\\\\\"6\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\"3\\\\\\\\\\\\\\\"]\\\\\\\",\\\\\\\"results:string[]\\\\\\\":\\\\\\\"[\\\\\\\\\\\\\\\"paralysis\\\\\\\\\\\\\\\"]\\\\\\\",\\\\\\\"priority:number\\\\\\\":\\\\\\\"2.00\\\\\\\"}\\\",\\\"{\\\\\\\"ingredients:number[]\\\\\\\":\\\\\\\"[\\\\\\\\\\\\\\\"5\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\"4\\\\\\\\\\\\\\\"]\\\\\\\",\\\\\\\"results:string[]\\\\\\\":\\\\\\\"[\\\\\\\\\\\\\\\"poison\\\\\\\\\\\\\\\"]\\\\\\\",\\\\\\\"priority:number\\\\\\\":\\\\\\\"2.00\\\\\\\"}\\\",\\\"{\\\\\\\"ingredients:number[]\\\\\\\":\\\\\\\"[\\\\\\\\\\\\\\\"6\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\"4\\\\\\\\\\\\\\\"]\\\\\\\",\\\\\\\"results:string[]\\\\\\\":\\\\\\\"[\\\\\\\\\\\\\\\"cureHp\\\\\\\\\\\\\\\"]\\\\\\\",\\\\\\\"priority:number\\\\\\\":\\\\\\\"2.00\\\\\\\"}\\\",\\\"{\\\\\\\"ingredients:number[]\\\\\\\":\\\\\\\"[\\\\\\\\\\\\\\\"7\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\"4\\\\\\\\\\\\\\\"]\\\\\\\",\\\\\\\"results:string[]\\\\\\\":\\\\\\\"[\\\\\\\\\\\\\\\"poison\\\\\\\\\\\\\\\"]\\\\\\\",\\\\\\\"priority:number\\\\\\\":\\\\\\\"2.00\\\\\\\"}\\\",\\\"{\\\\\\\"ingredients:number[]\\\\\\\":\\\\\\\"[\\\\\\\\\\\\\\\"8\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\"4\\\\\\\\\\\\\\\"]\\\\\\\",\\\\\\\"results:string[]\\\\\\\":\\\\\\\"[\\\\\\\\\\\\\\\"poison\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\"silence\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\"blindness\\\\\\\\\\\\\\\"]\\\\\\\",\\\\\\\"priority:number\\\\\\\":\\\\\\\"2.00\\\\\\\"}\\\",\\\"{\\\\\\\"ingredients:number[]\\\\\\\":\\\\\\\"[\\\\\\\\\\\\\\\"6\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\"5\\\\\\\\\\\\\\\"]\\\\\\\",\\\\\\\"results:string[]\\\\\\\":\\\\\\\"[\\\\\\\\\\\\\\\"blindness\\\\\\\\\\\\\\\"]\\\\\\\",\\\\\\\"priority:number\\\\\\\":\\\\\\\"2.00\\\\\\\"}\\\",\\\"{\\\\\\\"ingredients:number[]\\\\\\\":\\\\\\\"[\\\\\\\\\\\\\\\"7\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\"5\\\\\\\\\\\\\\\"]\\\\\\\",\\\\\\\"results:string[]\\\\\\\":\\\\\\\"[\\\\\\\\\\\\\\\"blindness\\\\\\\\\\\\\\\"]\\\\\\\",\\\\\\\"priority:number\\\\\\\":\\\\\\\"2.00\\\\\\\"}\\\",\\\"{\\\\\\\"ingredients:number[]\\\\\\\":\\\\\\\"[\\\\\\\\\\\\\\\"8\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\"5\\\\\\\\\\\\\\\"]\\\\\\\",\\\\\\\"results:string[]\\\\\\\":\\\\\\\"[\\\\\\\\\\\\\\\"blindness\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\"poison\\\\\\\\\\\\\\\"]\\\\\\\",\\\\\\\"priority:number\\\\\\\":\\\\\\\"2.00\\\\\\\"}\\\",\\\"{\\\\\\\"ingredients:number[]\\\\\\\":\\\\\\\"[\\\\\\\\\\\\\\\"7\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\"6\\\\\\\\\\\\\\\"]\\\\\\\",\\\\\\\"results:string[]\\\\\\\":\\\\\\\"[\\\\\\\\\\\\\\\"silence\\\\\\\\\\\\\\\"]\\\\\\\",\\\\\\\"priority:number\\\\\\\":\\\\\\\"2.00\\\\\\\"}\\\",\\\"{\\\\\\\"ingredients:number[]\\\\\\\":\\\\\\\"[\\\\\\\\\\\\\\\"8\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\"6\\\\\\\\\\\\\\\"]\\\\\\\",\\\\\\\"results:string[]\\\\\\\":\\\\\\\"[\\\\\\\\\\\\\\\"blindness\\\\\\\\\\\\\\\"]\\\\\\\",\\\\\\\"priority:number\\\\\\\":\\\\\\\"2.00\\\\\\\"}\\\",\\\"{\\\\\\\"ingredients:number[]\\\\\\\":\\\\\\\"[\\\\\\\\\\\\\\\"8\\\\\\\\\\\\\\\",\\\\\\\\\\\\\\\"7\\\\\\\\\\\\\\\"]\\\\\\\",\\\\\\\"results:string[]\\\\\\\":\\\\\\\"[\\\\\\\\\\\\\\\"rest\\\\\\\\\\\\\\\"]\\\\\\\",\\\\\\\"priority:number\\\\\\\":\\\\\\\"2.00\\\\\\\"}\\\"]\"}"]
 *
 * @param defaultCategory:str
 * @text Default Recipe Category
 * @desc Set Default Recipe Category
 * @default default
 *
 */
 /*~struct~Circles:
 *
 * @param name:str
 * @text Name
 * @desc Name of the circle.
 * @default Untitled Circle
 *
 * @param img:str
 * @text Image
 * @desc Image of the circle.
 * @type file
 * @dir img/alchemy/
 * @default natural-basic-circle
 *
 * @param space:number
 * @text Radius
 * @desc Length from the circle's center to his branches.
 * @type number
 * @default 228
 *
 * @param size:number
 * @text Number of branches
 * @desc Number of branches.
 * @type number
 * @default 3
 *
 * @param costMultiplier:number
 * @text Cost multiplier
 * @desc The cost multiplier of the circle.
 * @type number
 * @decimals 2
 * @default 1.00
 *
 * @param mpcost:number
 * @text MP Cost
 * @desc Cost of the circle in MP.
 * @type number
 * @default 0
 *
 * @param tpcost:number
 * @text TP Cost
 * @desc Cost of the circle in TP.
 * @type number
 * @default 0
 *
 * @param utcost:number
 * @text UT Cost
 * @desc Cost of the circle in UT.
 * @type number
 * @default 0
 *
 * @param target:number
 * @text Target
 * @desc The circle's target.
 * @type select
 * @default 0
 * @option Normal
 * @value 0
 * @option Unique ennemy
 * @value 1
 * @option All ennemies
 * @value 2
 * @option 1 random ennemy
 * @value 3
 * @option 2 random ennemy
 * @value 4
 * @option 3 random ennemy
 * @value 5
 * @option 4 random ennemy
 * @value 6
 * @option Unique alive ally
 * @value 7
 * @option All alive allies
 * @value 8
 * @option Unique dead ally
 * @value 9
 * @option All dead allies
 * @value 10
 * @option User
 * @value 11
 * @option Unique ally
 * @value 12
 * @option All allies
 * @value 13
 * @option Everyone
 * @value 14
 * @option Custom [JS]
 * @value 15
 *
 * @param targetJS:str
 * @text Custom Target [JS]
 * @desc The circle's target.
 * @type multiline_string
 * @default 
 *
 * @param prefix:str
 * @text Prefix
 * @desc Prefix of the circle. (leave empty for no prefix)
 * @default 
 *
 * @param category:str
 * @text Recipe Category
 * @desc Recipe Category of the circle. (leave empty for default)
 * @default 
 *
 */
 /*~struct~Elements:
 *
 * @param elemId:number
 * @text Database ID
 * @desc The element ID in database (0 for not in database).
 * @type number
 * @default 0
 *
 * @param name:str
 * @text Name
 * @desc Name of the circle. (leave empty to take the database name)
 * @default Untitled Element
 *
 * @param icon:number
 * @text Icon
 * @desc Icon of the element.
 * @type icon
 * @default 0
 *
 * @param energy:number
 * @text Energy
 * @desc The higher the energy, the higher the priority in blending Try to avoid same energy elements -think like in physics-.
 * @type number
 * @default 0
 *
 * @param hidden:number
 * @text Is hidden?
 * @desc Is element hidden in spell description.
 * @type boolean
 * @default false
 *
 * @param ressource:number
 * @text Is a ressource?
 * @desc Is element is a ressource.
 * @type boolean
 * @default true
 *
 * @param mpcost:number
 * @text MP Cost
 * @desc Cost of the element in MP.
 * @type number
 * @default 0
 *
 * @param tpcost:number
 * @text TP Cost
 * @desc Cost of the element in TP.
 * @type number
 * @default 0
 *
 * @param utcost:number
 * @text UT Cost
 * @desc Cost of the element in UT.
 * @type number
 * @default 0
 *
 * @param animations:struct
 * @text Animations
 * @desc Animations of the element.
 * @type struct<Animations>
 * @default {"normalAnim:number":"0","strongAnim:number":"0","weakGroupAnim:number":"0","groupAnim:number":"0","strongGroupAnim:number":"0"}
 *
 */
 /*~struct~Reactions:
 *
 * @param name:str
 * @text Name
 * @desc Name of the reaction.
 * @default Untitled Reaction
 *
 * @param prefix:str
 * @text Prefix
 * @desc Prefix of the reaction. (in lowercase unless you want a fixed case)
 * @default 
 *
 * @param results:arraystruct
 * @text Results
 * @desc Results of the reaction.
 * @type struct<Results>[]
 * @default []
 *
 */
/*~struct~RecipesCategory:
 *
 * @param name:str
 * @text Name
 * @desc Name of the category.
 * @default Untitled Recipes Category
 *
 * @param recipes:arraystruct
 * @text Recipes
 * @desc List of the differents recipes of this category.
 * @type struct<Recipe>[]
 * @default []
 *
*/
/*~struct~Recipe:
 *
 * @param ingredients:number[]
 * @text Ingredients
 * @desc ID of each ingredients of the recipe.
 * @type number[]
 * @default []
 * 
 * @param philosopherstone:number
 * @text Require Philosopher's Stone
 * @desc Do the recipe require Philosopher's Stone.
 * @type boolean
 * @default false
 *
 * @param results:string[]
 * @text Results
 * @desc Name of each results of the recipe.
 * @type string[]
 * @default []
 *
 * @param priority:number
 * @text Priority
 * @desc Priority of this recipe.
 * @type number
 * @decimals 2
 * @default 1.00
 *
*/
/*~struct~Results:
 *
 * @param result:object
 * @text Result
 * @desc Result of the reaction.
 * @type select
 * @option Cure HP ([Parameter 1]% + [Parameter 2])
 * @value {"code":11,"dataId":0,"value1":"thisCount*param1","value2":"thisCount*thisCount*param2"}
 * @option Cure MP ([Parameter 1]% + [Parameter 2])
 * @value {"code":12,"dataId":0,"value1":"thisCount*param1","value2":"thisCount*thisCount*param2"}
 * @option Cure TP (Parameter 1 = Number of TP)
 * @value {"code":13,"dataId":0,"value1":"thisCount*thisCount*param1","value2":0}
 * @option Apply state (Database ID = ID, Parameter 1 = Probability)
 * @value {"code":21,"dataId":"id","value1":"thisCount*param1","value2":0}
 * @option Spawn Summon (Database ID = ID, Parameter 1 = SP Cost, Custom [JS] = Callback)
 * @value {"code":"\"spawnSummon\"","dataId":"id","value1":"(() => {spcost += param1; return param1})()","value2":"eval(\"((summon) => { const arg1 = data; const arg2 = id; const arg3 = param1; const arg4 = param2; \" + (paramJS || \"return summon;\") + \"})\")"}
 * @option Create Philosopher's Stone
 * @value "Philosopher's Stone"
 * @option Add Skill (Database ID = SkillID)
 * @value {"skill":"id"}
 * @option Cancel skill creation
 * @value "Cancel"
 * @option Custom [JS]
 * @value 'custom'
 * @default {"code":21,"dataId":"id","value1":"thisCount*param1","value2":0}
 *
 * @param id:number
 * @text Database ID
 * @desc Parameter for an ID if required.
 * @type number
 * @default 0
 *
 * @param param1:number
 * @text Parameter 1
 * @desc First parameter of the result.
 * @type number
 * @decimals 2
 * @default 1.00
 *
 * @param param2:number
 * @text Parameter 2
 * @desc Second parameter of the result.
 * @type number
 * @decimals 2
 * @default 1.00
 *
 * @param resultJS:str
 * @text Result [JS]
 * @desc Result of the reaction. (return an effect JSON)
 * @type multiline_string
 * @default 
*/
/*~struct~Animations:
 *
 * @param normalAnim:number
 * @text Normal spell animation
 * @desc Animation in a normal spell.
 * @type animation
 * @default 0
 *
 * @param strongAnim:number
 * @text Strong spell animation
 * @desc Animation in a strong spell.
 * @type animation
 * @default 0
 *
 * @param weakGroupAnim:number
 * @text Weak group spell animation
 * @desc Animation in a weak group spell.
 * @type animation
 * @default 0
 *
 * @param groupAnim:number
 * @text Group spell animation
 * @desc Animation in a group spell.
 * @type animation
 * @default 0
 *
 * @param strongGroupAnim:number
 * @text Strong group spell animation
 * @desc Animation in a strong group spell.
 * @type animation
 * @default 0
 *
 */
 

(() => {
    const pluginName = "Feather_Alchemy";
	
	Feather_Core.preloadRessources['bloodCircle'] = ImageManager.loadBitmap('img/alchemy/', 'bloodCircle');
	Feather_Core.preloadRessources['bloodLine'] = ImageManager.loadBitmap('img/alchemy/', 'bloodLine');
	
	
	___FeatherA___DataManager_isSkill = DataManager.isSkill;
	DataManager.isSkill = function(item) {
		return (___FeatherA___DataManager_isSkill.call(this, item) || (item && item.isAlchemySkill) );
	};
	
	//-----------------------------------------------------------------------------
	// Feather_Alchemy
	//
	// The main class of Feather Alchemy.
	
	
	Feather_Alchemy = function() {
		throw new Error("This is a static class");
	};
	
	Feather_Alchemy.initialize = function() {
		Object.assign(this, Feather_Core.loadPluginParameters(PluginManager.parameters(pluginName)));
		this.Circles.forEach(a => {
			Feather_Core.preloadRessources[a.img] = ImageManager.loadBitmap('img/alchemy/', a.img);
			a.img = Feather_Core.preloadRessources[a.img];
			a.category = a.category || Feather_Alchemy.defaultCategory;
			if (a.target === 15) {
				a.target = `(() => { ${a.targetJS} })()`;
			}
		});
		this.Reactions.ingredients = {};
		this.Reactions.forEach((a,b,c) => {
			c[a.name] = a;
			c.ingredients[a.name] = 0;
			a.results.forEach(d => {
				if (d.result === 'custom') d.result = `(() => { ${d.resultJS} })()`;
			})
		});
		this.RecipesCategories.forEach((a,b,c) => {
			c[a.name] = a;
		});
		this.Elements.forEach(a => {
			a.name = !a.name ? $dataSystem.elements[a.elemId] : a.name;
		});
		this.Elements.unshift({name:"Retirer", icon:463, hidden:true, ressource:false});
		this.Elements.map((a,b) => a.id = b);
	}


	Game_BattlerBase.prototype.setElements = function(id,nb,element) {
		this._elements[id] = {count:nb, element:element};
		this.refresh();
	};
	
	Game_BattlerBase.prototype.getStartElementCount = function(id) {
		return 1 * (!$gameMap.getAreaGroup() || $gameMap.getAreaGroup().ElementsMultiplier.reduce((a,b) => a * ((b.Id === id) * b.Multiplier + (b.Id !== id)),1))
				* this.allTraits().reduce((a,b) => a * ((b.code === 'multElem' && b.dataId === id) * b.value + !(b.code === 'multElem' && b.dataId === id)), 1)
				+ this.allTraits().reduce((a,b) => a + (b.code === 'increaseElem' && b.dataId === id) * b.value, 0);
	}
	
	Game_BattlerBase.prototype.createElements = function() {
		if (!Feather_Alchemy.Elements) Feather_Alchemy.initialize();
		this._elements = [];
		const ressources = Feather_Alchemy.Elements.filter(a => a.ressource);
		for (let i = 0; i<ressources.length; i++) {
			this.setElements(i, this.getStartElementCount(ressources[i].elemId), ressources[i]);
		}
	}
	
	___FeatherA___Game_Battler_onBattleStart = Game_Battler.prototype.onBattleStart
	Game_Battler.prototype.onBattleStart = function(advantageous) {
		this.createElements();
		this._alchemySkills = [];
		this.philosopherStone = false;
		___FeatherA___Game_Battler_onBattleStart.call(this, advantageous);
		
	};

	___FeatherA___Game_Battler_refresh = Game_Battler.prototype.refresh;
	Game_Battler.prototype.refresh = function() {
		___FeatherA___Game_Battler_refresh.call(this);
		if (this.philosopherStone) {
			this._tp = 1000000;
			this._mp = 1000000;
			this._tp = 1000000;
			this._mp = 1000000;
		}
	}
	
	



	___FeatherA___Window_ActorCommand_addSkillCommands = Window_ActorCommand.prototype.addSkillCommands;
	Window_ActorCommand.prototype.addSkillCommands = function() {
		___FeatherA___Window_ActorCommand_addSkillCommands.call(this);
		if (this._actor.currentClass().meta.Alchemist)
		this.addAlchemyCommand();
	};
	
	Window_ActorCommand.prototype.addAlchemyCommand = function() {
		this.addCommand("\\I[447]Alchimie", "alchemy", true);
	};
	
	___FeatherA___Scene_Battle_createSkillWindow = Scene_Battle.prototype.createSkillWindow;
	Scene_Battle.prototype.createSkillWindow = function() {
		___FeatherA___Scene_Battle_createSkillWindow.call(this);
		this.createAlchemyWindow();
	};
	
	___FeatherA___Scene_Battle_shouldOpenStatusWindow = Scene_Battle.prototype.shouldOpenStatusWindow;
	Scene_Battle.prototype.shouldOpenStatusWindow = function() {
		return (
			___FeatherA___Scene_Battle_shouldOpenStatusWindow.call(this) && !this._statusWindow._forceClosing
		);
	};

	Scene_Battle.prototype.createAlchemyWindow = function() {
		const rect = this.alchemyWindowRect();
		const commandWindow = new Window_AlchemyCommand(rect);
		commandWindow.y = Graphics.boxHeight - commandWindow.height;
		commandWindow.setHandler("cancel", this.onAlchemyCancel.bind(this));
		commandWindow.setHelpWindow(this._helpWindow);
		this.addWindow(commandWindow);
		this._alchemyWindow = commandWindow;
		this._alchemyWindow.deactivate();
		this._alchemyWindow.close();
	};
	
	Scene_Battle.prototype.alchemyWindowRect = function() {
		const ww = 300;
		const wh = this.windowAreaHeight();
		const wx = this.isRightInputMode() ? Graphics.boxWidth - ww : 0;
		const wy = Graphics.boxHeight - wh;
		return new Rectangle(wx, wy, ww, wh);
	};
	
	Scene_Battle.prototype.onAlchemyCancel = function() {
		this._alchemyWindow.deactivate();
		this._alchemyWindow.close();
		this._actorCommandWindow.open();
		this._actorCommandWindow.activate();
	};
	
	___FeatherA___Scene_Battle_createActorCommandWindow = Scene_Battle.prototype.createActorCommandWindow
	Scene_Battle.prototype.createActorCommandWindow = function() {
		
		___FeatherA___Scene_Battle_createActorCommandWindow.call(this);
		this._actorCommandWindow.setHandler("alchemy", this.commandAlchemy.bind(this));
		
	}
	
	Scene_Battle.prototype.commandAlchemy = function() {
		this._alchemyWindow.setup(BattleManager.actor(), this);
		this._statusWindow.close();
		this._statusWindow._forceClosing = true;
		this._actorCommandWindow.deactivate();
		this._actorCommandWindow.close();
	};
	
	___FeatherA___Scene_Battle_isAnyInputWindowActive = Scene_Battle.prototype.isAnyInputWindowActive;
	Scene_Battle.prototype.isAnyInputWindowActive = function() {
		return (___FeatherA___Scene_Battle_isAnyInputWindowActive.call(this) || this._alchemyWindow.isActive());
	};
	
	___FeatherA___Scene_Battle_onActorOk = Scene_Battle.prototype.onActorOk;
	Scene_Battle.prototype.onActorOk = function() {
		___FeatherA___Scene_Battle_onActorOk.call(this);
		this._alchemyWindow.close();
	};

	___FeatherA___Scene_Battle_onActorCancel = Scene_Battle.prototype.onActorCancel;
	Scene_Battle.prototype.onActorCancel = function() {
		___FeatherA___Scene_Battle_onActorCancel.call(this);
		switch (this._actorCommandWindow.currentSymbol()) {
			case "alchemy":
				this._alchemyWindow._skillWindow.show();
				this._alchemyWindow._skillWindow.activate();
				break;
		}
	};
	
	___FeatherA___Scene_Battle_onEnemyOk = Scene_Battle.prototype.onEnemyOk;
	Scene_Battle.prototype.onEnemyOk = function() {
		___FeatherA___Scene_Battle_onEnemyOk.call(this);
		this._alchemyWindow.close();
	};

	___FeatherA___Scene_Battle_onEnemyCancel = Scene_Battle.prototype.onEnemyCancel;
	Scene_Battle.prototype.onEnemyCancel = function() {
		___FeatherA___Scene_Battle_onEnemyCancel.call(this);
		switch (this._actorCommandWindow.currentSymbol()) {
			case "alchemy":
				this._alchemyWindow._skillWindow.show();
				this._alchemyWindow._skillWindow.activate();
				break;
		}
	};
	
	___FeatherA___Scene_Battle_changeInputWindow = Scene_Battle.prototype.changeInputWindow;
	Scene_Battle.prototype.changeInputWindow = function() {
		this._alchemyWindow.close();
		___FeatherA___Scene_Battle_changeInputWindow.call(this);
	};







//-----------------------------------------------------------------------------
// Window_AlchemyCommand
//
// The window for selecting an actor's action on the battle screen.

function Window_AlchemyCommand() {
    this.initialize(...arguments);
}

Window_AlchemyCommand.prototype = Object.create(Window_Command.prototype);
Window_AlchemyCommand.prototype.constructor = Window_AlchemyCommand;

Window_AlchemyCommand.prototype.initialize = function(rect) {
    Window_Command.prototype.initialize.call(this, rect);
	this.showHelpWindow();
    this.openness = 0;
    this.deactivate();
    this._actor = null;
	this._parentScene = null;
};

Window_AlchemyCommand.prototype.isActive = function() {
	return this.isOpen() || this.isOpening();
}

Window_AlchemyCommand.prototype.close = function() {
	if (this._parentScene) {
		this._skillWindow.destroy();
		this._creationWindow.destroy();
		this._parentScene._statusWindow.open();
		this._parentScene._statusWindow._forceClosing = false;
		this.hideHelpWindow();
	}
	Window_Command.prototype.close.call(this);
}

Window_AlchemyCommand.prototype.drawItem = function(index) {
    const rect = this.itemLineRect(index);
    const align = this.itemTextAlign();
    this.resetTextColor();
    this.changePaintOpacity(this.isCommandEnabled(index));
  this.drawTextEx(this.commandName(index), rect.x, rect.y, rect.width);
};

Window_AlchemyCommand.prototype.createAlchemyWindow = function() {
    const rect = this.skillWindowRect();
    this._skillWindow = new Window_AlchemyList(rect);
    this._skillWindow.setHelpWindow(this._helpWindow);
    this._skillWindow.setHandler("ok", this.onSkillOk.bind(this));
    this._skillWindow.setHandler("cancel", this.onSubWindowCancel.bind(this));
	this._skillWindow.setActor(this.actor());
	this._skillWindow.cursorVisible = false;
	this._skillWindow.show();
	this._skillWindow.close();
	this._skillWindow.zIndex = -1;
    this._parentScene.addWindow(this._skillWindow);
};

Window_AlchemyCommand.prototype.skillWindowRect = function() {
	const wh = Window_Selectable.prototype.fittingHeight(4);
	const wx = 300;
	const ww = Graphics.boxWidth - wx;
	const wy = Graphics.boxHeight - wh;
	return new Rectangle(wx, wy, ww, wh);
};	

Window_AlchemyCommand.prototype.createAlchemyCreationWindow = function() {
    const rect = this.alchemyCreationWindowRect();
    this._creationWindow = new Window_AlchemyCreation(rect);
    this._creationWindow.setHelpWindow(this._helpWindow);
    this._creationWindow.setHandler("cancel", this.onSubWindowCancel.bind(this));
	this._creationWindow.setup(this.actor(), this._parentScene, this);
	this._creationWindow.cursorVisible = false;
	this._creationWindow.show();
	this._creationWindow.close();
	this._creationWindow.zIndex = -1;
    this._parentScene.addWindow(this._creationWindow);
};

Window_AlchemyCommand.prototype.alchemyCreationWindowRect = function() {
	const wh = 600;
	const wx = 450;
	const ww = 600;
	const wy = Graphics.boxHeight - wh;
	return new Rectangle(wx, wy, ww, wh);
};	

Window_AlchemyCommand.prototype.makeCommandList = function() {
    if (this._actor) {
        this.addCommand("\\I[79]Lancer un sort", "use");
        this.addCommand("\\I[447]Créer un sort", "make");
		this.setHandler("use", this.commandUse.bind(this));
		this.setHandler("make", this.commandMake.bind(this));
    }
};

Window_AlchemyCommand.prototype.commandUse = function() {
	this._skillWindow.cursorVisible = true;
    this._skillWindow.refresh();
    this._skillWindow.show();
    this._skillWindow.activate();
	this.deactivate();
}

Window_AlchemyCommand.prototype.onSkillOk = function() {
    const skill = this._skillWindow.item();
    const action = BattleManager.inputtingAction();
	skill.isAlchemySkill = true;
	action._item.setObject(skill);
	action._item._dataClass = "skill";
    action._item.object = function() {return skill};
	action.isValid = function() {
		return (this._forcing && this.item()) || this.subject().meetsSkillConditions(this.item());
	}
    BattleManager.actor().setLastBattleSkill(skill);
    this._parentScene.onSelectAction();
};

Window_AlchemyCommand.prototype.onSubWindowCancel = function() {
    this._skillWindow.deactivate();
	this._creationWindow.deactivate();
	this._skillWindow.cursorVisible = false;
	this._creationWindow.cursorVisible = false;
	this.showHelpWindow();
    this.activate();
};

Window_AlchemyCommand.prototype.commandMake = function() {
	this._creationWindow.cursorVisible = true;
    this._creationWindow.refresh();
    this._creationWindow.show();
    this._creationWindow.activate();
	this.deactivate();
}

Window_AlchemyCommand.prototype.setup = function(actor, parentScene) {
    this._actor = actor;
	this._parentScene = parentScene;
	this.createAlchemyWindow();
	this.createAlchemyCreationWindow();
	this.parent.sortChildren();
    this.refresh();
    this.selectLast();
    this.activate();
    this.open();
};

Window_AlchemyCommand.prototype.update = function() {
	Window_Command.prototype.update.call(this);
	if (this._skillWindow && this.active) {
		if (this.index() === 0) {
			this._skillWindow.open();
			this._helpWindow.setText("Lancer un sort créé à partir d'une transmutation.")
		}
		else this._skillWindow.close();
		if (this.index() === 1) {
			this._creationWindow.open();
			this._helpWindow.setText("Créer un nouveau sort en puisant l'énergie environnante grâce à un cercle de transmutation.")
		}
		else this._creationWindow.close();
	}
}

Window_AlchemyCommand.prototype.refresh = function() {
    Window_Command.prototype.refresh.call(this);
	if (this.actor()) this.drawRessources();
};

Window_AlchemyCommand.prototype.drawRessources = function() {
	
	
	const elemLength = this.actor()._elements.length;
	const elemMiddle = Math.ceil(this.actor()._elements.length/2);
	
	for (let i = 0; i<elemMiddle; i++) {
		
		this.drawText(`${this.actor()._elements[i].count<<0}`, i*this.innerWidth/elemMiddle, 85, this.innerWidth/(elemMiddle*2), "center");
		this.drawIcon(this.actor()._elements[i].element.icon, (i+0.5)*this.innerWidth/elemMiddle, 85+2);
		
	}
	for (let i = elemMiddle; i<elemLength; i++) {
		
		this.drawText(`${this.actor()._elements[i].count<<0}`, (i-elemMiddle)*this.innerWidth/elemMiddle, 115, this.innerWidth/(elemMiddle*2), "center");
		this.drawIcon(this.actor()._elements[i].element.icon, (i-elemMiddle+0.5)*this.innerWidth/elemMiddle, 115+2);
		
	}
	this.contents.fontSize -= 6;
	if (this.actor().philosopherStone) {
		this.changeTextColor(ColorManager.mpCostColor());
		this.drawText(`∞ PM`, 4, 145, this.innerWidth/4, "center");
		this.changeTextColor(ColorManager.tpCostColor());
		this.drawText(`∞ PT`, 4+this.innerWidth/4, 145, this.innerWidth/4, "center");
		this.changeTextColor(ColorManager.textColor(17));
		this.drawText(`${this.actor()._ut}`, 4+4*this.innerWidth/8, 145, this.innerWidth/8, "right");
		this.drawIcon(459, 4+5*this.innerWidth/8, 145+2);
		this.drawIcon(1113, 4+6.5*this.innerWidth/8, 145+2);
	} else {
		this.changeTextColor(ColorManager.mpCostColor());
		this.drawText(`${this.actor().mp} PM`, 4, 145, this.innerWidth/3, "center");
		this.changeTextColor(ColorManager.tpCostColor());
		this.drawText(`${this.actor().tp} PT`, 4+this.innerWidth/3, 145, this.innerWidth/3, "center");
		this.changeTextColor(ColorManager.textColor(17));
		this.drawText(`${this.actor()._ut}`, 4+4*this.innerWidth/6, 145, this.innerWidth/6, "right");
		this.drawIcon(459, 4+5*this.innerWidth/6, 145+2);
	}
	this.contents.fontSize += 6;
	
};

Window_AlchemyCommand.prototype.actor = function() {
    return this._actor;
};

Window_AlchemyCommand.prototype.processOk = function() {
    if (this._actor) {
        if (ConfigManager.commandRemember) {
            this._actor.setLastCommandSymbol(this.currentSymbol());
        } else {
            this._actor.setLastCommandSymbol("");
        }
    }
    Window_Command.prototype.processOk.call(this);
};

Window_AlchemyCommand.prototype.selectLast = function() {
    this.forceSelect(0);
    if (this._actor && ConfigManager.commandRemember) {
        const symbol = this._actor.lastCommandSymbol();
        this.selectSymbol(symbol);
    }
};

Window_AlchemyCommand.prototype.updateHelp = function() {
    //
};






//-----------------------------------------------------------------------------
// Window_AlchemySelectElement
//
// The window for selecting an actor's action on the battle screen.

function Window_AlchemySelectElement() {
    this.initialize(...arguments);
}

Window_AlchemySelectElement.prototype = Object.create(Window_SkillList.prototype);
Window_AlchemySelectElement.prototype.constructor = Window_AlchemySelectElement;

Window_AlchemySelectElement.prototype.initialize = function() {
	const width = 48*3+$gameSystem.windowPadding()*2;
	const height = 48*3+$gameSystem.windowPadding()*2;
	const rect = new Rectangle(-width,-height,width,height);
    Window_Selectable.prototype.initialize.call(this, rect);
    this._actor = null;
    this._elements = [];
};

Window_AlchemySelectElement.prototype.setup = function(actor,elements,creationWindow) {
    if (this._actor !== actor) {
        this._actor = actor;
		this._elements = elements;
		this._creationWindow = creationWindow;
        this.refresh();
        this.scrollTo(0, 0);
    }
};

Window_AlchemySelectElement.prototype.itemWidth = function() {
    return 48;
};

Window_AlchemySelectElement.prototype.itemHeight = function() {
    return 48;
};

Window_AlchemySelectElement.prototype.maxCols = function() {
    return 3;
};

Window_AlchemySelectElement.prototype.colSpacing = function() {
    return 0;
};

Window_AlchemySelectElement.prototype.maxItems = function() {
    return this._elements ? this._elements.length : 1;
};

Window_AlchemySelectElement.prototype.itemAt = function(index) {
    return this._elements && index >= 0 ? this._elements[index] : null;
};

Window_AlchemySelectElement.prototype.isCurrentItemEnabled = function() {
    return this.isEnabled(this._elements[this.index()]);
};

Window_AlchemySelectElement.prototype.isEnabled = function(item) {
    return !item.ressource || 
		(this._actor && 
			(item.mpcost || 0) <= this._actor.mp-this._creationWindow.calcTotalMpCost() &&
			(item.tpcost || 0) <= this._actor.tp-this._creationWindow.calcTotalTpCost() &&
			(item.utcost || 0) <= this._actor._ut-this._creationWindow.calcTotalUtCost() &&
			this._actor._elements.some(a => a.element === item) &&
			this._actor._elements.find(a => a.element === item).count > this._creationWindow.calcElementCount(item)
		);
};

Window_AlchemySelectElement.prototype.selectLast = function() {
    //
};

Window_AlchemySelectElement.prototype.drawItem = function(index) {
    const element = this.itemAt(index);
    if (element) {
        const rect = this.itemLineRect(index);
        this.changePaintOpacity(this.isEnabled(element));
        this.drawIcon(element.icon,rect.x+(rect.width - ImageManager.iconWidth)/2,rect.y+(rect.height - ImageManager.iconHeight)/2);
        this.changePaintOpacity(1);
    }
};

Window_AlchemySelectElement.prototype.updateHelp = function() {
	
	const mpCost = this._creationWindow.calcMpCost(this.item());
	const tpCost = this._creationWindow.calcTpCost(this.item());
	const utCost = this._creationWindow.calcUtCost(this.item());
	
	if (!mpCost && !tpCost && !utCost)
		this._helpWindow.setText(`${this.item().name}`)
	else 
		this._helpWindow.setText(`${this.item().name} ( \\C[23]${mpCost || ""}${mpCost ? " PM " : ""}\\C[29]${tpCost || ""}${tpCost ? " PT " : ""}\\C[17]${utCost || ""}${utCost ? "\\I[459]" : ""}\\C[0])`)
};


Window_AlchemySelectElement.prototype.refresh = function() {
    Window_Selectable.prototype.refresh.call(this);
};


//-----------------------------------------------------------------------------
// Window_AlchemySelectCircle
//
// The window for selecting an actor's action on the battle screen.

function Window_AlchemySelectCircle() {
    this.initialize(...arguments);
}

Window_AlchemySelectCircle.prototype = Object.create(Window_SkillList.prototype);
Window_AlchemySelectCircle.prototype.constructor = Window_AlchemySelectCircle;

Window_AlchemySelectCircle.prototype.initialize = function() {
	const width = 300;
	const height = 200;
	const rect = new Rectangle(-width,-height,width,height);
    Window_Selectable.prototype.initialize.call(this, rect);
    this._actor = null;
    this._circles = [];
};

Window_AlchemySelectCircle.prototype.setup = function(actor,circles) {
    if (this._actor !== actor) {
        this._actor = actor;
		this._circles = circles;
        this.refresh();
		const height = Math.min(200,this.fittingHeight(this.maxItems()))
		this.move(this.x, -height, this.width, height);
        this.scrollTo(0, 0);
    }
};

Window_AlchemySelectCircle.prototype.maxCols = function() {
    return 1;
};

Window_AlchemySelectCircle.prototype.maxItems = function() {
    return this._circles ? this._circles.length : 1;
};

Window_AlchemySelectCircle.prototype.itemAt = function(index) {
    return this._circles && index >= 0 ? this._circles[index] : null;
};

Window_AlchemySelectCircle.prototype.isCurrentItemEnabled = function() {
    return this.isEnabled(this._circles[this.index()]);
};

Window_AlchemySelectCircle.prototype.isEnabled = function(item) {
    return true;
};

Window_AlchemySelectCircle.prototype.selectLast = function() {
    //
};

Window_AlchemySelectCircle.prototype.drawItem = function(index) {
    const circle = this.itemAt(index);
    if (circle) {
        const rect = this.itemLineRect(index);
        this.changePaintOpacity(this.isEnabled(circle));
        this.drawText(circle.name,rect.x,rect.y, rect.width, "center");
        this.changePaintOpacity(1);
    }
};

Window_AlchemySelectCircle.prototype.updateHelp = function() {
    //
};


Window_AlchemySelectCircle.prototype.refresh = function() {
    Window_Selectable.prototype.refresh.call(this);
};


//-----------------------------------------------------------------------------
// Window_AlchemyCreation
//
// The window for selecting an actor's action on the battle screen.

function Window_AlchemyCreation() {
    this.initialize(...arguments);
}

Window_AlchemyCreation.prototype = Object.create(Window_Selectable.prototype);
Window_AlchemyCreation.prototype.constructor = Window_AlchemyCreation;

Window_AlchemyCreation.prototype.initialize = function(rect) {
    Window_Selectable.prototype.initialize.call(this, rect);
    this.openness = 0;
    this.deactivate();
    this._actor = null;
	this._parentScene = null;
	this.philosophicalCircle = false;
};

Window_AlchemyCreation.prototype.update = function() {
	Window_Selectable.prototype.update.call(this);
	if (this.index() > 0 && this.index() < this.bloodPact.length && Input.isTriggered("orderChange") && this.actor().skills().some(a => a.meta.ForbiddenKnowledge)) {
		AudioManager.playSe({name: 'Darkness7', pan: 0, pitch: 150, volume: 80});
		this.bloodPact[this.index()] = !this.bloodPact[this.index()]
		this.refresh();
	}

	if (this.actor().philosopherStone && Input.isTriggered("philosophicalCircle")) {
		this.philosophicalCircle = !this.philosophicalCircle;
		this.loadCircle(this._circle);
		if (this.philosophicalCircle) AudioManager.playSe({name: 'DevourerAttack', pan: 0, pitch: 100, volume: 80});
		AudioManager.playSe({name: 'Sword1', pan: 0, pitch: 100, volume: 80});
		this.refresh();
	}

}

Window_AlchemyCreation.prototype.createSelectWindow = function() {
	
    this._selectWindow = new Window_AlchemySelectElement();
    this._selectWindow.setHelpWindow(this._helpWindow);
    this._selectWindow.setHandler("ok", this.onSelectOk.bind(this));
    this._selectWindow.setHandler("cancel", this.onSelectCancel.bind(this));
	this._selectWindow.setup(this.actor(),this.Elements,this);
	this._selectWindow.show();
	this._selectWindow.close();
    this._parentScene.addWindow(this._selectWindow);
}

Window_AlchemyCreation.prototype.createSelectCircleWindow = function() {
	
    this._selectCircleWindow = new Window_AlchemySelectCircle();
    this._selectCircleWindow.setHelpWindow(this._helpWindow);
    this._selectCircleWindow.setHandler("ok", this.onSelectCircleOk.bind(this));
    this._selectCircleWindow.setHandler("cancel", this.onSelectCircleCancel.bind(this));
	this._selectCircleWindow.setup(this.actor(),this.Circles.filter((a,b) => this.actor().skills().some(c => eval(c.meta.UnlockCircle)-1 === b),this));
	this._selectCircleWindow.show();
	this._selectCircleWindow.close();
    this._parentScene.addWindow(this._selectCircleWindow);
	
}

Window_AlchemyCreation.prototype.createElements = function() {

	this.Elements = Feather_Alchemy.Elements;

}

Window_AlchemyCreation.prototype.initIngredients = function(forced) {
	
	for (let i = 1; i<=this.maxAlchemyElems(); i++) {
		if (forced || !this.ingredients[i]) {
			this.ingredients[i] = this.Elements[0];
			this.bloodPact[i] = false;
		}
	}
	
}

Window_AlchemyCreation.prototype.maxAlchemyElems = function() {
    return this._circle.size;
};

Window_AlchemyCreation.prototype.maxItems = function() {
    return 2 + this.maxAlchemyElems();
};

Window_AlchemyCreation.prototype.itemWidth = function() {
    return 48;
};

Window_AlchemyCreation.prototype.itemHeight = function() {
    return 48;
};

Window_AlchemyCreation.prototype.itemRect = function(index) {
    let itemWidth = this.itemWidth();
    let itemHeight = this.itemHeight();
	let x;
	let y;
	if (index > 0 && index <= this.maxAlchemyElems()) {
		x = this.width/2-this.padding-itemWidth/2 + ((Math.cos((index/this.maxAlchemyElems())*2*Math.PI)*this._circle.space)<<0);
		y = this.height/2-this.padding-itemHeight/2 + ((Math.sin((index/this.maxAlchemyElems())*2*Math.PI)*this._circle.space)<<0);
    }
	if (index == 0) {
		x = this.width/2-this.padding-itemWidth/2;
		y = this.height/2-this.padding-itemHeight/2;
	}
	if (index-this.maxAlchemyElems() == 1) {
		itemWidth = 200;
		itemHeight = 36;
		x = this.width/2-this.padding-itemWidth/2;
		y = this.height-6-this.padding*2-itemHeight;
	}
	const width = itemWidth;
    const height = itemHeight;
    return new Rectangle(x, y, width, height);
};

Window_AlchemyCreation.prototype.createCircles = function() {

	this.Circles = Feather_Alchemy.Circles;
	this._circle = this.Circles[0];
	this._circleBitmap = this._circle.img;
}

Window_AlchemyCreation.prototype.loadCircle = function(circle) {
	
	this._circle = circle;
	this._circleBitmap = this._circle.img;
	this.forceSelect(this.index());
	
	while ((this._actor.mp-this.calcTotalMpCost() < 0 ||
			this._actor.tp-this.calcTotalTpCost() < 0 ||
			this._actor._ut-this.calcTotalUtCost() < 0) &&
			this.ingredients.length > 0) {
				this.ingredients.pop();
				if (this.bloodPact.length > 1)
					this.bloodPact.pop();
			}
	
	if (this.maxAlchemyElems() > this.ingredients.length-1) {
		this.initIngredients();
	}
	else
		while (this.maxAlchemyElems() < this.ingredients.length-1) {
			this.ingredients.pop();
			this.bloodPact.pop();
		}
	
	this._selectWindow.refresh();
	this.refresh();
}


Window_AlchemyCreation.prototype.checkIncomplete = function() {
	return this.ingredients.includes(this.Elements[0]);
}

Window_AlchemyCreation.prototype.checkUniqueElement = function() {
	if (this.checkIncomplete()) return 0;
	return this.Elements.map(a => this.calcElementCount(a)).includes(this.ingredients.length-1);
}

Window_AlchemyCreation.prototype.checkBalance = function() {
	if (this.checkIncomplete() || this.checkUniqueElement()) return 0;
	return this.Elements.map(a => this.calcElementCount(a)).filter(a => a).every((a,b,c) => a === c[0]);
}

Window_AlchemyCreation.prototype.checkMajorant = function() {
	if (this.checkIncomplete() || this.checkUniqueElement()) return 0;
	return this.Elements.map(a => this.calcElementCount(a)).filter((a,b,c) => Math.max(...c) === a).length === 1;
}

Window_AlchemyCreation.prototype.checkStability = function() {
	if (this.checkIncomplete() || !this.checkBalance()) return 0;
	if (this.calcElementCount(this.ingredients[1]) === 1) return 1;
	return this.Elements.filter(a => this.calcElementCount(a)).map(element => this.ingredients.filter((a,b) => b>0).map((a,b,c) => {
		if (a !== element) return -1;
		let i, j;
		for (i = 1; (c[b+i] && c[b+i] !== element) || (!c[b+i] && c[-c.length+i+b] && c[-c.length+i+b] !== element); i++);
		for (j = 1; (c[b-j] && c[b-j] !== element) || (!c[b-j] && c[c.length-(j-b)] && c[c.length-(j-b)] !== element); j++);
		return Math.min(i,j);
	}).filter(a => a !== -1).reduce((a,b) => (a === b) && b)).every((a,b,c) => a > 0 && a === c[0]);
}



Window_AlchemyCreation.prototype.calcElementCount = function(element) {
	return this.ingredients.reduce((a,b) => a + (b === element), 0);
}

Window_AlchemyCreation.prototype.calcMpCost = function(ingredient) {
	return (ingredient.mpcost || 0)*this._circle.costMultiplier;
}

Window_AlchemyCreation.prototype.calcTpCost = function(ingredient) {
	return (ingredient.tpcost || 0)*this._circle.costMultiplier;
}

Window_AlchemyCreation.prototype.calcUtCost = function(ingredient) {
	return (ingredient.utcost || 0)*this._circle.costMultiplier;
}

Window_AlchemyCreation.prototype.calcTotalMpCost = function() {
	return this.Elements.reduce((a,b) => a + this.calcMpCost(b)*this.calcElementCount(b),0) + (this._circle.mpcost || 0);
}

Window_AlchemyCreation.prototype.calcTotalTpCost = function() {
	return this.Elements.reduce((a,b) => a + this.calcTpCost(b)*this.calcElementCount(b),0) + (this._circle.tpcost || 0);
}

Window_AlchemyCreation.prototype.calcTotalUtCost = function() {
	return this.Elements.reduce((a,b) => a + this.calcUtCost(b)*this.calcElementCount(b),0) + (this._circle.utcost || 0) + this.philosophicalCircle*20;
}

Window_AlchemyCreation.prototype.calcTotalHpCost = function() {
	return (this.actor().mhp/10)*this.bloodPact.reduce((a,b) => a + !!b,-1);
}

Window_AlchemyCreation.prototype.getIngredient = function(index) {
	return this.ingredients[index]
}

Window_AlchemyCreation.prototype.drawIngredientIcon = function(ingredient, x, y) {
	this.drawIcon(ingredient.icon, x, y);
}

Window_AlchemyCreation.prototype.drawItem = function(index) {
	const mpCost = this.calcTotalMpCost();
	const tpCost = this.calcTotalTpCost();
	const utCost = this.calcTotalUtCost();
	const hpCost = this.calcTotalHpCost();
	
	const rect = this.itemLineRect(index);
	const paddingX = (rect.width-ImageManager.iconWidth)/2;
	const paddingY = (rect.height-ImageManager.iconHeight)/2;
	this.changeTextColor(ColorManager.normalColor());
	if (index == 0) {
		if (this.actor().skills().some(a => a.meta.ForbiddenKnowledge)) this.drawTextEx("\\I[322]:Lien de sang",0,0,this.width);
		if (this.actor().philosopherStone) this.drawTextEx("\\I[335]:Cercle philosophal",300,0,this.width);
		this.bloodPact[0].children = [];
		if (this.philosophicalCircle) this.drawIcon(1113,rect.x+paddingX,rect.y+paddingY);
		else this.drawIcon(443,rect.x+paddingX,rect.y+paddingY);
	} 
	if (index > 0 && index <= this.maxAlchemyElems()) {
		if (this.bloodPact[index]) {
			let x1 = rect.x+rect.width/2;
			let y1 = rect.y+rect.height/2;
			for (let i = index+1; i<=this.maxAlchemyElems(); i++) if (this.bloodPact[i]) {
				let goalRect = this.itemLineRect(i);
				let x2 = goalRect.x+goalRect.width/2;
				let y2 = goalRect.y+goalRect.height/2;
				let length = Math.sqrt(Math.pow(x1-x2,2)+Math.pow(y1-y2,2))
				let angle = Math.atan2(y2-y1,x2-x1);
				let bloodLine = new Sprite();
				bloodLine.bitmap = Feather_Core.preloadRessources['bloodLine'];
				bloodLine.anchor.x = 0;
				bloodLine.anchor.y = 0.5;
				bloodLine.x = x1 + Math.cos(angle)*35;
				bloodLine.y = y1 + Math.sin(angle)*35;
				bloodLine.angle = angle*180/Math.PI;
				bloodLine.scale.x = (length-70)/bloodLine.bitmap.width;
				this.bloodPact[0].addChild(bloodLine);
			}
			let bloodPact = new Sprite();
			bloodPact.bitmap = Feather_Core.preloadRessources['bloodCircle'];
			bloodPact.anchor.x = 0.5;
			bloodPact.anchor.y = 0.5;
			bloodPact.x = x1;
			bloodPact.y = y1;
			this.bloodPact[0].addChild(bloodPact);
		}
		
		this.drawIngredientIcon(this.getIngredient(index),rect.x+paddingX,rect.y+paddingY);
	}
	if (index-this.maxAlchemyElems() == 1) {
		this.drawText("Fabriquer",rect.x,rect.y,rect.width,"center");
		
		const x = rect.x+rect.width+this.padding;
		const width = this.innerWidth-x;
		this.contents.fontSize -= 6;
		let i = 0;
		if (mpCost) {
			this.changeTextColor(ColorManager.mpCostColor());
			this.drawText(`${mpCost} PM`, x, rect.y, width/3, "center");
			i++;
		}
		if (tpCost) {
			this.changeTextColor(ColorManager.tpCostColor());
			this.drawText(`${tpCost} PT`, x+i*width/3, rect.y, width/3, "center");
			i++;
		}
		if (utCost) {
			this.changeTextColor(ColorManager.textColor(17));
			this.drawText(`${utCost}`, x+2*i*width/6, rect.y, width/6, "right");
			this.drawIcon(459, x+(2*i+1)*width/6, rect.y+2);
		}
		this.contents.fontSize += 6;
		if (hpCost) {
			this.changeTextColor(ColorManager.deathColor());
			this.drawText(`${hpCost} PV`, 0, rect.y, width, "center");
		}
	}
    //this.drawText(this.commandName(index), rect.x, rect.y, rect.width, align);
};

Window_AlchemyCreation.prototype.onOk = function() {
	
	const mpCost = this.calcTotalMpCost();
	const tpCost = this.calcTotalTpCost();
	const utCost = this.calcTotalUtCost();
	const hpCost = this.calcTotalHpCost();
	
	const index = this.index();
	const rect = this.itemLineRect(index);
	
	if (index === 0) {
		this.deactivate();
		this._selectCircleWindow.forceSelect(0);
		this._selectCircleWindow.open();
		this._selectCircleWindow.activate();
		this._selectCircleWindow.x = this.x + rect.x + rect.width/2 - this._selectCircleWindow.width/2 + this.padding;
		this._selectCircleWindow.y = this.y + rect.y + rect.height/2 - this._selectCircleWindow.height/2 + this.padding;
	}
	if (index > 0 && index <= this.maxAlchemyElems()) {
		this.deactivate();
		this._selectWindow.forceSelect(this.getIngredient(index).id);
		this._selectWindow.open();
		this._selectWindow.activate();
		this._selectWindow.x = this.x + rect.x + rect.width/2 - this._selectWindow.width/2 + this.padding;
		this._selectWindow.y = this.y + rect.y + rect.height/2 - this._selectWindow.height/2 + this.padding;
	}
	if (index-this.maxAlchemyElems() == 1) {
		if (this.createSkill()) {
			this.actor().gainMp(-mpCost);
			this.actor().gainTp(-tpCost);
			this.actor()._ut -= utCost;
			this.actor()._hp -= hpCost;
			for (let item of this.actor()._elements)
				item.count -= this.calcElementCount(item.element);
			AudioManager.playSe({name: 'Magic12', pan: 0, pitch: 150, volume: 80});
			AudioManager.playSe({name: 'Magic6', pan: 0, pitch: 150, volume: 80});
			$gameScreen.startFlash([255,255,255,255],30);
			this._parentWindow._skillWindow.refresh();
		} else {
			AudioManager.playSe({name: 'Down3', pan: 0, pitch: 100, volume: 80});
		}
		this.initIngredients(1);
		this.refresh();
		this.deactivate();
		this.cursorVisible = false;
		this._parentWindow.refresh();
		this._parentWindow.activate();
	}
	
};

Window_AlchemyCreation.prototype.onSelectCancel = function() {
	
	this._selectWindow.close();
	this._selectWindow.deactivate();
	this.refresh();
	this.activate();
	
};

Window_AlchemyCreation.prototype.onSelectOk = function() {
	
	this.ingredients[this.index()] = this._selectWindow.item();
	this.refresh();
	this._selectWindow.close();
	this._selectWindow.deactivate();
	this._selectWindow.refresh();
	this.activate();
	
};

Window_AlchemyCreation.prototype.onSelectCircleCancel = function() {
	
	this._selectCircleWindow.close();
	this._selectCircleWindow.deactivate();
	this.refresh();
	this.activate();
	
};

Window_AlchemyCreation.prototype.onSelectCircleOk = function() {
	
	this.loadCircle(this._selectCircleWindow.item());
	this.refresh();
	this._selectCircleWindow.close();
	this._selectCircleWindow.deactivate();
	this.activate();
	
};

Window_AlchemyCreation.prototype.actor = function() {
	return this._actor;
}

Window_AlchemyCreation.prototype.setup = function(actor, parentScene, parentWindow) {
    if (this._actor !== actor) {
        this._actor = actor;
		this._parentScene = parentScene;
		this._index = 0;
		this._parentWindow = parentWindow;
		this.setHandler("ok", this.onOk.bind(this));
		this.createCircles();
		this.createElements();
		
		this.bloodPact = [];
		this.ingredients = [];
		this.initIngredients();
		this.children[1].children[0].zIndex = -2;
		this.bloodPact[0] = new Sprite();
		this.bloodPact[0].zIndex = -1;
		this.children[1].addChild(this.bloodPact[0]);
		this.children[1].sortChildren();

		this.createSelectWindow();
		this.createSelectCircleWindow();
        this.refresh();
    }
};

Window_AlchemyCreation.prototype.paint = function() {
    if (this.contents) {
        this.contents.clear();
        this.contentsBack.clear();
		this.contentsBack.blt(this._circleBitmap, 0, 0, 600, 600, -this.padding, -this.padding);
        this.drawAllItems();
    }
};

Window_AlchemyCreation.prototype.updateHelp = function() {
    //
};

Window_AlchemyCreation.prototype.refresh = function() {
    this.drawAllItems();
	let helpText = `<wordwrap>${this._circle.name} : `;
	this.ingredients.forEach((item, i, c) => {
		if (c.indexOf(item) === i && !item.hidden)
			helpText += `${item.name}   ${this.calcElementCount(item)}00% `;
	}, this)
	this._helpWindow.setText(helpText)
    Window_Selectable.prototype.refresh.call(this);
};


Window_AlchemyCreation.prototype.recipe = function(ingredients,ingredientsIds,results,forcedElements) {
	
	if (forcedElements && !forcedElements.every(a => ingredientsIds.includes(a))) return ingredients;
	const blendId = ingredients.length-1;
	if (ingredients.reduce((a,b,c) => a && (!ingredientsIds.includes(c) || b > 0))) {
		
		ingredientsIds.forEach(a => ingredients[a]--);
		for (let item of results) {
			ingredients[blendId][item]++;
		}
		
	}
	return ingredients;
	
}


Window_AlchemyCreation.prototype.blend = function(ingredients, forcedElements, leastToMostPriority) {
	console.log(forcedElements);
	Feather_Alchemy.RecipesCategories[this._circle.category].recipes.sort((a,b) => leastToMostPriority ? a.ingredients.length-b.ingredients.length : b.priority-a.priority).forEach(a => {
		if (!a.philosopherstone || this.philosophicalCircle) ingredients = this.recipe(ingredients,a.ingredients,a.results,forcedElements)
	}, this);

	return ingredients;
	
}


Window_AlchemyCreation.prototype.blendElements = function(ingredients) {
	
	const blendId = ingredients.length;
	const majorElemLevel = Math.max(...ingredients);
	let majorElem = ingredients.filter(a => majorElemLevel === a);
	majorElem = (majorElem.length === 1) ? this.Elements[ingredients.findIndex(a => a === majorElem[0])] : null;
	ingredients[blendId] = {};
	Object.assign(ingredients[blendId], Feather_Alchemy.Reactions.ingredients);
	
	if (this.calcTotalHpCost()) ingredients = this.blend(ingredients, ingredients.filter((a,b) => b > 0 && this.bloodPact[b]), 1);
	
	if (majorElem) ingredients = this.blend(ingredients, [ingredients[majorElem.id]]);
	
	if ((this.ingredients.length-1)%2 === 0) {
		const maxEnergy = this.ingredients.clone().sort((a,b) => b.energy - a.energy)[0].energy+1;
		const orderedIngredients = this.ingredients.filter((a,b) => b>0).map((a,b,c) => [a,c[b+c.length/2 + (b>=c.length/2 ? -c.length : 0)]]).sort((a,b) => (b[0].energy+b[1].energy/maxEnergy)-(a[0].energy+a[1].energy/maxEnergy));
		console.log(orderedIngredients);
		for (let i = 0; i<orderedIngredients.length; i++) {
			ingredients = this.blend(ingredients, [orderedIngredients[i][0].id, orderedIngredients[i][1].id]);
			
		}
	}
	const orderedIngredients = this.Elements.filter((a,b) => b > 0).sort((a,b) => b.energy-a.energy);
	for (let i = 0; i<orderedIngredients; i++)
		ingredients = this.blend(ingredients, [orderedIngredients[i]]);
	ingredients = this.blend(ingredients);
	
	return ingredients;
	
}


Window_AlchemyCreation.prototype.createSkill = function() {
	
	const Reactions = Feather_Alchemy.Reactions;
	let ingredients = this.Elements.map((a,b) => (b === 0 && -1) || this.calcElementCount(a));
	if (Math.max(...ingredients) === 0) return 0;
	if (this.philosophicalCircle) {
		ingredients[ingredients.length] = this.blendElements([...ingredients])[ingredients.length];
	} else ingredients = this.blendElements(ingredients);
	const reactions = ingredients.pop();
	const majorElemLevel = Math.max(...ingredients);
	const majorElem = this.Elements[ingredients.findIndex(a => majorElemLevel === a)];
	const elemId = majorElem.elemId;
	
	
	let target = eval(this._circle.target) || 1;
	let isGroupTarget = [2,8,10,13,14].includes(target);
	let animation
	let mpcost = this.calcTotalMpCost();
	let tpcost = this.calcTotalTpCost();
	let utcost = this.calcTotalUtCost() - this.philosophicalCircle*20;
	let icon;
	let formula;
	if (majorElemLevel) {
		icon = majorElem.icon;
		animation = majorElem.animations.normalAnim;
		if (isGroupTarget) animation = majorElem.animations.weakGroupAnim;
	} else {
		icon = 447;
		animation = 50;
		if (isGroupTarget) animation = 47;
	}
	
	let name = "";
	
	if (this._circle.prefix) name += this._circle.prefix;
	
	for (const [key, value] of Object.entries(reactions)) {
		let prefix = "";
		if (value > 0) {
			switch (value) {
				case 2:
					prefix += "di";
					break;
				case 3:
					prefix += "tri";
					break;
				case 4:
					prefix += "tetra";
					break;
				case 5:
					prefix += "quinte";
					break;
				case 6:
					prefix += "suprema";
					break;
			}
			prefix += Reactions[key].prefix;
			if (prefix[0]) name += prefix[0].toUpperCase() + prefix.substring(1) + " ";
		}
	}
	switch (majorElemLevel) {
		case 2:
			name += "Super-";
			break;
		case 3:
			name += "Mega-";
			animation = majorElem.animations.strongAnim;
			if (isGroupTarget) animation = majorElem.animations.weakGroupAnim;
			break;
		case 4:
			name += "Giga-";
			animation = majorElem.animations.strongAnim;
			if (isGroupTarget) animation = majorElem.animations.groupAnim;
			break;
		case 5:
			name += "Ultima-";
			animation = majorElem.animations.strongAnim;
			if (isGroupTarget) animation = majorElem.animations.strongGroupAnim;
			utcost += 3;
			break;
		case 6:
			name += "Philosophica-";
			animation = majorElem.animations.strongAnim;
			if (isGroupTarget) animation = majorElem.animations.strongGroupAnim;
			utcost += 5;
			break;
	}
	
	if (majorElemLevel) {
		name += majorElem.name.replace(/\\.|[^a-z]/gmi,"");
		formula = `${100+Math.min(4,majorElemLevel)*200} + a.mat * ${2*(majorElemLevel<=4)+5*(majorElemLevel===5)+8*(majorElemLevel>=6)} - b.mdf * ${2-(majorElemLevel>4)}`;
	} else {
		name += "Neutre";
		formula = null;
	}
	
	if (isGroupTarget) name += " Orbis";
	
	let spcost = 0;
	
	let effects = Feather_Alchemy.Reactions.reduce((a,b) => a.concat(b.results.map(c => {
		const thisCount = reactions[b.name];
		if (!thisCount) return null;
		if (typeof c.result === 'string') return c.result;
		const id = c.id;
		const param1 = c.param1;
		const param2 = c.param2;
		const paramJS = c.resultJS;
		const data = {};
		Object.assign(data,reactions);
		const effect = {};
		Object.assign(effect, c.result);
		if (effect.skill) return this.actor()._alchemySkills.push($dataSkills[eval(effect.skill)]), null;
		effect.code = eval(effect.code);
		effect.dataId = eval(effect.dataId);
		effect.value1 = eval(effect.value1);
		effect.value2 = eval(effect.value2);
		return effect;
	})),[]).filter(a => a);
	console.log(ingredients);
	if (effects.some(item => item === "Philosopher's Stone")) this.actor().refresh(), this.actor().philosopherStone = true;
	if (effects.some(item => item === "Cancel")) return 1;
	ingredients.shift();
	let elements = [];
	ingredients.forEach((a,b) => {
		elements = elements.concat(Array.apply(null,Array(a)).map(item => b+2));
	});
	return this.generateSkill(elements, name, icon, formula, target, effects, mpcost, tpcost, utcost, spcost, animation);
	
}


Window_AlchemyCreation.prototype.generateSkill = function(elements, name, icon, formula, target, effects, mpcost, tpcost, utcost, spcost, animation) {
	console.log(effects);
	return this.actor()._alchemySkills.push ({
		//id:416,
		animationId:animation,
		damage: {
			critical:false,
			elementId:0,
			formula:formula,
			type:(formula === null) ? 0 : 1,
			variance:20},
		description:(this.actor().skills().some(a => a.meta.AlchemyKnowledge)) ? name : name.toNorse(),
		effects: effects,
		hitType:2,
		iconIndex:icon,
		message1:"%1 attaque !",
		message2:"",
		mpCost:mpcost,
		name:name.toNorse(),
		note:`<UT Cost: ${utcost}> <SP Cost: ${spcost}> <Multi-Element: ${elements}>`,
		occasion:1,
		repeats:1,
		requiredWtypeId1:0,
		requiredWtypeId2:0,
		scope:target,
		speed:0,
		//stypeId:2,
		successRate:100-this.checkIncomplete()*50,
		tpCost:tpcost,
		tpGain:0,
		messageType:1,
		meta:[{"UT Cost":utcost},{"SP Cost":spcost},{"Multi-Element":`${elements}`}],
		longMeta:{}
	});
}



//-----------------------------------------------------------------------------
// Window_AlchemyList
//
// The window for selecting a skill on the skill screen.

function Window_AlchemyList() {
    this.initialize(...arguments);
}

Window_AlchemyList.prototype = Object.create(Window_BattleSkill.prototype);
Window_AlchemyList.prototype.constructor = Window_AlchemyList;

Window_AlchemyList.prototype.initialize = function(rect) {
    Window_Selectable.prototype.initialize.call(this, rect);
    this._actor = null;
    this._data = [];
};

Window_AlchemyList.prototype.isEnabled = function(item) {
    return this._actor && item && this._actor.meetsSkillConditions(item);
};

Window_AlchemyList.prototype.makeItemList = function() {
    if (this._actor) {
        this._data = this._actor._alchemySkills; // [{"id":0,"animationId":-1,"damage":{"critical":true,"elementId":-1,"formula":"a.atk * 400 - b.def * 2","type":1,"variance":20},"description":"Permet d’effectuer une double attaque sur un ennemi.","effects":[{"code":21,"dataId":0,"value1":1,"value2":0}],"hitType":1,"iconIndex":76,"message1":"%1 attaque !","message2":"","mpCost":0,"name":"Double attaque","note":"","occasion":1,"repeats":1,"requiredWtypeId1":0,"requiredWtypeId2":0,"scope":4,"speed":0,"stypeId":2,"successRate":100,"tpCost":5,"tpGain":0,"messageType":1,"meta":{},"longMeta":{}}];
    } else {
        this._data = [];
    }
};



___FeatherA___BattleManager_endAction = BattleManager.endAction;
BattleManager.endAction = function() {
	const subject = this._subject;
	const action = this._action;
	if (action && action.item().meta.RegenerateElements) {
		const ressources = Feather_Alchemy.Elements.filter(a => a.ressource);
		for (let i = 0; i<ressources.length; i++) {
			subject._elements[i].count += subject.getStartElementCount(ressources[i].elemId)*eval(action.item().meta.RegenerateElements);
		}
	}
	if (action && action.item().meta.RegenerateElement) {
		const ressources = Feather_Alchemy.Elements.filter(a => a.ressource);
		const elem = eval(action.item().meta.RegenerateElement);
		subject._elements.find(a => a.element.elemId === elem[0]).count += subject.getStartElementCount(elem[0])*elem[1];
	}
	if (action && action.item().meta.GenerateElement) {
		const elem = eval(action.item().meta.GenerateElement);
		subject._elements.find(a => a.element.elemId === elem[0]).count += elem[1];
	}
	___FeatherA___BattleManager_endAction.call(this);
};

})();
