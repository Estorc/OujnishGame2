//=============================================================================
// RPG Maker MZ - StatesMoreMetas
//=============================================================================

/*:
 * @target MZ
 * @plugindesc States More Metas system plugin.
 * @author Feather
 *
 * @help 
 * States More Metas system plugin.
 *
 */
 

(() => {
    const pluginName = "StatesMoreMetas";
	
	
	
	
	
	applyDeathCounter = function(stateId) {
		
		if ((stateId === 1 || $dataStates[stateId].meta.DeathCounterpart) && this.states().some(item => item.meta.DeathCounter)) {
			this._hp = this.mhp;
			this.states().some(item => item.meta.DeathCounterpart) && this.eraseState.apply(this,this.states().filter(item => item.meta.DeathCounterpart).id);
			this.eraseState.apply(this,this.states().filter(item => item.meta.DeathCounter).id);
			this.eraseState(1);
			this.refresh();
			this._result.pushRemovedState(1);
			AudioManager.playSe({name: 'Magic12', pan: 0, pitch: 100, volume: 100});
		}
		
	}
	
	
	
	applyRegenesis = function(stateId) {
	
		if ($dataStates[stateId].meta.Regenesis) {
			
			this._hp = (this.mhp/2) << 0;
			this.eraseState(1);
			this.refresh();
			this._result.pushRemovedState(1);
			AudioManager.playSe({name: 'Magic12', pan: 0, pitch: 100, volume: 100});
			return 0
				
		}
		
		return 1;
	
	}
	
	
	applyDeathCounterpart = function(stateId) {
		
		if (this.isStateAddable(stateId)) {
			if ($dataStates[stateId].meta.DeathCounterpart) {
				stateId = 1;
				if (!this.isStateAffected(stateId)) {
					this.addNewState(stateId);
					this.refresh();
				}
				this.resetStateCounts(stateId);
				this._result.pushAddedState(stateId);
				
				return 0;
			}	
			return 1;
		}
		
		return 0;
		
	}
	
	
	
	applyTension = function(subject) {
		
		if (subject.states().some(item => item.meta.Tension && item.meta.Tension == 5)) {
			subject.removeState(subject.states().filter(item => item.meta.Tension && item.meta.Tension == 5).map(item => item.id)[0]);
			subject.addState($dataStates.filter(item => item && item.meta.Tension && item.meta.Tension == 20).map(item => item.id)[0]);
			AudioManager.playSe({name: 'Down3', pan: 0, pitch: 150, volume: 80});
		}
		else if (subject.states().some(item => item.meta.Tension && item.meta.Tension == 20)) {
			subject.removeState(subject.states().filter(item => item.meta.Tension && item.meta.Tension == 20).map(item => item.id)[0]);
			subject.addState($dataStates.filter(item => item && item.meta.Tension && item.meta.Tension == 50).map(item => item.id)[0]);
			AudioManager.playSe({name: 'Down3', pan: 0, pitch: 150, volume: 80});
		}
		else if (subject.states().some(item => item.meta.Tension && item.meta.Tension == 50)) {
			if (Math.random()<0.3) {
				subject.removeState(subject.states().filter(item => item.meta.Tension && item.meta.Tension == 50).map(item => item.id)[0]);
				subject.addState($dataStates.filter(item => item && item.meta.Tension && item.meta.Tension == 100).map(item => item.id)[0]);
				AudioManager.playSe({name: 'Magic6', pan: 0, pitch: 100, volume: 80});
				AudioManager.playSe({name: 'Magic7', pan: 0, pitch: 100, volume: 80});
			} else AudioManager.playSe({name: 'Down1', pan: 0, pitch: 100, volume: 80});
		}
		else if (!subject.states().some(item => item.meta.Tension && item.meta.Tension == 100)) {
			subject.addState($dataStates.filter(item => item && item.meta.Tension && item.meta.Tension == 5).map(item => item.id)[0]);
			AudioManager.playSe({name: 'Down3', pan: 0, pitch: 150, volume: 80});
		}
		
	}

	___FeatherSMM___Game_Action_itemHit = Game_Action.prototype.itemHit;
	Game_Action.prototype.itemHit = function(target) {
		return ___FeatherSMM___Game_Action_itemHit.call(this, target) * (this.subject().states().some(item => item.meta.Contagion) ? 0.25 : 1);
	};

	___FeatherSMM___Game_BattlerBase_states = function() {
		let flatF = false;
		let array = this._states.map(id => 
			(this._objectStates[id]) ? 
				((this._objectStates[id].linkedBattlers) ? 
					(flatF = true, this.statesReader = true, this._objectStates[id].linkedBattlers.map(battler => {
						if (!battler.statesReader) return battler.states();
						else return [this._objectStates[id]];
					},this))
					: this._objectStates[id])
				: $dataStates[id]);
		this.statesReader = false;
		return (flatF) ? [...new Set(array.flat().flat())] : array;
	};
	if (VisuMZ) VisuMZ.SkillsStatesCore.Game_BattlerBase_states = ___FeatherSMM___Game_BattlerBase_states;
	else Game_BattlerBase.prototype.states = ___FeatherSMM___Game_BattlerBase_states;
	
	___FeatherSMM___Game_Battler_onBattleStart = Game_Battler.prototype.onBattleStart;
	Game_Battler.prototype.onBattleStart = function(advantageous) {
		___FeatherSMM___Game_Battler_onBattleStart.call(this, advantageous);
		if (!this._objectStates) this._objectStates = [];
		this.setSp(this.spMax());
		this._summons = {array:[],index:-1};
		this._summoner = null;
	};

	___FeatherSMM___Game_Action_apply = Game_Action.prototype.apply;
	Game_Action.prototype.apply = function(target) {
		___FeatherSMM___Game_Action_apply.call(this, target);
		if (target.states().some(item => item.meta.Contagion)) {
			const item = target.states().find(item => item.meta.Contagion);
			const atk = item.traits.find(a => a.code == 21 && a.dataId == 2);
			if (target.result().missed) atk.value = 1;
			else atk.value += Math.min(Math.max(1/(atk.value*atk.value),0.1),0.5);
		}
	};


	___FeatherSMM___Game_Battler_addState = Game_Battler.prototype.addState
	Game_Battler.prototype.addState = function(stateId) {
		
		let test = 0;
		
		applyDeathCounter.call(this,stateId);
		test += applyRegenesis.call(this,stateId);
		test += applyDeathCounterpart.call(this,stateId);

		if (test > 0 ) return ___FeatherSMM___Game_Battler_addState.call(this,stateId);

		
	};


	___FeatherSMM___Game_BattlerBase_addNewState = Game_BattlerBase.prototype.addNewState;
	Game_BattlerBase.prototype.addNewState = function(stateId) {
		const length = this._states.length;
		___FeatherSMM___Game_BattlerBase_addNewState.call(this, stateId);
		if ($dataStates[stateId].meta.InstinctiveShooting && this._states.length > length) {
			this.opponentsUnit().members().forEach(battler => {
				battler.addState($dataStates.find(state => state && state.meta.Targetted).id);
			});
		}
		if ($dataStates[stateId].meta.ObjectState && this._states.length > length) {
			this._objectStates[stateId] = Feather_Core.deepCopy($dataStates[stateId]);
			if ($dataStates[stateId].meta.SharedStates && BattleManager._subject !== this) {
				const subject = BattleManager._subject;
				subject.addState(stateId);
				if (!subject._objectStates[stateId].linkedBattlers) subject._objectStates[stateId].linkedBattlers = [];
				if (!this._objectStates[stateId].linkedBattlers) this._objectStates[stateId].linkedBattlers = [];
				subject._objectStates[stateId].linkedBattlers.push(this);
				this._objectStates[stateId].linkedBattlers.push(subject);
			}
		}
	};

	___FeatherSMM___Game_BattlerBase_clearStates = Game_BattlerBase.prototype.clearStates;
	Game_BattlerBase.prototype.clearStates = function() {
		if (this._states && this.states().some(item => item.meta.SharedStates)) {
			this.states().filter(item => item.meta.SharedStates).forEach(state => {
				this.removeState(state.id);
			}, this);
		}
		___FeatherSMM___Game_BattlerBase_clearStates.call(this);
	};

	___FeatherSMM___Game_Battler_removeState = Game_Battler.prototype.removeState;
	Game_Battler.prototype.removeState = function(stateId) {
		___FeatherSMM___Game_Battler_removeState.call(this, stateId);
		if ($dataStates[stateId].meta.SharedStates) {
			this._objectStates[stateId].linkedBattlers.forEach(battler => {
				battler._objectStates[stateId].linkedBattlers = battler._objectStates[stateId].linkedBattlers.filter(item => item !== this, this);
				if (battler._objectStates[stateId].linkedBattlers.length <= 0) battler.removeState(stateId);
			}, this);
		}
	};


	
	___FeatherSMM___Game_Action_makeDamageValue = Game_Action.prototype.makeDamageValue;
	Game_Action.prototype.makeDamageValue = function(target, critical) {
		this._currentTarget = target;
		return ___FeatherSMM___Game_Action_makeDamageValue.call(this, target, critical);
	};
	
	___FeatherSMM___Game_Action_executeHpDamage2 = Game_Action.prototype.executeHpDamage;
	Game_Action.prototype.executeHpDamage = function(target, value) {
		if (target.isActor()) {
			if (target.states().some(item => item.meta.ShareDamageToOthers)) {
				return $gameParty.members().filter(a => a != target && a._hp > 0).forEach((trueTarget,id,members) => {
					trueTarget._result = target._result;
					___FeatherSMM___Game_Action_executeHpDamage2.call(this, trueTarget, value/members.length)
					BattleManager._logWindow.displayActionResults(this.subject(), trueTarget);
				}, this);
			}
			if ($gameParty.members().some(actor => actor.states().some(item => item.meta.TakeDamageFromOthers))) {
				const trueTarget = $gameParty.members().find(actor => actor.states().some(item => item.meta.TakeDamageFromOthers));
				trueTarget._result = target._result;
				___FeatherSMM___Game_Action_executeHpDamage2.call(this, trueTarget, value);
				return BattleManager._logWindow.displayActionResults(this.subject(), trueTarget);
			}
			if (target.states().some(item => item.meta.ShareDamageRandomly)) {
				return $gameParty.members().forEach((target, id, members) => {
					trueTarget._result = target._result;
					const appliedValue = (id === members.length-1) ? value : value*Math.random();
					___FeatherSMM___Game_Action_executeHpDamage2.call(this, target, appliedValue);
					BattleManager._logWindow.displayActionResults(this.subject(), target);
					value -= appliedValue;
				},this);
			}
		}
		return ___FeatherSMM___Game_Action_executeHpDamage2.call(this, target, value);
	};
	
	
	___FeatherSMM___Game_Action_applyVariance = Game_Action.prototype.applyVariance;
	Game_Action.prototype.applyVariance = function(damage, variance) {
		variance += this.subject().states().reduce((a,b) => a + eval((b.meta.ChangeSkillsRandomness || 0)), 0);
		if (!this._currentTarget.states().some(item => item.meta.BlockSkillsRandomness))
			return ___FeatherSMM___Game_Action_applyVariance.call(this, damage, variance);
		return damage;
	};
	
	
	
	
	___FeatherSMM___Game_Action_gainDrainedHp = Game_Action.prototype.gainDrainedHp;
	Game_Action.prototype.gainDrainedHp = function(value) {
		if ((this.isDrain()) && this.item().meta.DATFACE) {
			let gainTarget = this.subject();
			if (this._reflectionTarget) {
				gainTarget = this._reflectionTarget;
			}
			$gameParty.members().forEach(function(item){
				if (!item._states.includes(1) && !item.states().some(item => item.meta.DeathCounterpart)) {
					item.gainHp(value);
				}
			})
			return 0;
		}
		return ___FeatherSMM___Game_Action_gainDrainedHp.call(this,value);
	};
	
	
	____FeatherSMM___Game_Action_executeHpDamage = Game_Action.prototype.executeHpDamage;
	Game_Action.prototype.executeHpDamage = function(target, value) {
		____FeatherSMM___Game_Action_executeHpDamage.call(this,target,value);
		if (this.subject() !== target && this.subject().states().some(item => item.meta.Bloodshed)) {
			this.subject().gainTp((value/100)<<0);
		}
		if (target.hp <= 0 && this.item().meta.FinalBlow) {
			AudioManager.playSe({name: 'Evasion2', pan: 0, pitch: 80, volume: 100});
			const exp = target.exp();
			this.subject().gainExp(exp);
			Feather_Core.range(8).forEach((id) => {
				const diviser = (id < 2) ? 1000 : 100;
				this.subject().addParam(id, ((target.paramBase(id)*(Math.random()*0.4+0.8))/diviser)<<0);
			}, this)
		}
		if (target.states().some(item => item.meta.IntenseRage)) {
			target.states().filter(item => item.meta.IntenseRage).forEach(item => {
				item.traits.find(a => a.code == 21 && a.dataId == 2).value += value/8000;
			})
		}
		if (target.states().some(item => item.meta.IntenseAdrenaline)) {
			target.states().filter(item => item.meta.IntenseAdrenaline).forEach(item => {
				item.traits.find(a => a.code == 21 && a.dataId == 3).value += value/8000;
			})
		}
		if (target.states().some(item => item.meta.SwapTP)) {
			const targetTp = target._tp;
			target._tp = this.subject()._tp;
			this.subject()._tp = targetTp;
			this.subject().refresh();
			target.refresh();
		}
		if (target.states().some(item => item.meta.Multix)) {
			target.gainMp(value/2);
		}
		if (target.states().some(item => item.meta.FTB)) {
			applyTension(target);
		}
	};
	

	___FeatherSMM___BattleManager_startAction = BattleManager.startAction
	BattleManager.startAction = function() {
		const subject = this._subject;
		const action = subject.currentAction();
		if (subject.states().some(item => item.meta.Adrenaline)) {
			
			action._multipliers.damageRate += $gameTroop._turnCount/7.5;
			
		}
		
		if (action.item().damage.type > 0 && subject.states().some(item => item.meta.Tension)) {
			if (subject.states().some(item => item.meta.Tension == 100)) AudioManager.playSe({name: 'Magic8', pan: 0, pitch: 150, volume: 80});
			else AudioManager.playSe({name: 'Magic3', pan: 0, pitch: 150, volume: 80});
		}
		___FeatherSMM___BattleManager_startAction.call(this);
	};
	
	
	___FeatherSMM___BattleManager_updateAction = BattleManager.updateAction
	BattleManager.updateAction = function() {
		const subject = this._subject;
		if (!this._logWindow.isBusy()) {
			if (subject.states().some(item => item.meta.Targetted)) {
				subject.opponentsUnit().members().filter(item => item.states().some(state => state.meta.InstinctiveShooting)).forEach(item => {
					const fastAction = new Game_Action(item);
					fastAction.setAttack();
					fastAction.apply(subject);
					this._logWindow.displayCounter(item);
					this._logWindow.displayActionResults(item, subject);
				},this)
			}
			this.endAction();
		}
		//___FeatherSMM___BattleManager_updateAction.call(this);
	};
	// Peut être améliorer en la faisant plus modulable.
	
	
	___FeatherSMM___BattleManager_endAction = BattleManager.endAction;
	BattleManager.endAction = function() {
		const subject = this._subject;
		const action = this._action;
		if (action && action.item().meta.userAddState) subject.addState(eval(action.item().meta.userAddState));
		if (action && action.item().damage.type > 0) subject._states = subject._states.filter(a => !subject.states().filter(item => item.meta.Tension).map(item => item.id).includes(a));
		if (action && action.item().meta.PsycheUp) applyTension(subject);
		___FeatherSMM___BattleManager_endAction.call(this);
	};
	
	
	___FeatherSMM___BattleManager_processTurn = BattleManager.processTurn
	BattleManager.processTurn = function() {
		
		if (this._subject.states().some(item => item.meta.Scared) && (Math.random()*3) < 1) {
			
			this._logWindow.push("addText", this._subject.name() + " a trop peur pour attaquer.");
			this._subject._actions = [];
			this.endAction();
			this._subject = null;
			return 0;
			
		}
		
		
		if (this._subject.states().some(item => item.meta.Late) && this._subject.turnCount() % 2 == 0) {
			this.endAction();
			this._subject = null;
			return 0;
			
		} 
		
		if (this._subject.states().some(item => item.meta["Rythm Curse"])) {
			
			
			if ($gameMap.getQTEResult() === "pending") {
			
				$gameMap.QTE(["normal"],320,$createQTEinRange(16 + Math.floor(Math.random()*5) -2),true)
				
			}
			
			if ($gameMap.getQTEResult() !== "start") {
				
				if ($gameMap.getQTEResult() !== "success") {
					this.endAction();
					this._subject = null;
					return 0;
				}	
				
			}
		}

		if (this._subject && this._subject.currentAction() && this._subject.currentAction().item() && this._subject.currentAction().item().meta.FalcoFerrum) {
			const frameT = 1000/60;
			const subject = this._subject;
			const action = subject.currentAction();
			const targets = action.makeTargets();
			let animationEnded = false;

			if (!this._logWindow.prepTimer && !this._logWindow.timer) {
				this._logWindow.prepTimer = 5000;
				this._logWindow.timer = subject.agi*10;
			}

			if (this._logWindow.prepTimer > 0) {

				this._logWindow.prepTimer-=frameT;
				if (this._logWindow.prepTimer > 3000) {
					this._logWindow._lines[0] = "Préparez vous !!"
				} else {
					this._logWindow._lines[0] = `${Math.ceil(this._logWindow.prepTimer / 1000)}`
				}
				this._logWindow.refresh();
			
			} else {

				this._logWindow.prepTimer = 0;

				this._logWindow.timer-=frameT;
				if (this._logWindow._spriteset._animationSprites.length < this._logWindow.lastAnimationLength) animationEnded = true;
				this._logWindow._lines[0] = `${Math.ceil(this._logWindow.timer / 100) / 10}s restantes`
				this._logWindow.refresh();

				if (Input.isTriggered("ok")) {
					if (action.isValid()) {
						const item = action.item();
						//this._phase = "action";
						this._action = action;
						this._targets = targets;
						subject.useItem(item);
						this._action.applyGlobal();
						this._logWindow.push("performAction", subject, action);
						this._logWindow.push("showAnimation", subject, targets.clone(), item.animationId);
					}
				}
				if (animationEnded) {
					const target = this._targets.shift();
					this._targets.push(target);
					if (target) {
						this.invokeAction(this._subject, target);
					}
				}

				this._logWindow.lastAnimationLength = this._logWindow._spriteset._animationSprites.length;
			}
			if (this._logWindow.timer <= 0) {
				this._logWindow.timer = 0;
				this._logWindow.clear();
				subject.removeCurrentAction();
				this.endAction();
			}
			return 0;

		}
		
		return ___FeatherSMM___BattleManager_processTurn.call(this);
		
	};

})();
