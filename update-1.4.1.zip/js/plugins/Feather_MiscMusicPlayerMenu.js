//=============================================================================
// RPG Maker MZ - MiscMusicPlayerMenu
//=============================================================================

/*:
 * @target MZ
 * @plugindesc Misc Music Player Menu system plugin.
 * @author Feather
 *
 * @help 
 * Misc Music Player Menu system plugin.
 *
 */
 

(() => {
    const pluginName = "MiscMusicPlayerMenu";
	
	$Window_ChoiceList_start = null;
	$Window_ChoiceList_processCursorMove = null;

	$initGramophone = function() {
		
		
		$Window_ChoiceList_start = Window_ChoiceList.prototype.start
		Window_ChoiceList.prototype.start = function() {
			$Window_ChoiceList_start.call(this)
			this.x = 650
			this.y = 50
			this.setBackgroundType(2)
		};
			
			
		$Window_ChoiceList_processCursorMove = Window_ChoiceList.prototype.processCursorMove
		Window_ChoiceList.prototype.processCursorMove = function() {
			$Window_ChoiceList_processCursorMove.call(this);
			if (this._list[this.index()].name.includes('603')) $gameScreen.picture(1)._name = "vinylOG2_01"
			if (this._list[this.index()].name.includes('604')) $gameScreen.picture(1)._name = "vinylOG2_02"
			if (this._list[this.index()].name.includes('605')) $gameScreen.picture(1)._name = "vinylOG2_03"
			if (this._list[this.index()].name.includes('606')) $gameScreen.picture(1)._name = "vinylOG2_04"
			if (this._list[this.index()].name.includes('607')) $gameScreen.picture(1)._name = "vinylOG2_05"
			if (this._list[this.index()].name.includes('608')) $gameScreen.picture(1)._name = "vinylOG2_06"
			if (this._list[this.index()].name.includes('609')) $gameScreen.picture(1)._name = "vinylOG2_07"
			if (this._list[this.index()].name.includes('610')) $gameScreen.picture(1)._name = "vinylOG2_08"
			if (this._list[this.index()].name.includes('611')) $gameScreen.picture(1)._name = "vinylOG2_09"
			if (this._list[this.index()].name.includes('612')) $gameScreen.picture(1)._name = "vinylOG2_10"
			if (this._list[this.index()].name.includes('613')) $gameScreen.picture(1)._name = "vinylOG2_11"
			if (this._list[this.index()].name.includes('614')) $gameScreen.picture(1)._name = "vinylOG2_12"
			if (this._list[this.index()].name.includes('615')) $gameScreen.picture(1)._name = "vinylOG2_13"
			if (this._list[this.index()].name.includes('616')) $gameScreen.picture(1)._name = "vinylOG2_14"
			if (this._list[this.index()].name.includes('617')) $gameScreen.picture(1)._name = "vinylOG2_15"
			if (this._list[this.index()].name.includes('618')) $gameScreen.picture(1)._name = "vinylOG2_16"
				
		};
		
	}


	$endGramophone = function() {
		
		
		Window_ChoiceList.prototype.start = $Window_ChoiceList_start;
		Window_ChoiceList.prototype.processCursorMove = $Window_ChoiceList_processCursorMove;
		
	}
	
})();
