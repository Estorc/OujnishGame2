//=============================================================================
// RPG Maker MZ - LoadingIcon
//=============================================================================

/*:
 * @target MZ
 * @plugindesc Loading Icon system plugin.
 * @author Feather
 *
 * @help 
 * Loading Icon system plugin.
 *
 */
 

(() => {
    const pluginName = "LoadingIcon";



	Graphics._createLoadingSpinnerEnd = function() {
			const loadingSpinnerEnd = document.createElement("div");
			const loadingSpinnerImageEnd = document.createElement("div");
			loadingSpinnerEnd.id = "loadingSpinnerEnd";
			loadingSpinnerImageEnd.id = "loadingSpinnerImageEnd";
			loadingSpinnerEnd.appendChild(loadingSpinnerImageEnd);
			if (typeof this._loadingSpinnerEnd === 'undefined') {
				this._loadingSpinnerEnd = null;
			}
			this._loadingSpinnerEnd = loadingSpinnerEnd;
	};


	Graphics._createAllElements = function() {
		this._createErrorPrinter();
		this._createCanvas();
		this._createLoadingSpinner();
		this._createLoadingSpinnerEnd();
		this._createFPSCounter();
	};


	Graphics._deleteLoadingSpinnerEnd = function() {
		if (typeof this._loadingSpinnerEnd !== 'undefined') { document.body.removeChild(this._loadingSpinnerEnd)}
	}

	Graphics._canDeleteLoadingSpinnerEndFun = function(_this) {
		this._canDeleteLoadingSpinnerEnd = 1;
	}

	Graphics.startLoading = function() {
		/*if (document.getElementById("loadingSpinnerEnd")) {
		   if (typeof this._loadingSpinnerEnd !== 'undefined') { document.body.removeChild(this._loadingSpinnerEnd)};
		}*/
		if (!document.getElementById("loadingSpinner")) {
			document.body.appendChild(this._loadingSpinner);
			this._canDeleteLoadingSpinnerEnd = 0;
			setTimeout(this._canDeleteLoadingSpinnerEndFun.bind(this), 500);
		}
	};

	Graphics.endLoading = function() {
		if (document.getElementById("loadingSpinner")) {
			document.body.removeChild(this._loadingSpinner);
			
			if (!document.getElementById("loadingSpinner") && (typeof this._canDeleteLoadingSpinnerEnd !== 'undefined') && this._canDeleteLoadingSpinnerEnd == 1) {
				if (typeof this._loadingSpinnerEnd !== 'undefined') { document.body.appendChild(this._loadingSpinnerEnd)};
				setTimeout(this._deleteLoadingSpinnerEnd, 500);
			}
			
			return true;
		} else {
			return false;
		}
	};

	
})();
