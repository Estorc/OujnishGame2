//==============================================================================
// More Resolutions
// by Feather
// Last Updated: 2016.02.15
//==============================================================================

/*:
 * @plugindesc More Resolutions
 * @author Feather
 * @target MZ
 *
 * @help
 * More Resolutions
 *
 */

(function() {
	const pluginName = "More Resolutions";


addEventListener("resize", (event) => {
	Graphics.resize(window.innerWidth,window.innerHeight)
	SceneManager.goto(SceneManager._scene.constructor);
	$dataSystem.advanced.screenWidth = window.innerWidth;
	$dataSystem.advanced.screenHeight = window.innerHeight;
	$dataSystem.advanced.uiAreaWidth = window.innerWidth;
	$dataSystem.advanced.uiAreaHeight = window.innerHeight;
	Graphics.boxWidth = $dataSystem.advanced.uiAreaWidth - 4 * 2;
	Graphics.boxHeight = $dataSystem.advanced.uiAreaHeight - 4 * 2;
	$gameBulletHell.bhworldwidth = window.innerWidth;
	$gameBulletHell.bhworldheight = window.innerHeight;
	$gameBulletHell.screenw = window.innerWidth;
	$gameBulletHell.screenh = window.innerHeight;
});



function isResponsivePicture(picture) {
	
	return picture._name != "black" && picture._name != "quest" && picture._name != "ppg_attackbg" && picture._name != "ppg_attackbgblue" && picture._name != "ppg_attackbgonly" && picture._name != "ppg_attackbgorange" && picture._name != "ppg_finalattackbg" && picture._name != "tf_attackbg" && picture._name != "tf_attackbgblue" && picture._name != "tf_attackbgorange" && picture._name != "tf_finalattackbg" && picture._name != "kingkong_attackbg" && picture._name != ""
	
}


Sprite_Picture.prototype.updatePosition = function() {
    const picture = this.picture();
    this.x = Math.round(picture.x()) * (isResponsivePicture(picture) ? ($dataSystem.advanced.screenWidth/1280) : 1);
    this.y = Math.round(picture.y()) * (isResponsivePicture(picture) ? ($dataSystem.advanced.screenHeight/720) : 1);
};

Sprite_Picture.prototype.updateScale = function() {
    const picture = this.picture();
	if (!(picture.name() == "")) {
    this.scale.x = picture.scaleX() / 100 * (isResponsivePicture(picture) ? ($dataSystem.advanced.screenWidth/1280) : 1);
    this.scale.y = picture.scaleY() / 100 * (isResponsivePicture(picture) ? ($dataSystem.advanced.screenWidth/1280) : 1);
	}
};



})();