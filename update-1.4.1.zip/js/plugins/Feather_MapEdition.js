//=============================================================================
// RPG Maker MZ - MapEdition
//=============================================================================

/*:
 * @target MZ
 * @plugindesc Map Edition system plugin.
 * @author Feather
 *
 * @help 
 * Map Edition system plugin.
 *
 */
 

(() => {
    const pluginName = "Feather_MapEdition";
	
	Game_Map.prototype.featherResetMapData = function() {
		
		if ($dataMap.preGenEvents) {
			$dataMap.events = $dataMap.preGenEvents;
			SceneManager._scene._spriteset._tilemap.children = SceneManager._scene._spriteset._tilemap.preGenChildren;
		}
		this.setup(this._mapId);
		this._eventCache = this._events.filter(a=>a);
		$dataMap.preGenEvents = $dataMap.events.concat([]);
		SceneManager._scene._spriteset._tilemap.preGenChildren = SceneManager._scene._spriteset._tilemap.children.concat([]);
		
	}
	
	
	Game_Map.prototype.featherGetAutotileID = function(tileId) {
	
		return tileId >= 2048 ? Math.floor((tileId - 2048) / 48)*48+2048 : -1;
		
	}
	
	Game_Map.prototype.featherIsSameAutotile = function(x1, y1, z1, x2, y2, z2, wallCheck = true) {
		const tileIdA = this.tileId(x1, y1, z1);
		const tileIdB = this.tileId(x2, y2, z2);
		if (x1<0 || x1>=this.width || y1<0 || y1>=this.height ||
			x2<0 || x2>=this.width || y2<0 || y2>=this.height) return true;
		if (wallCheck && Tilemap.isWallSideTile(tileIdA)) {
			let i = y1+1;
			let j = y2+1;
			while(Math.floor((this.tileId(x1, i, z1)-2048)/48)*48+2048 === Math.floor((tileIdA-2048)/48)*48+2048) i++;
			while(Math.floor((this.tileId(x2, j, z2)-2048)/48)*48+2048 === Math.floor((tileIdB-2048)/48)*48+2048) j++;
			if (i !== j) return false;
		}
		return (tileIdA >= 2048 && tileIdB >= 2048) ? Math.floor((tileIdA - 2048) / 48)*48+2048 === Math.floor((tileIdB - 2048) / 48)*48+2048 : false;
	}
	

	Game_Map.prototype.featherShapeAutotile = function(x, y, z) {
		
		let tile =  this.tileId(x, y, z);
		
		let neighbors = 0x0;
		
		neighbors |= 0x1 * this.featherIsSameAutotile(x, y - 1, z, x, y, z) |
					 0x2 * this.featherIsSameAutotile(x + 1, y, z, x, y, z) |
					 0x4 * this.featherIsSameAutotile(x, y + 1, z, x, y, z) |
					 0x8 * this.featherIsSameAutotile(x - 1, y, z, x, y, z) |
					 0x10 * this.featherIsSameAutotile(x - 1, y - 1, z, x, y, z) |
					 0x20 * this.featherIsSameAutotile(x + 1, y - 1, z, x, y, z) |
					 0x40 * this.featherIsSameAutotile(x + 1, y + 1, z, x, y, z) |
					 0x80 * this.featherIsSameAutotile(x - 1, y + 1, z, x, y, z);
		
		if(Tilemap.isWaterfallTile(tile)) //Waterfall Animation Autotiles
			return tile + this.getAutotile1AxeShape(neighbors & 0x2, neighbors & 0x8);
		if(Tilemap.isTileA3(tile) || Tilemap.isWallSideTile(tile)) //Buildings Autotiles
			return tile + this.getAutotile2AxesShape(neighbors & 0x1, neighbors & 0x2, neighbors & 0x4, neighbors & 0x8);
		return tile + this.getAutotile4AxesShape(neighbors);
	};

	Game_Map.prototype.getAutotile4AxesShape = function(a) {

		let b = a & 0xf;
		
		let ul = a & 0x10;
		let ur = a & 0x20;
		let br = a & 0x40;
		let bl = a & 0x80;
		
		return (b === 0xf) * ((!ul)*1 + (!ur)*2 + (!br)*4 + (!bl)*8) +

				(b === 0x7)*(16 + (!ur) + (!br)*2) + 
				(b === 0xe)*(20 + (!br) + (!bl)*2) + 
				(b === 0xd)*(24 + (!bl) + (!ul)*2) + 
				(b === 0xb)*(28 + (!ul) + (!ur)*2) + 
		
				(b === 0x5)*32 + (b === 0xa)*33 + 
		
				(b === 0x6)*(34 + (!br)) + 
				(b === 0xc)*(36 + (!bl)) +
				(b === 0x9)*(38 + (!ul)) + 
				(b === 0x3)*(40 + (!ur)) + 
				
				(b === 0x4)*42 + (b === 0x2)*43 +
				(b === 0x1)*44 + (b === 0x8)*45 + (b === 0x0)*46;
				
		
		/*
		
			0x1 = n
			0x2 = e
			0x4 = s
			0x8 = w
			
			0x10 = nw
			0x20 = ne
			0x40 = se
			0x80 = sw
		
		*/
		
		
	};


	Game_Map.prototype.getAutotile1AxeShape = function(e, w) {
		return (!w)*1 + (!e)*2;
	};


	Game_Map.prototype.getAutotile2AxesShape = function(n, e, s, w) {
		return (!w)*1 + (!n)*2 + (!e)*4 + (!s)*8;
	};
	
	
	Game_Map.prototype.featherCloneEvent = function(event, x, y) {
		
		event.x = x;
		event.y = y;
		let lastId = $dataMap.events.filter(a=>a)
		lastId = lastId[lastId.length-1].id+1;
		event.id = lastId;
		$gameSelfSwitches.setValue(`${this.mapId()},${event.id},A`,false)
		$gameSelfSwitches.setValue(`${this.mapId()},${event.id},B`,false)
		$gameSelfSwitches.setValue(`${this.mapId()},${event.id},C`,false)
		$gameSelfSwitches.setValue(`${this.mapId()},${event.id},D`,false)
		$dataMap.events[lastId] = event;
		event = new Game_Event(this._mapId, lastId);
		this._events.push(event);
		if (VisuMZ) this._eventCache.push(event);
		SceneManager._scene._spriteset._tilemap.addChild(new Sprite_Character(event));
	
	}
	
	
	Game_Map.prototype.featherSavePostGeneration = function() {
		
		//$dataMap.postGenEvents = $dataMap.events.concat([]);
		//$dataMap.postGenData = $dataMap.data.concat([]);
		$dataMap.postGenId = this._mapId;
	
	}
	
	
	
	Game_Map.prototype.loadSchematic = function(model,x1,y1,x2,y2) {
	
		let schema = [[],[],[],[],[],[],x2-x1+1,y2-y1+1];
		let w = model.width;
		let h = model.height;
	
		for (let i = y1; i<y2+1; i++) {
			
			for (let z = 0; z<6; z++) {
			
				let data = model.data.slice(x1+(z*h+i)*w,x2+(z*h+i)*w+1);
				schema[z] = schema[z].concat(data);
				
			}
		}
		
		return schema;
		
	}
	
	
	
	Game_Map.prototype.placeSchematic = function(schema,dx,dy,type) {
	
	
		for (let y = 0; y<schema[7]; y++) {
			
			for (let x = 0; x<schema[6]; x++) {
			
				for (let z = 0; z<6; z++) {
					
					let tile = schema[z][x + y*schema[6]];
					let autotile = this.featherGetAutotileID(tile);
					if (autotile > -1) tile = autotile;
				
					$dataMap.data[(z * $dataMap.height + dy + y) * $dataMap.width + x + dx] = tile;
				
				}

			}
			
		}
	
	}
	
	
	
	Game_Map.prototype.featherSetupAutotiles = function() {
		
		let width = $dataMap.width;
		let height = $dataMap.height;
		
		for (let x = 0; x < width; x++) {
			
			for (let y = 0; y < height; y++) {
				
				for (let z = 0; z < 4; z++) {
				
					let tile = $gameMap.tileId(x, y, z);
					if (tile >= 2048) {
						$dataMap.data[(z * height + y) * width + x] = $gameMap.featherShapeAutotile(x,y,z);
						if ((Tilemap.isTileA3(tile) || Tilemap.isTileA4(tile)) && !$gameMap.allTiles(x+1, y).some(a => Tilemap.isTileA3(a) || Tilemap.isTileA4(a)) && $gameMap.allTiles(x, y-1).some(a => Tilemap.isTileA3(a) || Tilemap.isTileA4(a)) ) $dataMap.data[(4 * $dataMap.height + y) * $dataMap.width + x + 1] = 5;
					}
					
				}
				
			}
			
		}
		
	}
	
	
	___FeatherMG___DataManager_loadMapData = DataManager.loadMapData;
	DataManager.loadMapData = function(mapId) {
		if ($dataMap && $dataMap.postGenId && $dataMap.postGenId === mapId) return 0;
		___FeatherMG___DataManager_loadMapData.call(this, mapId);
	};
	
	
})();
