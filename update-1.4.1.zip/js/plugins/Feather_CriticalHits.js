//=============================================================================
// RPG Maker MZ - CriticalHits
//=============================================================================

/*:
 * @target MZ
 * @plugindesc Critical Hits system plugin.
 * @author Feather
 *
 * @help 
 * Critical Hits system plugin.
 *
 */
 

(() => {
    const pluginName = "Critical Hits";
	const PARAM_STATE_ID = 300;

	Window_BattleStatus.prototype.isActorVisible = function(actorId) {
		const yPos = ((((actorId/this.maxCols())<<0)*this.innerHeight)+(this.innerHeight>>1));
		return (yPos > this._scrollY && yPos < this._scrollY + this.innerHeight)
	}

	___FeatherCH___Window_BattleStatus_drawItem = Window_BattleStatus.prototype.drawItem;
	Window_BattleStatus.prototype.drawItem = function(index) {
		if (this.isActorVisible(index))
			___FeatherCH___Window_BattleStatus_drawItem.call(this, index);
	}

	___FeatherCH___Window_BattleStatus_updateSmoothScroll = Window_BattleStatus.prototype.updateSmoothScroll;
	Window_BattleStatus.prototype.updateSmoothScroll = function() {
		___FeatherCH___Window_BattleStatus_updateSmoothScroll.call(this);
		if (this._scrollDuration > 0) this.refresh();
	};

	___FeatherCH___Game_Action_executeDamage = Game_Action.prototype.executeDamage;
	Game_Action.prototype.executeDamage = function(target, value) {
		___FeatherCH___Game_Action_executeDamage.call(this, target, value);
		target._result.elementRate = this.calcElementRate(target);
	};
	
	
	___FeatherCH___Game_ActionResult_clear = Game_ActionResult.prototype.clear;
	Game_ActionResult.prototype.clear = function() {
		___FeatherCH___Game_ActionResult_clear.call(this);
		this.elementRate = 1;
	};
	
	
	___FeatherCH___Sprite_Damage_damageColor = Sprite_Damage.prototype.damageColor;
	Sprite_Damage.prototype.damageColor = function() {
		switch (this._effectiveness) {
			
			case -1:
			return ColorManager.damageColor(52);
			
			case 0:
			return ColorManager.damageColor(51);
			
			case 2:
			return ColorManager.damageColor(50);
			
			default:
			return ___FeatherCH___Sprite_Damage_damageColor.call(this);
			
		};
	};
	
	
	___FeatherCH___ColorManager_damageColor = ColorManager.damageColor;
	ColorManager.damageColor = function(colorType) {
		switch (colorType) { // [50,...] = Feather Colors
			case 50: // Effective damage
				return "#fa8500";
			case 51: // Weak damage
				return "#8797a3";
			case 52: // Useless damage
				return "#666666";
			default:
				return ___FeatherCH___ColorManager_damageColor.call(this, colorType);
		}
	};
	
	
	Sprite_Damage.prototype.initEffectiveness = function(target) {
		
		const result = target.result();
		this._effectiveness = 1;
		if (!(result.missed || result.evaded)) {
			
			this._elementRate = result.elementRate;
			
			if (result.elementRate > 1) {
				this._effectiveness = 2;
			}
			else if (result.elementRate < 1) {
				if (result.elementRate) this._effectiveness = 0;
				else this._effectiveness = -1;
			} 
			
		}
		
	}


	___FeatherCH___Sprite_Damage_setup = Sprite_Damage.prototype.setup;
	Sprite_Damage.prototype.setup = function(target) {
		const result = target.result();
		this.initEffectiveness(target);
		___FeatherCH___Sprite_Damage_setup.call(this, target);
	};
	
	
	___FeatherCH___Sprite_Damage_createDigits = Sprite_Damage.prototype.createDigits;
	Sprite_Damage.prototype.createDigits = function(value) {
		
		const h = this.fontSize();
		const w = Math.floor(h * 0.75);
		
		if (this._effectiveness >= 0) {
			___FeatherCH___Sprite_Damage_createDigits.call(this, value);
			if (this._effectiveness !== 1) {
				
				const string = ` (x${this._elementRate.toString().slice(0,5)})`;
				
				for (let i = 0; i < string.length; i++) {
					const sprite = this.createChildSprite(w, h);
					sprite.bitmap.drawText(string[i], 0, 0, w, h, "center");
					sprite.x = (i - (string.length - 1) / 2) * w;
					sprite.dy = -i;
				}
				
				this.children.map((a, b) => {
					a.x = (b - (this.children.length - 1) / 2) * w;
					a.dy = -b;
				})
				
			}
		}
		else {
			const string = `Immunité`;
			
			for (let i = 0; i < string.length; i++) {
				const sprite = this.createChildSprite(w, h);
				sprite.bitmap.drawText(string[i], 0, 0, w, h, "center");
				sprite.x = (i - (string.length - 1) / 2) * w;
				sprite.dy = -i;
			}
		}
		
	};
	
	
	___FeatherCH___Sprite_Battler_initialize = Sprite_Battler.prototype.initialize;
	Sprite_Battler.prototype.initialize = function(battler) {
		___FeatherCH___Sprite_Battler_initialize.call(this, battler);
		this._statePopupWindow = new Window_FeatherStatesPopup();
		this.addChild(this._statePopupWindow);
	};
	
	
	___FeatherCH___Game_Enemy_addState = Game_Enemy.prototype.addState;
	Game_Enemy.prototype.addState = function(stateId) {
		if (!this.isStateAffected(stateId) && this.isStateAddable(stateId)) {
			BattleManager._spriteset._enemySprites.find(a => a._battler === this)._statePopupWindow.push(stateId);
		}
		___FeatherCH___Game_Enemy_addState.call(this, stateId);
	};
	
	___FeatherCH___Game_Actor_addState = Game_Actor.prototype.addState;
	Game_Actor.prototype.addState = function(stateId) {
		if (!this.isStateAffected(stateId) && this.isStateAddable(stateId)) {
			const actor = BattleManager._spriteset._actorSprites.find(a => a._battler === this)
			if (actor) actor._statePopupWindow.push(stateId);
			const statePopup = SceneManager._scene._statusWindow && SceneManager._scene._statusWindow._statePopupWindows[this.index()];
			if (statePopup) statePopup.push(stateId);
		}
		___FeatherCH___Game_Actor_addState.call(this, stateId);
	};
	
	
	
	___FeatherCH___Game_Enemy_addBuff = Game_Enemy.prototype.addBuff;
	Game_Enemy.prototype.addBuff = function(paramId, turns) {
		___FeatherCH___Game_Enemy_addBuff.call(this, paramId, turns);
		BattleManager._spriteset._enemySprites[this.index()]._statePopupWindow.push(paramId+PARAM_STATE_ID);
	};
	
	___FeatherCH___Game_Actor_addBuff = Game_Actor.prototype.addBuff;
	Game_Actor.prototype.addBuff = function(paramId, turns) {
		___FeatherCH___Game_Actor_addBuff.call(this, paramId, turns);
		const actor = BattleManager._spriteset._actorSprites[this.index()];
		if (actor) actor._statePopupWindow.push(paramId+PARAM_STATE_ID);
		const statePopup = SceneManager._scene._statusWindow && SceneManager._scene._statusWindow._statePopupWindows[this.index()];
		if (statePopup) statePopup.push(paramId+PARAM_STATE_ID);
	};
	
	
	
	
	
	___FeatherCH___Window_BattleStatus_initialize = Window_BattleStatus.prototype.initialize;
	Window_BattleStatus.prototype.initialize = function(rect) {
		this._statePopupWindows = [];
		___FeatherCH___Window_BattleStatus_initialize.call(this, rect);
		for (const index in $gameParty.battleMembers()) this.drawItem(index);
	};
	
	Window_BattleStatus.prototype.placeStateIcon = function(actor, x, y) {
		const key = "actor%1-stateIcon".format(actor.actorId());
		const sprite = this.createInnerSprite(key, Sprite_FeatherActorStateIcon);
		sprite.setup(actor);
		sprite.move(x, y-128);
		sprite.show();
		const width = this.itemRectWithPadding(actor.index()).width;
		if (!this._statePopupWindows[actor.index()]) {
			const statePopupWindow = new Window_FeatherStatesPopup();
			this._statePopupWindows[actor.index()] = statePopupWindow;
			statePopupWindow.x = x+width/2;
			statePopupWindow.y = y-128;
			this.addChild(statePopupWindow);
		}
	};
	
	
	Sprite_Enemy.prototype.createStateIconSprite = function() {
		this._stateIconSprite = new Sprite_FeatherEnemyStateIcon();
		this.addChild(this._stateIconSprite);
	};
	
	
	___Feather_CH___Sprite_Enemy_updateStateSprite = Sprite_Enemy.prototype.updateStateSprite;
	Sprite_Enemy.prototype.updateStateSprite = function() {
		___Feather_CH___Sprite_Enemy_updateStateSprite.call(this);
		this._stateIconSprite.x = this._stateIconSprite.realX;
		this._statePopupWindow.y = this._stateIconSprite.y+40;
	};
	
	
	//-----------------------------------------------------------------------------
	// Window_FeatherStatesPopup
	//
	// This window is the window for the state popup system.

	Window_FeatherStatesPopup = function() {
		this.initialize(...arguments);
	}

	Window_FeatherStatesPopup.prototype = Object.create(Window_Base.prototype);
	Window_FeatherStatesPopup.prototype.constructor = Window_FeatherStatesPopup;

	Window_FeatherStatesPopup.prototype.initialize = function () {
		let rect = {x:0,y:0,width:500,height:0};
		Window_Base.prototype.initialize.call(this, rect);
		this._popupList = [];
		this._texts = [];
		this.setBackgroundType(2);
	};

	Window_FeatherStatesPopup.prototype.update = function() {

		Window_Base.prototype.update.call(this);
		this._texts = this._texts.filter(a => this.children.includes(a));
		if (this._popupList.length > 0) {
			const text = this._popupList.pop()
			if (this._texts.length !== 0 && this._texts[0].y < 32) text.y = this._texts[this._texts.length-1].y+32;
			this._texts.push(text);
			this.addChild(text);
		}
	};
	
	
	Window_FeatherStatesPopup.prototype.push = function(stateId) {
		
		const state = $dataStates[stateId];
		if (state.iconIndex !== 0 && !state.meta.DeathCounterpart && stateId !== Game_BattlerBase.prototype.deathStateId()) this._popupList.push(new Window_FeatherStateText(stateId,this.width));
		
	};
	
	
	//-----------------------------------------------------------------------------
	// Window_FeatherStateText
	//
	// This window is the window for the state popup system.

	Window_FeatherStateText = function() {
		this.initialize(...arguments);
	}

	Window_FeatherStateText.prototype = Object.create(Window_Base.prototype);
	Window_FeatherStateText.prototype.constructor = Window_FeatherStateText;

	Window_FeatherStateText.prototype.initialize = function (stateId) {
		let rect = {x:-250,y:0,width:500,height:60};
		Window_Base.prototype.initialize.call(this, rect);
		const state = $dataStates[stateId];
		this._text = state.name;
		this._icon = state.iconIndex;
		this.refresh();
		this.setBackgroundType(2);
	};

	Window_FeatherStateText.prototype.update = function() {
		Window_Base.prototype.update.call(this);
		this.y++;
		this.contentsOpacity-=5;
		if (this.contentsOpacity === 0) this.destroy();
	};

	Window_FeatherStateText.prototype.refresh = function() {
		const width = this.contents.measureTextWidth(`+${this._text}`)+64;
		this.drawTextEx(`+\\I[${this._icon}]${this._text}`, (this.width-width)/2, 0, width);
	};
	
	
	//-----------------------------------------------------------------------------
	// Sprite_FeatherStateIcon
	//
	// The sprite for displaying state icons.

	function Sprite_FeatherStateIcon() {
		this.initialize(...arguments);
	}

	Sprite_FeatherStateIcon.prototype = Object.create(Sprite_StateIcon.prototype);
	Sprite_FeatherStateIcon.prototype.constructor = Sprite_FeatherStateIcon;

	Sprite_FeatherStateIcon.prototype.initialize = function() {
		Sprite_StateIcon.prototype.initialize.call(this);
	};
	
	Sprite_FeatherStateIcon.prototype.update = function() {
		Sprite.prototype.update.call(this);
		this.updateIcon();
		this.updateFrame();
	};
	
	Sprite_FeatherStateIcon.prototype.updateIcon = function() {
		const icons = [];
		if (this.shouldDisplay()) {
			icons.push(...this._battler.allIcons());
		}
		if (icons.length >= this._index-1) {
			this._iconIndex = icons[this._index];
			this._animationIndex = this._index;
		} else {
			this._iconIndex = 0;
			this._animationIndex = 0;
		}
	};


	//-----------------------------------------------------------------------------
	// Sprite_FeatherActorStateIcon
	//
	// The sprite for displaying state icons.

	function Sprite_FeatherActorStateIcon() {
		this.initialize(...arguments);
	}

	Sprite_FeatherActorStateIcon.prototype = Object.create(Sprite_StateIcon.prototype);
	Sprite_FeatherActorStateIcon.prototype.constructor = Sprite_FeatherActorStateIcon;

	Sprite_FeatherActorStateIcon.prototype.initialize = function() {
		Sprite.prototype.initialize.call(this);
		this.MAX_ICONS = 7;
		this.i = 0;
		this.initMembers();
		this.createIcons();
	};
	
	Sprite_FeatherActorStateIcon.prototype.setup = function(battler) {
		if (this._battler !== battler) {
			this._battler = battler;
			for (const sprite of this._icons) {
				
				sprite.setup(battler);
				
			}
		}
	};
	
	Sprite_FeatherActorStateIcon.prototype.createIcons = function() {
		this._icons = [];
		for (let i = 0; i<this.MAX_ICONS+1; i++) {
			this._icons[i] = new Sprite_FeatherStateIcon();
			this._icons[i].bitmap = ImageManager.loadSystem("IconSet");
			this._icons[i].setFrame(0, 0, 0, 0);
			this._icons[i].y = i*34;
			this._icons[i]._realY = this._icons[i].y;
			this._icons[i]._index = i;
			this.addChild(this._icons[i]);
		}

	};
	
	Sprite_FeatherActorStateIcon.prototype.update = function() {
		if (!$gameBulletHell.active && this.parent.parent.isActorVisible(this._battler.index())) {
			Sprite.prototype.update.call(this);
			if (this._battler.allIcons().length > this.MAX_ICONS) {
				const index = this.i;
				this._icons.forEach((a,b) => { 
					a.y--;
					if (a.y < a._realY-33) {
						a.y = a._realY;
						this.i = index + 1;
						if (this.i > this._battler.allIcons().length-1) this.i = 0;
						a._index = b+this.i;
						if (a._index > this._battler.allIcons().length-1) a._index -= this._battler.allIcons().length;
						a.update();
					}
				}, this);
				
			} else if (this._icons[0]._index !== 0 || this._icons[0].y !== this._icons[0]._realY) {
				
				this._icons.map((a, b) => {a._index = b; a.y = a._realY; a.update()});
				
			}
		}
	};
	
	
	
	//-----------------------------------------------------------------------------
	// Sprite_FeatherEnemyStateIcon
	//
	// The sprite for displaying state icons.

	function Sprite_FeatherEnemyStateIcon() {
		this.initialize(...arguments);
	}

	Sprite_FeatherEnemyStateIcon.prototype = Object.create(Window_Base.prototype);
	Sprite_FeatherEnemyStateIcon.prototype.constructor = Sprite_FeatherEnemyStateIcon;

	Sprite_FeatherEnemyStateIcon.prototype.initialize = function() {
		this.MAX_ICONS = 5;
		this.i = 0;
		let rect = {x:-(34 * this.MAX_ICONS/2),y:0,width:34*this.MAX_ICONS,height:32};
		Window_Base.prototype.initialize.call(this,rect);
		this.setBackgroundType(2);
		this.realX = this.x;
		this.createIcons();
	};
	
	Sprite_FeatherEnemyStateIcon.prototype.updatePadding = function() {
		this.padding = 0;
	};
	
	Sprite_FeatherEnemyStateIcon.prototype.setup = function(battler) {
		if (this._battler !== battler) {
			this._battler = battler;
			for (const sprite of this._icons) {
				
				sprite.setup(battler);
				
			}
		}
	};
	
	Sprite_FeatherEnemyStateIcon.prototype.createIcons = function() {
		this._icons = [];
		for (let i = 0; i<this.MAX_ICONS+1; i++) {
			this._icons[i] = new Sprite_FeatherStateIcon();
			this._icons[i].bitmap = ImageManager.loadSystem("IconSet");
			this._icons[i].setFrame(0, 0, 0, 0);
			this._icons[i].x = i*34+16;
			this._icons[i].y = 16;
			this._icons[i]._realX = this._icons[i].x;
			this._icons[i]._index = i;
			this.addInnerChild(this._icons[i]);
		}
	};
	
	Sprite_FeatherEnemyStateIcon.prototype.update = function() {
		Window_Base.prototype.update.call(this);
		if (this._battler.allIcons().length > this.MAX_ICONS) {
			const index = this.i;
			this._icons.forEach((a,b) => { 
				a.x--;
				if (a.x < a._realX-33) {
					a.x = a._realX;
					this.i = index + 1;
					if (this.i > this._battler.allIcons().length-1) this.i = 0;
					a._index = b+this.i;
					if (a._index > this._battler.allIcons().length-1) a._index -= this._battler.allIcons().length;
					a.update();
				}
			}, this);
			
		} else if (this._icons[0]._index !== 0 || this._icons[0].x !== this._icons[0]._realX) {
			
			this._icons.map((a, b) => {a._index = b; a.x = a._realX; a.update()});
			
		}
	};


})();
