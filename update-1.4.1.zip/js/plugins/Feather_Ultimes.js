//=============================================================================
// RPG Maker MZ - Ultimes
//=============================================================================

/*:
 * @target MZ
 * @plugindesc Ultimes system plugin.
 * @author Feather
 *
 * @help 
 * Ultimes system plugin.
 *
 */
 

(() => {
    const pluginName = "Ultimes";
	
	UtMax = function () {
		
		return 20;
		
	};
	
	
	Game_BattlerBase.prototype.utMax = function() {
		let value = UtMax();
		if (this._equips && this.equips().some((item) => item && item.meta && item.meta.setUtMax)) value = this.equips().filter((item) => item && item.meta && item.meta.setUtMax).map((item) => eval(item.meta.setUtMax)).reduce((a,b) => Math.max(a,b));
		return value;
	};
	
	
	Game_BattlerBase.prototype.setUt = function(ut) {
		this._ut = ut;
		this.refresh();
	};
	
	Game_BattlerBase.prototype.getUtMultiplier = function() {
		
		
		let mult = 1;
		this._equips && this.equips().forEach(item => {item && item.meta.UT_Multiplier && (mult += (eval(item.meta.UT_Multiplier)-1))})
		mult *= (this.isGuard()) ? 2 : 1;
		return mult;
		
	}
	
	
	Game_BattlerBase.prototype.getUtKeep = function() {
		
		
		return this._equips && this.equips().some(item => item && item.meta.UT_Keep)
		
	}
	
	Game_BattlerBase.prototype.gainTurnUt = function() {
		this._ut += this.getUtMultiplier();
		if (this.hasSummons())
			this._summons.array.map(a => a._ut += a.getUtMultiplier());
		this.refresh();
	};
	
	Game_BattlerBase.prototype.UtCost = function(skill) {
		// Declare Variables
		const user = this;
		let cost = 0;

		// Calculations
		const note = skill.note;
		if (note.match(/<UT COST:[ ](\d+)>/i)) {
			cost += Number(RegExp.$1);
		}
		if (note.match(/<UT COST:[ ](\d+)([%％])>/i)) {
			cost += Math.ceil(Number(RegExp.$1) * user._ut / 100);
		}
		if (note.match(/<JS UT COST>\s*([\s\S]*)\s*<\/JS UT COST>/i)) {
			const code = String(RegExp.$1);
			eval(code);
		}

		// Apply Trait Cost Alterations
		if (cost > 0) {
			const rateNote = /<UT COST:[ ](\d+\.?\d*)([%％])>/i;
			const rates = user.traitObjects().map((obj) => (obj && obj.note.match(rateNote) ? Number(RegExp.$1) / 100 : 1));
			const flatNote = /<UT COST:[ ]([\+\-]\d+)>/i;
			const flats = user.traitObjects().map((obj) => (obj && obj.note.match(flatNote) ? Number(RegExp.$1) : 0));
			cost = rates.reduce((r, rate) => r * rate, cost);
			cost = flats.reduce((r, flat) => r + flat, cost);
			cost = Math.max(1, cost);
		}

		// Set Cost Limits
		if (note.match(/<UT COST MAX:[ ](\d+)>/i)) {
			cost = Math.min(cost, Number(RegExp.$1));
		}
		if (note.match(/<UT COST MIN:[ ](\d+)>/i)) {
			cost = Math.max(cost, Number(RegExp.$1));
		}

		// Return cost value
		return Math.round(Math.max(0, cost));
	}
	
	
	___Game_BattlerBase_initMembers = Game_BattlerBase.prototype.initMembers
	Game_BattlerBase.prototype.initMembers = function() {
		this._ut = (this.getUtKeep()) ? this._ut : 0;
		___Game_BattlerBase_initMembers.call(this);
	};
	
	___Game_Battler_onTurnEnd = Game_Battler.prototype.onTurnEnd
	Game_Battler.prototype.onTurnEnd = function() {
		this.gainTurnUt();
		___Game_Battler_onTurnEnd.call(this)
	};
	
	
	___Game_Battler_onBattleStart = Game_Battler.prototype.onBattleStart
	Game_Battler.prototype.onBattleStart = function(advantageous) {
		this.setUt((this.getUtKeep()) ? (this._ut || 0) : 0);
		___Game_Battler_onBattleStart.call(this, advantageous);
		
	};
	
	
	___Game_BattlerBase_refresh = Game_BattlerBase.prototype.refresh
	Game_BattlerBase.prototype.refresh = function() {
		___Game_BattlerBase_refresh.call(this);
		this._ut = this._ut || 0
		this._ut = this._ut.clamp(0, this.utMax());
	};

	Window_BattleStatus.prototype.drawItemStatusXPStyle = function(index) {
		const layout = VisuMZ.BattleCore.Settings.BattleLayout;
		const actor = this.actor(index);
		const rect = this.itemRect(index);
		const nameX = Math.round(rect.x + (rect.width - 0x80) / 0x2);
		const nameY = this.nameY(rect);
		let stateIconX = nameX - ImageManager.iconWidth / 0x2 - 0x4;
		let stateIconY = nameY + ImageManager.iconHeight / 0x2;
		if (stateIconX - ImageManager.iconWidth / 0x2 < rect.x) {
			stateIconX = nameX + ImageManager.iconWidth / 0x2 - 0x4;
			stateIconY = nameY - ImageManager.iconHeight / 0x2;
		}
		const basicGaugesX = nameX;
		const basicGaugesY = this.basicGaugesY(rect)-14;
			
		this.placeTimeGauge(actor, nameX + (layout.TpbGaugeOffsetX || 0x0), nameY + (layout.TpbGaugeOffsetY || 0x0));
		this.placeActorName(actor, nameX + (layout.NameOffsetX || 0x0), nameY + (layout.NameOffsetY-4 || 0x0));
		this.placeStateIcon(actor, stateIconX + (layout.StateIconOffsetX || 0x0), stateIconY + (layout.StateIconOffsetY || 0x0));
		this.placeGauge(actor, 'hp', basicGaugesX + (layout.HpGaugeOffsetX || 0x0), basicGaugesY + (layout.HpGaugeOffsetY || 0x0));
		this.placeGauge(actor, 'mp', basicGaugesX + (layout.MpGaugeOffsetX || 0x0), basicGaugesY + this.gaugeLineHeight() * 0.85 + (layout.TpGaugeOffsetY || 0x0));
		if ($dataSystem.optDisplayTp)
			this.placeGauge(actor, 'tp', basicGaugesX + (layout.TpGaugeOffsetX || 0x0), basicGaugesY + this.gaugeLineHeight() * 1.7 + (layout.TpGaugeOffsetY || 0x0));
		this.placeGauge(actor, 'ut', basicGaugesX + (layout.MpGaugeOffsetX || 0x0), basicGaugesY + this.gaugeLineHeight() * 2.5 + (layout.TpGaugeOffsetY || 0x0));
		this.placeGauge(actor, 'sp', basicGaugesX + (layout.MpGaugeOffsetX || 0x0) + 40, 0);
	}

})();
