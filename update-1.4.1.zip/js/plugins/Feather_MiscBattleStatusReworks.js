//=============================================================================
// RPG Maker MZ - MiscBattleStatusReworks
//=============================================================================

/*:
 * @target MZ
 * @plugindesc Misc Battle Status Reworks system plugin.
 * @author Feather
 *
 * @help 
 * Misc Battle Status Reworks system plugin.
 *
 */
 

(() => {
    const pluginName = "MiscBattleStatusReworks";
	$maxBattleMembers = 4;
	
	

	___FeatherMBSR___Window_BattleStatus_initialize = Window_BattleStatus.prototype.initialize;
	Window_BattleStatus.prototype.initialize = function(rect) {
		___FeatherMBSR___Window_BattleStatus_initialize.call(this, rect);
		this.frameVisible = true;
	};

	Window_BattleStatus.prototype.maxCols = function() {
		return 5;
	};

	Game_Party.prototype.maxBattleMembers = function() {
		return $maxBattleMembers;
	};

	Window_BattleStatus.prototype.scrollBaseX = function() {
		return (($gameParty.maxBattleMembers() <= 4) ? -this.itemWidth()/2 : 0);
	};

	___FeatherMBSR___Window_BattleStatus_update = Window_BattleStatus.prototype.update
	Window_BattleStatus.prototype.update = function() {
		___FeatherMBSR___Window_BattleStatus_update.call(this);
		if (this._index >= 0) {
			this.smoothSelect(this._index);
		}
	};

	Scene_Battle.prototype.statusWindowRect = function() {
		const extra = 10;
		const ww = Graphics.boxWidth - 192;
		const wh = this.windowAreaHeight() + extra + 40;
		const wx = this.isRightInputMode() ? 0 : Graphics.boxWidth - ww;
		const wy = Graphics.boxHeight - wh + extra - 4;
		return new Rectangle(wx, wy, ww, wh);
	};

	___FeatherMBSR___BattleManager_endBattle = BattleManager.endBattle;
	BattleManager.endBattle = function(result) {
		this._logWindow.clear();
		___FeatherMBSR___BattleManager_endBattle.call(this, result);
	};

	
})();
