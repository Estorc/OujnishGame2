//=============================================================================
// RPG Maker MZ - MiscClassLargerFix
//=============================================================================

/*:
 * @target MZ
 * @plugindesc Misc Class Larger Fix system plugin.
 * @author Feather
 *
 * @help 
 * Misc Class Larger Fix system plugin.
 *
 */
 

(() => {
    const pluginName = "MiscClassLargerFix";
	
	Window_StatusBase.prototype.drawActorSimpleStatus = function(actor, x, y) {
		const lineHeight = this.lineHeight();
		const x2 = x + 180;
		this.drawActorName(actor, x, y, 370);
		this.drawActorLevel(actor, x, y + lineHeight * 1);
		this.drawActorIcons(actor, x, y + lineHeight * 2);
		this.drawActorClass(actor, x + 370, y);
		this.placeBasicGauges(actor, x2, y + lineHeight);
	};
	
	
	if (typeof VisuMZ !== 'undefined') Window_SkillStatus.prototype[_0x2043a5(0x230)] = function() {
		const _0x38e51e = _0x2043a5;
		if (!Imported['VisuMZ_0_CoreEngine']) return;
		if (!Imported[_0x38e51e(0x1b6)]) return;
		const _0x32e728 = this['gaugeLineHeight']();
		let _0x1186be = this[_0x38e51e(0x248)]() / 0x2 + 0xb4 + 0xb4 + 0xb4,
			_0x27e8d8 = this['innerWidth'] - _0x1186be - 0x2;
		if (_0x27e8d8 >= 0x12c) {
			const _0x6d35f3 = VisuMZ[_0x38e51e(0x300)][_0x38e51e(0x34b)][_0x38e51e(0x458)]['DisplayedParams'],
				_0x53aab4 = Math[_0x38e51e(0x45b)](_0x27e8d8 / 0x2) - 0x18;
			let _0x3bc784 = _0x1186be,
				_0x1519d1 = Math[_0x38e51e(0x45b)]((this[_0x38e51e(0x341)] - Math[_0x38e51e(0x3e3)](_0x6d35f3[_0x38e51e(0x474)] / 0x2) * _0x32e728) / 0x2) + 0x16,
				_0x558c77 = 0x0;
			for (const _0xe4b667 of _0x6d35f3) {
				this[_0x38e51e(0x38a)](_0x3bc784, _0x1519d1, _0x53aab4, _0xe4b667), _0x558c77++;
				if (_0x558c77 % 0x2 === 0x0) {
					if (_0x38e51e(0x387) !== _0x38e51e(0x387)) {
						function _0x23d258() {
							const _0x38df9c = _0x38e51e,
								_0x9b396a = _0x5c7c22[_0x38df9c(0x376)]('[' + _0x56bc6d['$1'][_0x38df9c(0x47c)](/\d+/g) + ']');
							for (const _0x33293c of _0x9b396a) {
								if (!this['_actor']['isLearnedSkill'](_0x33293c)) return !![];
							}
							return ![];
						}
					} else _0x3bc784 = _0x1186be, _0x1519d1 += _0x32e728;
				} else _0x3bc784 += _0x53aab4 + 0x18;
			}
		}
		this['resetFontSettings']();
	}

})();
