//=============================================================================
// RPG Maker MZ - Censor
//=============================================================================

/*:
 * @target MZ
 * @plugindesc Censor system plugin.
 * @author Feather
 *
 * @help 
 * Censor system plugin.
 *
 */
 

(() => {
    const pluginName = "Censor";
	
	___Feather___ImageManager_loadBitmap = ImageManager.loadBitmap;
	ImageManager.loadBitmap = function(folder, filename) {
		if (!ConfigManager.FeatherCensor) {
			if (filename === "!$labitecosmique") filename = "!$labitecosmiqueUncensored";
			if (filename === "LaBitasCosmicas") filename = "LaBitasCosmicasUncensored";
			if (filename === "Labituscosmicus") filename = "LabituscosmicusUncensored";
			if (filename === "Oujnish4") filename = "Oujnish4Uncensored";
			if (filename === "IconSet") filename = "IconSetUncensored";
		}
		return ___Feather___ImageManager_loadBitmap.call(this,folder,filename);
	};
	
	___Feather___EffectManager_load = EffectManager.load;
	EffectManager.load = function(filename) {
		if (!ConfigManager.FeatherCensor) {
			if (filename == "LaBitasCosmicas") filename = "LaBitasCosmicasUncensored";
		}
		return ___Feather___EffectManager_load.call(this, filename);
	};
	
	___Feather___Video_play = Video.play;
	Video.play = function(src) {
		if (!ConfigManager.FeatherCensor) {
			if (src == "movies/BiteCosmiquePlan.webm") src = "movies/BiteCosmiquePlanUncensored.webm";
		}
		return ___Feather___Video_play.call(this,src);
	};
	
	
	ImageManager.loadSystem("IconSet");
	
	

})();
