//=============================================================================
// RPG Maker MZ - MapGeneration
//=============================================================================

/*:
 * @target MZ
 * @plugindesc Map Generation system plugin.
 * @author Feather
 *
 * @help 
 * Map Generation system plugin.
 *
 */
 

(() => {
const pluginName = "Feather_MapGeneration";

const SPAWN_REGION = 6;
const END_REGION = 14;
const UNIQUE_DECORATION_REGION = 62;
const END_DECORATION_REGION = 61;

//-----------------------------------------------------------------------------
// Game_RandomMap
//
// The game object class for a generated random map. It contains a lot of shading
// and generating functions.

Game_RandomMap = function() {
	this.initialize(...arguments);
};

/**
 * Generate a basic shape random map.
 */

Game_RandomMap.basicGeneration = function() {
	
	return new Game_RandomMap(...arguments);
	
}

/**
 * Initialise random map generation.
 */

Game_RandomMap.prototype.initialize = function(chaos,margin) {
	
	$gameMap.featherResetMapData();
	
	this.width = $gameMap.width()/7<<0;
	this.height = $gameMap.height()/7<<0;
	
	this.chaos = chaos;
	this.margin = margin;
	
	this.top = {x:this.width/2<<0,y:margin};
	this.left = {x:margin,y:this.height/2<<0};
	this.right = {x:this.width-1-margin,y:this.height/2<<0};
	this.bottom = {x:this.width/2<<0,y:this.height-1-margin};
	
	this.array = new Array(this.width*this.height).fill(0x0);
	
	this.array[this.top.x+this.top.y*this.width] = 0x30;
	this.array[this.left.x+this.left.y*this.width] = 0x50;
	this.array[this.right.x+this.right.y*this.width] = 0x90;
	this.array[this.bottom.x+this.bottom.y*this.width] = 0x110;
	
	this.connectedPoI = 0x0;
	while(this.connectedPoI !== 0x1e0) this.trace();
	//this.log();
};

/**
 * Tracing the map.
 */

Game_RandomMap.prototype.trace = function() {
	
	let w = this.width;
	let h = this.height;
	
	let margin = this.margin;
	let filteredList = this.array.filter(a => a & 0x10);
	let pos
	let dir;
	let move;
	let item;
	if (Math.random() <= this.chaos) {
		
		item = filteredList[Math.random()*filteredList.length<<0];
		let id = this.array.indexOf(item);
		pos = {x:id%w,
				y:id/w<<0};
		
		while (!move || Math.abs(move.x%(w-margin)-pos.x%(w-margin)) > 1 || move.x < margin || move.y < margin || move.x >= w-margin || move.y >= h-margin) {
			dir = Math.random()*4<<0;
			move = this.move(pos,dir);
		}
	} else {
		
		sortedList = filteredList.filter(a => !(a & 0x1e0 & this.connectedPoI)).sort((a,b) => (!!(a&0x1)+!!(a&0x2)+!!(a&0x4)+!!(a&0x8)) - (!!(b&0x1)+!!(b&0x2)+!!(b&0x4)+!!(b&0x8)));
		
		let i = [Math.random()*sortedList.length/2<<0];
		while (sortedList[i] && (!move || !item || this.array[move.x+move.y*w] & item & 0x1e0)) {
			item = sortedList[i];
			let id = this.array.indexOf(item);
			pos = {x:id%w,
					y:id/w<<0};
			
			dir = this.getDirectionToClosestTile(item,pos.x,pos.y);
			move = this.move(pos,dir);
			i++;
		}
	}
	
	this.createPath(pos.x+pos.y*w, move.x+move.y*w, dir);
	
};

/**
 * Get direction to the closest tile in distance.
 */

Game_RandomMap.prototype.getDirectionToClosestTile = function(tileCode, x, y) {
	let w = this.width;
	let h = this.height;
	let array = this.array.map((a,b) => [a,b%w,b/w<<0]).filter(a => (a[0] & 0x10) && !(a[0] & tileCode & 0x1e0));
	let closest = array.sort((a,b) => {
		Math.sqrt(Math.pow(x-a[1],2) + Math.pow(y-a[2],2)) - Math.sqrt(Math.pow(x-b[1],2) + Math.pow(y-b[2],2))
	});
	closest = closest[Math.random()*closest.length/2<<0]
	x = Math.abs(closest[1])-x;
	y = Math.abs(closest[2])-y;
	
	if (Math.abs(x)-Math.abs(y) < 0) {
		
		return y/Math.abs(y)+1;
		
	} else {
		
		return x/-Math.abs(x)+2;
		
	}
};

/**
 * Move around a tile.
 */

Game_RandomMap.prototype.move = function(pos, dir) {
	return {x:pos.x+(dir===1)-(dir===3),
			y:pos.y-(dir===0)+(dir===2)};
};

/**
 * Create a path between two tiles.
 */

Game_RandomMap.prototype.createPath = function(a, b, dir) {
	
	if ((this.array[a] & 0x1e0) & (this.connectedPoI & 0x1e0)) this.array[a] |= this.connectedPoI;
	
	this.array[a] |= 0x1*(dir===0);
	this.array[a] |= 0x2*(dir===1);
	this.array[a] |= 0x4*(dir===2);
	this.array[a] |= 0x8*(dir===3);
	
	this.array[b] |= 0x4*(dir===0);
	this.array[b] |= 0x8*(dir===1);
	this.array[b] |= 0x1*(dir===2);
	this.array[b] |= 0x2*(dir===3);
	
	if ((this.array[a] & 0x1e0) !== (this.array[b] & 0x1e0)) {
		if ((this.array[b] & 0x1e0) !== 0) {
			if (!this.connectedPoI) this.connectedPoI |= (this.array[a] & 0x1e0) | (this.array[b] & 0x1e0);
			if (this.connectedPoI & ((this.array[a] & 0x1e0) | (this.array[b] & 0x1e0))) this.connectedPoI |= (this.array[a] & 0x1e0) | (this.array[b] & 0x1e0);
			
		}
		if (!(this.array[b] & 0x1e0))
			this.array[b] |= this.array[a] & 0x1e0;
		else if ((this.array[a] & 0x1e0) !== (this.array[b] & 0x1e0)) {
			
			this.array = this.array.map((o,i,t) => {
				
				if ((o & 0x1e0) === (t[a] & 0x1e0)) return o | (t[b] & 0x1e0);
				if ((o & 0x1e0) === (t[b] & 0x1e0)) return o | (t[a] & 0x1e0);
				return o;
				
			});
			
		}
		
		this.array[b] |= 0x10;
		
	}
};

/**
 * Replace the current map by the generated map.
 */

Game_RandomMap.prototype.generate = function(modelA,modelB,modelC,modelD) {
	
	this.createArea();
	
	let blockset = this.loadBlockset(4,4,modelA).concat(this.loadBlockset(3,5,modelB)).concat(this.loadBlockset(4,4,modelC));
	
	for (let i = 0; i < this.height; i++) {
		
		for (let j = 0; j < this.width; j++) {
			
			$gameMap.placeSchematic(this.getSchematic(this.array[j+i*this.width],blockset),j*7,i*7);
			
		}
		
	}
	
	$gameMap.featherSetupAutotiles();
	let decorationset = this.loadDecoration(this.loadModel(modelD));
	this.drawDecoration(decorationset);
	$gameMap.featherSavePostGeneration();

	
};

/**
 * Load the differents blocksets for map shading.
 */

Game_RandomMap.prototype.loadBlockset = function(width,height,model) {
	
	let blockset = [];
	
	for (let i = 0; i<width; i++) {
		
		for (let j = 0; j<height; j++) {
			
			blockset[i+j*width] = $gameMap.loadSchematic(this.loadModel(model),1+i*8,1+j*8,7+i*8,7+j*8);
			
		}
		
	}
	
	return blockset;
	
}

/**
 * Load the differents models with XML requests (greedy).
 */


Game_RandomMap.prototype.loadModel = function(model) {
	
	let filename = "Map%1.json".format(model.padZero(3));
	let url = "data/" + filename;
	
	let xhr = new XMLHttpRequest();
	xhr.open("GET", url, false); // `false` makes the request synchronous
	xhr.overrideMimeType("application/json");
	xhr.send();

	if (xhr.status === 200) {
	  return JSON.parse(xhr.responseText);
	}
	
};

/**
 * Get the specific schematic that match the current tile code.
 */

Game_RandomMap.prototype.getSchematic = function(item, blockset) {
	
	if (item === 0xfff) return blockset[20];
	
	if ((item & 0xbff) === 0xbff) return blockset[25];
	if ((item & 0x7ff) === 0x7ff) return blockset[26];
	if ((item & 0xdff) === 0xdff) return blockset[28];
	if ((item & 0xeff) === 0xeff) return blockset[29];
	

	if ((item & 0xaff) === 0xaff) return blockset[27];
	if ((item & 0x5ff) === 0x5ff) return blockset[30];
	
	
	
	
	if ((item & 0xcef) === 0xcef) return blockset[32];
	if ((item & 0x3bf) === 0x3bf) return blockset[36];
	if ((item & 0x67f) === 0x67f) return blockset[41];
	if ((item & 0x9df) === 0x9df) return blockset[45];
	
	if ((item & 0x46f) === 0x46f) return blockset[34];
	if ((item & 0x8cf) === 0x8cf) return blockset[38];
	if ((item & 0x19f) === 0x19f) return blockset[42];
	if ((item & 0x23f) === 0x23f) return blockset[46];
	
	
	
	
	
	
	
	if ((item & 0x46f) === 0x466) return blockset[16];
	if ((item & 0x8cf) === 0x8cc) return blockset[18];
	if ((item & 0x23f) === 0x233) return blockset[22];
	if ((item & 0x19f) === 0x199) return blockset[24];
	
	
	if ((item & 0xcef) === 0xcee) return blockset[17];
	if ((item & 0x67f) === 0x677) return blockset[19];
	if ((item & 0x9df) === 0x9dd) return blockset[21];
	if ((item & 0x3bf) === 0x3bb) return blockset[23];
	
	
	
	if ((item & 0x46f) === 0x467) return blockset[31];
	if ((item & 0x23f) === 0x237) return blockset[35];
	
	if ((item & 0x8cf) === 0x8cd) return blockset[33];
	if ((item & 0x19f) === 0x19d) return blockset[37];
	
	if ((item & 0x46f) === 0x46e) return blockset[39];
	if ((item & 0x8cf) === 0x8ce) return blockset[40];
	
	if ((item & 0x23f) === 0x23b) return blockset[43];
	if ((item & 0x19f) === 0x19b) return blockset[44];

	
	item &= 0xf;
	
	if (item === 0xc) return blockset[3];
	if (item === 0x3) return blockset[9];
	if (item === 0x6) return blockset[1];
	if (item === 0x9) return blockset[11];
	
	if (item === 0x7) return blockset[5];
	if (item === 0xd) return blockset[7];
	if (item === 0xe) return blockset[2];
	if (item === 0xb) return blockset[10];
	
	if (item === 0xf) return blockset[6];
	if (item === 0xa) return blockset[8];
	if (item === 0x5) return blockset[4];
	if (item === 0x0) return blockset[0];
	
	if (item === 0x1) return blockset[12];
	if (item === 0x2) return blockset[13];
	if (item === 0x4) return blockset[14];
	if (item === 0x8) return blockset[15];
	
	
};

/**
 * Load the differents decorations for map shading.
 */

Game_RandomMap.prototype.loadDecoration = function(model) {

	let decorations = [];
	
	let h = model.height;
	let w = model.width;
	
	for (let y = 0; y<h; y++) {
		
		if (model.data[(5 * h + y) * w] > 0) {
			
			let tag = model.data[(5 * h + y) * w];
			if (!decorations[tag]) decorations[tag] = [1,1,0,[4]];
			else {
				decorations[tag][1]++;
				decorations[tag][3].push(decorations[tag].length);
			};
			
			for (let x = 1; x<w; x++) {
				
				if (model.data[(5 * h + y) * w + x] === tag) decorations[tag][0] = Math.max(decorations[tag][0], x+1);
				else {
					let tileData = 0;
					for (let z = 0; z<6; z++) {
						tileData += model.data[(z * h + y) * w + x];
						decorations[tag].push(model.data[(z * h + y) * w + x])
					}
					let event = model.events.find(a => a && a.x == x && a.y == y);
					decorations[tag].push(event);
					if ((tileData || event) && decorations[tag][2] < x) decorations[tag][2] = x;
					if (model.data[(5 * h + y) * w + x] === END_DECORATION_REGION) decorations[tag][2] = x-1;
				}
				
			};
			
		};
		
	};
	
	return decorations;
	
}

/**
 * Place the decoration in top of the generated map for final look.
 */

Game_RandomMap.prototype.drawDecoration = function(decorations) {

	let regionsId = [];
	let w = $dataMap.width;
	let h = $dataMap.height;
	
	for (let x = 0; x < w; x++) {
		
		for (let y = 0; y < h; y++) {
			
			if ($gameMap.tileId(x,y,5) > 0) regionsId.push(x+y*w);
			
		}
		
	}
	
	while (regionsId.length > 0) {
		let i = Math.random()*regionsId.length<<0;
		let tileId = regionsId[i];
		
		let region = $dataMap.data[tileId+5*h*w];
		let decoration = decorations[region];
		if (decoration) {
								
			let decoId = (Math.random()*((decoration[2])/decoration[0]<<0)<<0)*decoration[0];
			while (decoration[4+(decoId)*7] === -1) {
				decoId += decoration[0];
				if (decoId > decoration[2]) decoId = 0;
			}
			for (let x = 0; x<decoration[0]; x++) {
				for (let y = 0; y<decoration[1]; y++) {
					let ex = (tileId%w)+x;
					let ey = y+(tileId/w<<0);
					for (let z = 0; z<6; z++) {
						let item = decoration[decoration[3][y]+(decoId+x)*7+z];
						if (item) $dataMap.data[(z*h+y)*w+tileId+x] = item;
						
						if (z === 5 &&
							(item === UNIQUE_DECORATION_REGION ||
							item === SPAWN_REGION ||
							item === END_REGION)) decoration[4+(decoId)*7] = -1;
						
						if (z === 5 && item === SPAWN_REGION) {
							$gamePlayer.setPosition(ex,ey);
							$gamePlayer.followers().data().forEach(a => a.setPosition(ex,ey));
						}
						
					}
					
					let event = decoration[decoration[3][y]+(decoId+x)*7+6];
					if (event) {
						$gameMap.featherCloneEvent(event,ex,ey);
					};
					
					
				}
			}
			
		}
		
		regionsId.splice(i,1);
		
	}
	
	if ($gameMap.refresh());
	
}

/**
 * (DEBUG FUNCTION) : Log the entire generated map in ascii.
 */

Game_RandomMap.prototype.log = function() {
	
	for (let i = 0; i < this.height; i++) {
		
		let line = "";
		
		for (let j = 0; j < this.width; j++) {
			
			line += this.hexToChar(this.array[j+i*this.width]);
			
		}
		
		console.log(line);
		
	}
	
};

/**
 * (DEBUG FUNCTION) : Transform map tile code in ascii code.
 */

Game_RandomMap.prototype.hexToChar = function(item) {
	
	item = item & 0xf;
	
	if (item === 0xc) return "╗";
	if (item === 0x3) return "╚";
	if (item === 0x6) return "╔";
	if (item === 0x9) return "╝";
	
	if (item === 0x7) return "╠";
	if (item === 0xd) return "╣";
	if (item === 0xe) return "╦";
	if (item === 0xb) return "╩";
	
	if (item === 0xf) return "╬";
	if (item === 0xa) return "═";
	if (item === 0x5) return "║";
	if (item === 0x0) return "░";
	
	if (item === 0x1) return "╹";
	if (item === 0x2) return "╺";
	if (item === 0x4) return "╻";
	if (item === 0x8) return "╸";
	
	
};

/**
 * Transform map crossroads into area if possible (look more organic).
 */

Game_RandomMap.prototype.createArea = function () {
	
	this.array = this.array.map((a,b,c) => {
		
		return (a&0xf) |
				( ( (c[b-this.width] & 0x4) ) === 0x4)  * 0x10 |
				( ( (c[b+1] & 0x8) ) === 0x8) 			 * 0x20 |
				( ( (c[b+this.width] & 0x1) ) === 0x1) * 0x40 |
				( ( (c[b-1] & 0x2) ) === 0x2) 			 * 0x80 |
				
				( (c[b-this.width-1] & 0x6) === 0x6) * 0x100 |
				( (c[b-this.width+1] & 0xc) === 0xc) * 0x200 |
				( (c[b+this.width+1] & 0x9) === 0x9) * 0x400 |
				( (c[b+this.width-1] & 0x3) === 0x3) * 0x800;
		
	},this);
	
};
	
})();
