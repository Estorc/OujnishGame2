//=============================================================================
// RPG Maker MZ - VideoVolume
//=============================================================================

/*:
 * @target MZ
 * @plugindesc Video Volume system plugin.
 * @author Feather
 *
 * @help 
 * Video Volume system plugin.
 *
 */
 

(() => {
    const pluginName = "VideoVolume";

	Game_Interpreter.prototype.command261 = function(params) {
		if ($gameMessage.isBusy()) {
			return false;
		}
		const name = params[0];
		if (name.length > 0) {
			const ext = this.videoFileExt();
			Video._volume = (WebAudio._masterVolume)*(AudioManager._bgmVolume/100)
			Video.play("movies/" + name + ext);
			this.setWaitMode("video");
		}
		return true;
	};

	
})();
