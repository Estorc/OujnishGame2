//=============================================================================
// RPG Maker MZ - Day Night System
//=============================================================================

/*:
 * @target MZ
 * @plugindesc Day Night system plugin.
 * @author Feather
 *
 * @help 
 * Day Night system plugin.
 *
 */
 

(() => {
    const pluginName = "Feather_DayNightSystem";
	
	DAY_LIGHT_COLOR = "#ffffff";
	DUSK_LIGHT_COLOR = "#ccbb66";
	NIGHT_LIGHT_COLOR = "#333366";
	DAWN_LIGHT_COLOR = "#ccbb66";
	
	CAVE_LIGHT_COLOR = "#404040";
	UNDERWATER_LIGHT_COLOR = "#000080";
	HOUSE_LIGHT_COLOR = "#FFFFFF";
	
	
	FeatherDayNightSystem = function() {
		throw new Error("This is a static class");
	};
	
	FeatherDayNightSystem.timer = 0;
	
	
	FeatherDayNightSystem.CommunityLightingSetup = function() {
		
		let commands = ["regionlight","regionfire","regionglow"];
		let lightTypes = ["light","fire","glow"]
		let colors = ($dataMap.note.includes('<House>')) ? ["a#666666","a#a07000","a#00ffff"] : ["#666666","#ffdd00","#00ffff"];
		let lightRadius = ["150","150","25"];
		let brightnesses = ["0","100","100"];
		
		for (let k = 0; k < 3; k++) {
            PluginManager.callCommand(
              $gameMap._interpreter,
              'Community_Lighting_MZ',
              'tileLight',
              {tileType:"region",lightType:lightTypes[k],id:(50+k).toString(), enabled:"true", color:colors[k], radius:lightRadius[k], brightness:brightnesses[k]}
            );
		}
		
		PluginManager.callCommand(
		  $gameMap._interpreter,
		  'Community_Lighting_MZ',
		  'tileBlock',
		  {tileType:"region",id:"255", enabled:"true", color:"a#000000", shape:"0", xOffset:"0", yOffset:"0", blockWidth:"48", blockHeight:"48"}
		);
		
		this.reloadNeeded = true;
		$gameVariables.SetDaynightSpeed(0);
	
	}
	
	
	FeatherDayNightSystem.updateTimePeriod = function() {
		
		if ($gameVariables.value(2) >= 0 && $gameVariables.value(2) <= 40) {
			
			$gameVariables.setValue(3,1);
			
		}
		
		if ($gameVariables.value(2) > 40 && $gameVariables.value(2) <= 60) {
			
			$gameVariables.setValue(3,2);
			
		}
		
		if ($gameVariables.value(2) > 60 && $gameVariables.value(2) <= 100) {
			
			$gameVariables.setValue(3,3);
			
		}
		
		if ($gameVariables.value(2) > 100 && $gameVariables.value(2) <= 120) {
			
			$gameVariables.setValue(3,4);
			
		}
		
	}
	
	
	FeatherDayNightSystem.update = function() {
		
		if (this.reloadNeeded) {
			Community.Lighting.ReloadTagArea();
			this.reloadNeeded = false;
		}
		
		if (this.timer <= 0) {
			
			let dayTransition = true;
			let timeFlow = true;
			let dayLight = true;
			
			
			if ($dataMap.note.includes('<Sunshine*>')) {
				
				const filterController = $gameMap.getFilterController("daysunray");
				if (!filterController) {
					$gameMap.createFilter("daysunray","godray","TileAndChars");
				}
				
			} else if (!$dataMap.note.includes('<Sunshine>')) {
				
				$gameMap.eraseFilter('daysunray');
				
			};
			
			if ($dataMap.note.includes('<Cave>')) {
				
				dayLight = false;
				timeFlow = false;
				dayTransition = false;
				
				$gameVariables.SetTintTarget(ColorDelta.createTint(new VRGBA(CAVE_LIGHT_COLOR), 40));
				
			};
			
			if ($dataMap.note.includes('<Underwater>')) {
				
				dayLight = false;
				timeFlow = false;
				dayTransition = false;
				
				$gameVariables.SetTintTarget(ColorDelta.createTint(new VRGBA(UNDERWATER_LIGHT_COLOR), 0));
				
			};
			
			if ($dataMap.note.includes('<House>')) {
				
				dayLight = false;
				timeFlow = false;
				dayTransition = false;
				
				$gameVariables.SetTintTarget(ColorDelta.createTint(new VRGBA(HOUSE_LIGHT_COLOR), 0));
				
			};
			
			if ($dataMap.note.includes('<CustomTime>')) {
				
				dayLight = false;
				timeFlow = false;
				dayTransition = false;
				
			};
			
			if ($dataMap.note.includes('<NoTime>')) {
				
				timeFlow = false;
				
			};
			
			if (timeFlow) {
				
				$gameVariables.setValue(2,$gameVariables.value(2)+1);
				
			}
			
			this.updateTimePeriod();
			
			if (dayTransition) {
				
				if ($gameVariables.value(2) > 120) {
					
					$gameVariables.setValue(2,0);
					
				}
				
				if (!dayLight) {
					
					switch ($gameVariables.value(3)) {
						
						case 1:
							$gameVariables.SetTintTarget(ColorDelta.createTint(new VRGBA(DAY_LIGHT_COLOR), 0));
							break;
						
						case 2:
							$gameVariables.SetTintTarget(ColorDelta.createTint(new VRGBA(DUSK_LIGHT_COLOR), 0));
							break;
						
						case 3:
							$gameVariables.SetTintTarget(ColorDelta.createTint(new VRGBA(NIGHT_LIGHT_COLOR), 0));
							break;
						
						case 4:
							$gameVariables.SetTintTarget(ColorDelta.createTint(new VRGBA(DAWN_LIGHT_COLOR), 0));
							break;
						
					}
					
				}
				
				
				if ($gameVariables.value(3) == 1) {
				
					if ($dataMap.note.includes('<Sunshine>')) {
						
						const filterController = $gameMap.getFilterController("daysunray");
						if (!filterController) {
							$gameMap.createFilter("daysunray","godray","TileAndChars");
						}
						
					} else {
						
						$gameMap.eraseFilter('daysunray');
						
					}
					
				} else {
				
					if ($dataMap.note.includes('<Sunshine*>')) {
						
						const filterController = $gameMap.getFilterController("daysunray");
						if (!filterController) {
							$gameMap.createFilter("daysunray","godray","TileAndChars");
						}
						
					}
					
				};
				
				switch ($gameVariables.value(3)) {
					
					case 1:
						$gameVariables.SetTintTarget(ColorDelta.createTint(new VRGBA(DAY_LIGHT_COLOR), 200));
						break;
					
					case 2:
						$gameVariables.SetTintTarget(ColorDelta.createTint(new VRGBA(DUSK_LIGHT_COLOR), 200));
						break;
					
					case 3:
						$gameVariables.SetTintTarget(ColorDelta.createTint(new VRGBA(NIGHT_LIGHT_COLOR), 200));
						break;
					
					case 4:
						$gameVariables.SetTintTarget(ColorDelta.createTint(new VRGBA(DAWN_LIGHT_COLOR), 200));
						break;
					
				}
				
				
			}
		
			this.timer = 200;
		
		}
		
		this.timer -= 1;
		
	}
	
	
	___FeatherDNS___Scene_Map_start = Scene_Map.prototype.start;
	Scene_Map.prototype.start = function(mapId) {
		___FeatherDNS___Scene_Map_start.call(this);
		FeatherDayNightSystem.CommunityLightingSetup();
		FeatherDayNightSystem.timer = 0;
	};
	
	
	___FeatherDNS___Game_Map_update = Game_Map.prototype.update;
	Game_Map.prototype.update = function(sceneActive) {
		___FeatherDNS___Game_Map_update.call(this, sceneActive);
		FeatherDayNightSystem.update();
	};
	

})();
