//=============================================================================
// RPG Maker MZ - Feather Core
//=============================================================================

/*:
 * @target MZ
 * @plugindesc The core plugin for all Feather's plugins.
 * @author Feather
 *
 * @help 
 * The core plugin for all Feather's plugins.
 *
 */
 

(() => {
    const pluginName = "FeatherCore";
	
	
	//-----------------------------------------------------------------------------
	// Feather_Core
	//
	// The main class of Feather's plugins.
	
	
	Feather_Core = function() {
		throw new Error("This is a static class");
	};
	
	
	Feather_Core.initialize = function() {
		this.createKeyboardStringMap();
		this.createKeyboardIconMap();
	};
	
	
	Feather_Core.preloadRessources = {};

	Feather_Core.deepCopy = function(object) {
		return JSON.parse(JSON.stringify(object))
	}

	Feather_Core.range = function(start, end = 0, iterator = 1) {
		return Array.apply(null,Array(Math.ceil(Math.abs(end - start)/iterator))).map((a,b) => (start < end)*start+b*iterator);
	}
	
	
	Feather_Core.rotatePoint = function(cx, cy, x, y, angle) {		
		let sinus   = Math.sin((-angle)*Math.PI/180);
		let cosinus = Math.cos((-angle)*Math.PI/180);
		let tmpx = 0;
		let tmpy = 0;

		x = x - cx;
		y = y - cy;
		tmpx = x * cosinus - y * sinus;
		tmpy = x * sinus   + y * cosinus;
		x = tmpx + cx;
		y = tmpy + cy;

		return {x:x,y:y};
	};
	
	
	Feather_Core.rotateRect = function(rect, cx, cy, angle) {
		let tl = this.rotatePoint(cx,cy,rect.x1,rect.y1,angle);
		let tr = this.rotatePoint(cx,cy,rect.x2,rect.y1,angle);
		let bl = this.rotatePoint(cx,cy,rect.x1,rect.y2,angle);
		let br = this.rotatePoint(cx,cy,rect.x2,rect.y2,angle);
		
		return {tl:tl,tr:tr,bl:bl,br:br};
	};
	
	
	Feather_Core.getDirectionToPosition = function(x1,y1,x2,y2) {
		
		let direction = 0;
		
		direction = (Math.atan2(y1 - y2, x1 - x2) * 180 / Math.PI)-180;
		if (direction < 0) {
			direction += 360;
		}
		return direction;
		
	};

	
	Feather_Core.getDistanceBetweenPoints = function(x1,y1,x2,y2) {
		
		let distance = Math.sqrt(Math.pow((x2-x1),2) + Math.pow((y2-y1),2))
		return distance;
		
	};
	
	
	Feather_Core.easeOutSine = function (t, b, c, d) {
		
			return c * Math.sin(t / d * (Math.PI / 2)) + b;
			
	};
	
	Game_Interpreter.prototype.event = function() { 
		return $gameMap.event(this._eventId);
	}

	Feather_Core.loadPluginParameters = function(params,type) {
		type = type || 'root';
		let nextType;
		if (type.includes('[]')) {
			nextType = type.replace('[]','');
			type = 'array';
		}
		let newParams = params;
		switch (type) {
			case 'array':
				newParams = [];
				params = JSON.parse(params);
				for (param in params) {
					newParams[param] = Feather_Core.loadPluginParameters(params[param], nextType);
					
				}
			break;
			case 'struct':
				params = JSON.parse(params);
			case 'root':
				newParams = {};
				for (param in params) {
					const splitedParam = param.split(':');
					const name = splitedParam[0];
					const type = splitedParam[1];
					newParams[name] = Feather_Core.loadPluginParameters(params[param], type);
					
				}
			break;
			case 'arraystruct':
				newParams = [];
				params = JSON.parse(params);
				for (param in params) {
					newParams[param] = Feather_Core.loadPluginParameters(params[param], 'struct');
					
				}
			break;
			case 'number':
				newParams = eval(params);
			break;
			case 'object':
				newParams = JSON.parse(params);
			break;
		};
		return newParams;
	};
	

	Feather_Core.extractArrayLongMetadata = function(array) {
		if (Array.isArray(array)) {
			for (const data of array) {
				if (data && "note" in data) {
					Feather_Core.extractLongMetadata(data);
				}
			}
		}
	};


	Feather_Core.extractLongMetadata = function(data) {
		const regExp = /<(\$*)([^\/][^>]*)>\n([^<]*(?:.*?))<\/\$*\2>/gms;
		data.longMeta = {};
		for (;;) {
			const match = regExp.exec(data.note);
			if (match) {
				let content = {};
				
				const inRegExp = / *([^\n:]*): *([^\n]*)/gm;
				for (;;) {
					const inMatch = inRegExp.exec(match[3]);
					if (inMatch) {
						content[inMatch[1]] = inMatch[2];
					} else {
						break;
					}
				}
				
				if (match[1] === '$') {
					if (!data.longMeta[match[2]]) data.longMeta[match[2]] = [];
					data.longMeta[match[2]].push(content);
				} else {
					data.longMeta[match[2]] = content;
				}
				
			} else {
				break;
			}
		}
	};
	
	
	Feather_Core.extractMetadataArray = function(data) {
		const regExp = /<\$([^<>:]+)(:?)([^>]*)>/g;
		data.metaArray = {};
		for (;;) {
			const match = regExp.exec(data.note);
			if (match) {
				if (!data.metaArray[match[1]]) data.metaArray[match[1]] = [];
				if (match[2] === ":") {
					data.metaArray[match[1]].push(match[3]);
				} else {
					data.metaArray[match[1]].push(true);
				}
			} else {
				break;
			}
		}
	};
	
	
	Feather_Core.convertKeyCodeToIcon = function(keyCode) {
	
		return this.keyboardIconMap[keyCode]
	
	};
	
	
	Feather_Core.convertKeyCodeToString = function(keyCode) {
		
		return this.keyboardStringMap[keyCode];
		
	};
	
	
	Feather_Core.createKeyboardStringMap = function() {
		this.keyboardStringMap = [
		  "", // [0]
		  "", // [1]
		  "", // [2]
		  "CANCEL", // [3]
		  "", // [4]
		  "", // [5]
		  "HELP", // [6]
		  "", // [7]
		  "BACK_SPACE", // [8]
		  "TAB", // [9]
		  "", // [10]
		  "", // [11]
		  "CLEAR", // [12]
		  "ENTER", // [13]
		  "ENTER_SPECIAL", // [14]
		  "", // [15]
		  "SHIFT", // [16]
		  "CONTROL", // [17]
		  "ALT", // [18]
		  "PAUSE", // [19]
		  "CAPS_LOCK", // [20]
		  "KANA", // [21]
		  "EISU", // [22]
		  "JUNJA", // [23]
		  "FINAL", // [24]
		  "HANJA", // [25]
		  "", // [26]
		  "ESCAPE", // [27]
		  "CONVERT", // [28]
		  "NONCONVERT", // [29]
		  "ACCEPT", // [30]
		  "MODECHANGE", // [31]
		  "SPACE", // [32]
		  "PAGE_UP", // [33]
		  "PAGE_DOWN", // [34]
		  "END", // [35]
		  "HOME", // [36]
		  "LEFT", // [37]
		  "UP", // [38]
		  "RIGHT", // [39]
		  "DOWN", // [40]
		  "SELECT", // [41]
		  "PRINT", // [42]
		  "EXECUTE", // [43]
		  "PRINTSCREEN", // [44]
		  "INSERT", // [45]
		  "DELETE", // [46]
		  "", // [47]
		  "0", // [48]
		  "1", // [49]
		  "2", // [50]
		  "3", // [51]
		  "4", // [52]
		  "5", // [53]
		  "6", // [54]
		  "7", // [55]
		  "8", // [56]
		  "9", // [57]
		  "COLON", // [58]
		  "SEMICOLON", // [59]
		  "LESS_THAN", // [60]
		  "EQUALS", // [61]
		  "GREATER_THAN", // [62]
		  "QUESTION_MARK", // [63]
		  "AT", // [64]
		  "A", // [65]
		  "B", // [66]
		  "C", // [67]
		  "D", // [68]
		  "E", // [69]
		  "F", // [70]
		  "G", // [71]
		  "H", // [72]
		  "I", // [73]
		  "J", // [74]
		  "K", // [75]
		  "L", // [76]
		  "M", // [77]
		  "N", // [78]
		  "O", // [79]
		  "P", // [80]
		  "Q", // [81]
		  "R", // [82]
		  "S", // [83]
		  "T", // [84]
		  "U", // [85]
		  "V", // [86]
		  "W", // [87]
		  "X", // [88]
		  "Y", // [89]
		  "Z", // [90]
		  "OS_KEY", // [91] Windows Key (Windows) or Command Key (Mac)
		  "", // [92]
		  "CONTEXT_MENU", // [93]
		  "", // [94]
		  "SLEEP", // [95]
		  "NUMPAD0", // [96]
		  "NUMPAD1", // [97]
		  "NUMPAD2", // [98]
		  "NUMPAD3", // [99]
		  "NUMPAD4", // [100]
		  "NUMPAD5", // [101]
		  "NUMPAD6", // [102]
		  "NUMPAD7", // [103]
		  "NUMPAD8", // [104]
		  "NUMPAD9", // [105]
		  "MULTIPLY", // [106]
		  "ADD", // [107]
		  "SEPARATOR", // [108]
		  "SUBTRACT", // [109]
		  "DECIMAL", // [110]
		  "DIVIDE", // [111]
		  "F1", // [112]
		  "F2", // [113]
		  "F3", // [114]
		  "F4", // [115]
		  "F5", // [116]
		  "F6", // [117]
		  "F7", // [118]
		  "F8", // [119]
		  "F9", // [120]
		  "F10", // [121]
		  "F11", // [122]
		  "F12", // [123]
		  "F13", // [124]
		  "F14", // [125]
		  "F15", // [126]
		  "F16", // [127]
		  "F17", // [128]
		  "F18", // [129]
		  "F19", // [130]
		  "F20", // [131]
		  "F21", // [132]
		  "F22", // [133]
		  "F23", // [134]
		  "F24", // [135]
		  "", // [136]
		  "", // [137]
		  "", // [138]
		  "", // [139]
		  "", // [140]
		  "", // [141]
		  "", // [142]
		  "", // [143]
		  "NUM_LOCK", // [144]
		  "SCROLL_LOCK", // [145]
		  "WIN_OEM_FJ_JISHO", // [146]
		  "WIN_OEM_FJ_MASSHOU", // [147]
		  "WIN_OEM_FJ_TOUROKU", // [148]
		  "WIN_OEM_FJ_LOYA", // [149]
		  "WIN_OEM_FJ_ROYA", // [150]
		  "", // [151]
		  "", // [152]
		  "", // [153]
		  "", // [154]
		  "", // [155]
		  "", // [156]
		  "", // [157]
		  "", // [158]
		  "", // [159]
		  "CIRCUMFLEX", // [160]
		  "EXCLAMATION", // [161]
		  "DOUBLE_QUOTE", // [162]
		  "HASH", // [163]
		  "DOLLAR", // [164]
		  "PERCENT", // [165]
		  "AMPERSAND", // [166]
		  "UNDERSCORE", // [167]
		  "OPEN_PAREN", // [168]
		  "CLOSE_PAREN", // [169]
		  "ASTERISK", // [170]
		  "PLUS", // [171]
		  "PIPE", // [172]
		  "HYPHEN_MINUS", // [173]
		  "OPEN_CURLY_BRACKET", // [174]
		  "CLOSE_CURLY_BRACKET", // [175]
		  "TILDE", // [176]
		  "", // [177]
		  "", // [178]
		  "", // [179]
		  "", // [180]
		  "VOLUME_MUTE", // [181]
		  "VOLUME_DOWN", // [182]
		  "VOLUME_UP", // [183]
		  "", // [184]
		  "", // [185]
		  "SEMICOLON", // [186]
		  "EQUALS", // [187]
		  "COMMA", // [188]
		  "MINUS", // [189]
		  "PERIOD", // [190]
		  "SLASH", // [191]
		  "BACK_QUOTE", // [192]
		  "", // [193]
		  "", // [194]
		  "", // [195]
		  "", // [196]
		  "", // [197]
		  "", // [198]
		  "", // [199]
		  "", // [200]
		  "", // [201]
		  "", // [202]
		  "", // [203]
		  "", // [204]
		  "", // [205]
		  "", // [206]
		  "", // [207]
		  "", // [208]
		  "", // [209]
		  "", // [210]
		  "", // [211]
		  "", // [212]
		  "", // [213]
		  "", // [214]
		  "", // [215]
		  "", // [216]
		  "", // [217]
		  "", // [218]
		  "OPEN_BRACKET", // [219]
		  "BACK_SLASH", // [220]
		  "CLOSE_BRACKET", // [221]
		  "QUOTE", // [222]
		  "", // [223]
		  "META", // [224]
		  "ALTGR", // [225]
		  "", // [226]
		  "WIN_ICO_HELP", // [227]
		  "WIN_ICO_00", // [228]
		  "", // [229]
		  "WIN_ICO_CLEAR", // [230]
		  "", // [231]
		  "", // [232]
		  "WIN_OEM_RESET", // [233]
		  "WIN_OEM_JUMP", // [234]
		  "WIN_OEM_PA1", // [235]
		  "WIN_OEM_PA2", // [236]
		  "WIN_OEM_PA3", // [237]
		  "WIN_OEM_WSCTRL", // [238]
		  "WIN_OEM_CUSEL", // [239]
		  "WIN_OEM_ATTN", // [240]
		  "WIN_OEM_FINISH", // [241]
		  "WIN_OEM_COPY", // [242]
		  "WIN_OEM_AUTO", // [243]
		  "WIN_OEM_ENLW", // [244]
		  "WIN_OEM_BACKTAB", // [245]
		  "ATTN", // [246]
		  "CRSEL", // [247]
		  "EXSEL", // [248]
		  "EREOF", // [249]
		  "PLAY", // [250]
		  "ZOOM", // [251]
		  "", // [252]
		  "PA1", // [253]
		  "WIN_OEM_CLEAR", // [254]
		  "" // [255]
		];
	};
	
	
	Feather_Core.createKeyboardIconMap = function() {
		this.keyboardIconMap = {
		  37:346,
		  38:348,
		  39:347,
		  40:349,
		  
		  16:1099,
		  17:1088,
		  32:1087,
		  13:1086,
		  
		  65:320,
		  66:321,
		  67:322,
		  68:323,
		  69:324,
		  70:325,
		  71:326,
		  72:327,
		  73:328,
		  74:329,
		  75:330,
		  76:331,
		  77:332,
		  78:333,
		  79:334,
		  80:335,
		  81:336,
		  82:337,
		  83:338,
		  84:339,
		  85:340,
		  86:341,
		  87:342,
		  88:343,
		  89:344,
		  90:345,
		  
		  96:361,
		  97:352,
		  98:353,
		  99:354,
		  100:355,
		  101:356,
		  102:357,
		  103:358,
		  104:359,
		  105:360

		};
	};

	Input.keyMapper[67] = "orderChange";
	Input.keyMapper[80] = "philosophicalCircle";
	
	
	Feather_Core.initialize();
	
	
	//-----------------------------------------------------------------------------
	// Feather_PictureManager
	//
	// A permanent Picture Manager to increase performance
	// in the cost of memory.
	
	
	Feather_PictureManager = new Sprite();
	
	Feather_PictureManager.createPictures = function() {
		if (!this._pictureContainer) {
			const rect = this.pictureContainerRect();
			this._pictureContainer = new Sprite();
			this._pictureContainer.setFrame(rect.x, rect.y, rect.width, rect.height);
			for (let i = 1; i <= $gameScreen.maxPictures(); i++) {
				this._pictureContainer.addChild(new Sprite_Picture(i));
			}
			this.addChild(this._pictureContainer);
		}
	};
	
	Feather_PictureManager.destroy = function() {
		//
	}

	Feather_PictureManager.pictureContainerRect = function() {
		return new Rectangle(0, 0, Graphics.width, Graphics.height);
	};
	
	
	//-----------------------------------------------------------------------------
	// Spriteset_Feather
	//
	// The set of sprites of Feather's plugins.


	Spriteset_Feather = function() {
		this.initialize(...arguments);
	};
	

	Spriteset_Feather.prototype = Object.create(Spriteset_Base.prototype);
	Spriteset_Feather.prototype.constructor = Spriteset_Feather;
	
	
	Spriteset_Base.prototype.createUpperLayer = function() {
		this.createPictures();
		this.createOverallFilters();
	};


	Spriteset_Feather.prototype.pictureContainerRect = function() {
		return new Rectangle(0, 0, Graphics.width, Graphics.height);
	};
	
	
	Spriteset_Feather.prototype.createBaseSprite = function() {
		this._baseSprite = new Sprite();
		this.addChild(this._baseSprite);;
	};
	
	
	//-----------------------------------------------------------------------------
	// Classes rewrite
	//
	
	
	String.prototype.toNorse = function() {
		return this.replace(/[a-z]/gmi,item => {
			return String.fromCharCode(0x1670+item.charCodeAt(0))
		});;
	};
	
    Game_Character.prototype.getActor = function () { return; };
	
    Game_Player.prototype.getActor = function () {
        if (!$gameParty || !$gameParty.battleMembers) return;
        return $gameParty.battleMembers()[0];
    };
	
	Game_Follower.prototype.getActor = function () {
        if (!$gameParty || !$gameParty.battleMembers) return;
        return $gameParty.battleMembers()[this._memberIndex];
    };
	
    Game_Actor.prototype.getCharacter = function () {
        if ($gamePlayer.getActor()._actorId == this._actorId) return $gamePlayer;
        let character = $gamePlayer.followers().find(item => (item.getActor()._actorId == this._actorId));
		return character;
    };
	
    Game_CharacterBase.prototype.getSprite = function () {
        if (!(SceneManager._scene && SceneManager._scene._spriteset && SceneManager._scene._spriteset._characterSprites)) return null;
        return SceneManager._scene._spriteset._characterSprites.find(item => (item._character === this));
    };
	
	
	Spriteset_Base.prototype.createPictures = function() {
		Feather_PictureManager.createPictures();
		this.addChild(Feather_PictureManager);
	};
	
	
	___FeatherC___TouchInput__onRightButtonDown = TouchInput._onRightButtonDown;
	TouchInput._onRightButtonDown = function(event) {
		___FeatherC___TouchInput__onRightButtonDown.call(this, event);
		const x = Graphics.pageToCanvasX(event.pageX);
		const y = Graphics.pageToCanvasY(event.pageY);
		if (Graphics.isInsideCanvas(x, y)) {
			this._rightMousePressed = true;
		}
	};
	
	
	___FeatherC___TouchInput___onMouseUp = TouchInput._onMouseUp;
	TouchInput._onMouseUp = function(event) {
		___FeatherC___TouchInput___onMouseUp.call(this,event)
		if (event.button === 2) {
			this._rightMousePressed = false;
		}
	};


	TouchInput.isRightPressed = function() {
		return this._rightMousePressed;
	};

	
	_Scene_Battle_createSpriteset = Scene_Battle.prototype.createSpriteset
	Scene_Battle.prototype.createSpriteset = function() {
		_Scene_Battle_createSpriteset.call(this)
		this._featherSpriteset = new Spriteset_Feather();
		this.addChild(this._featherSpriteset);
	};


	_Scene_Map_createSpriteset = Scene_Map.prototype.createSpriteset
	Scene_Map.prototype.createSpriteset = function() {
		_Scene_Map_createSpriteset.call(this)
		this._featherSpriteset = new Spriteset_Feather();
		this.addChild(this._featherSpriteset);
	};
	
	
	Scene_Battle.prototype.createPictures = function() {

	};
	

	Scene_Map.prototype.createPictures = function() {

	};
	

	_DataManager_extractArrayMetadata = DataManager.extractArrayMetadata;
	DataManager.extractArrayMetadata = function(array) {
		_DataManager_extractArrayMetadata.call(this, array);
		Feather_Core.extractArrayLongMetadata.call(this, array);
	};


	_DataManager_extractMetadata = DataManager.extractMetadata;
	DataManager.extractMetadata = function(data) {
		_DataManager_extractMetadata.call(this, data);
		Feather_Core.extractMetadataArray.call(this, data);
		Feather_Core.extractLongMetadata.call(this, data);
	};
	
	
})();
