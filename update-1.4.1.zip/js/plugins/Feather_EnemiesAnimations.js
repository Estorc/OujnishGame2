//=============================================================================
// RPG Maker MZ - EnemiesAnimations
//=============================================================================

/*:
 * @target MZ
 * @plugindesc Enemies Animations system plugin.
 * @author Feather
 *
 * @help 
 * Enemies Animations system plugin.
 *
 */
 

(() => {
    const pluginName = "EnemiesAnimations";
	
	
	
	
	playDOGAnimation = function() {
		
		if ($dataEnemies[this._enemy._enemyId].meta.dog) {
			
			if (typeof this.rotDir === 'undefined') {
				
				this.rotDir = 0;
				this._mainSprite.anchor.y = 0.5;
				this._mainSprite.anchor.x = 80/168;
				this._defoffsetY = this._offsetY
				console.log(this._enemy._screenX + 228);
				switch (this._enemy._screenX + 228) {
					case 334:
					this.movedur = 0;
					this.rotDir = 6;
					this._mainSprite.anchor.x = 0.5;
					this._offsetX = 50;
					break;
					case 476:
					this.movedur = 1;
					this.rotDir = 5;
					this._offsetX = -5;
					break;
					case 563:
					this.movedur = 2;
					this.rotDir = 4;
					this._offsetX = -10;
					break;
					case 651:
					this.movedur = 3;
					this.rotDir = 3;
					this._offsetX = -15;
					break;
					case 739:
					this.movedur = 4;
					this.rotDir = 2;
					this._offsetX = -20;
					break;
					case 826:
					this.movedur = 5;
					this.rotDir = 1;
					this._offsetX = -25;
					break;
					case 944:
					this.movedur = 6;
					this._offsetX = -62;
					this.rotDir = 0;
					this._mainSprite.anchor.x = 80/228;
					break;
				}
				this._offsetX += 228
				
			}
			
			
			let levitateData = eval($dataEnemies[this._enemy._enemyId].meta.levitate)
			this.movedur -= 0.045;
			this._offsetY = this._defoffsetY+Math.cos(this.movedur)*40;
			this.rotDir += 0.045

			this._mainSprite.rotation = Math.sin(this.rotDir)/2;
		}
		
	}
	
	
	
	
	
	playDodgeAnimation = function() {
		
		if(typeof this.dodgedur === 'undefined' && $dataEnemies[this._enemy._enemyId].meta.dodge) {
			this.dodgedur = eval($dataEnemies[this._enemy._enemyId].meta.dodge)[0];
		}		
		
		if(typeof this._enemy.dodgeSwitch === 'undefined') {
			this._enemy.dodgeSwitch = 0;
			this._enemy.dodge = false;
		}	
		
		if ($dataEnemies[this._enemy._enemyId].meta.dodge && this._enemy.dodgeSwitch) {
			let dodgeData = eval($dataEnemies[this._enemy._enemyId].meta.dodge)
			this._mainSprite.anchor.x = this._mainSprite.anchor.x+Math.cos(this.dodgedur)*0.1;
			this.dodgedur += dodgeData[2];
			
			if (this.dodgedur >= dodgeData[1]) {
				this.dodgedur = dodgeData[0];
				this._enemy.dodgeSwitch = 0;
			}
			
		}
		
	}
	
	
	
	
	
	
	playLevitateAnimation = function() {
		
		if(typeof this.movedur === 'undefined') {
			this.movedur = 0;
		}	
		
		if ($dataEnemies[this._enemy._enemyId].meta.levitate) {
			let levitateData = eval($dataEnemies[this._enemy._enemyId].meta.levitate)
			this.movedur += levitateData[0];
			this._offsetY = this._offsetY+Math.cos(this.movedur)*levitateData[1];
		}
		
	}
	
	
	
	
	
	playTranscendance = function() {
		
		if(typeof this.movedir === 'undefined') {
			this.movedir = Math.random() * 360;
		}	
		
		if ($dataEnemies[this._enemy._enemyId].meta.transcendance) {
			let transcendanceData = eval($dataEnemies[this._enemy._enemyId].meta.transcendance)
			let power = transcendanceData[0];
			let duration = transcendanceData[1];
			let targetX = Math.cos(this.movedir * Math.PI/180)*power;
			let targetY = Math.sin(this.movedir * Math.PI/180)*power;
			let distanceToZero = Feather_Core.getDistanceBetweenPoints(this._offsetX,this._offsetY,0,0);
			this.movedir += (Math.random() * 360 -180) / power * distanceToZero;
			let dir = Feather_Core.getDirectionToPosition(this._offsetX,this._offsetY,targetX,targetY);
			this._offsetX += Math.cos(dir * Math.PI/180)*power/(distanceToZero+1)/duration;
			this._offsetY += Math.sin(dir * Math.PI/180)*power/(distanceToZero+1)/duration;
		}
		
	}
	
	
	
	
	createDog = function() {
		
		if ($dataEnemies[$gameTroop._enemies[0]._enemyId].meta.dog) {
			const enemies = $gameTroop.members();
			const sprites = [];
			for (const enemy of enemies) {
				sprites.push(new Sprite_Enemy(enemy));
			}
			sprites.sort(this.compareEnemySprite.bind(this));
			for (const sprite of sprites) {
				this._battleField.addChild(sprite);
			}
			this._enemySprites = sprites;
			
			return 0;
		}
		
		return  ___FeatherEA___Spriteset_Battle_createEnemies.call(this);
	}
	
	
	___FeatherEA___Game_Action_itemHit = Game_Action.prototype.itemHit
	Game_Action.prototype.itemHit = function(target) {
		if (target.dodge) { return -1; }
		return ___FeatherEA___Game_Action_itemHit.call(this,target);
	};
	
	
	
	___FeatherEA___Window_BattleLog_showAnimation = Window_BattleLog.prototype.showAnimation;
	Window_BattleLog.prototype.showAnimation = function(subject, targets, animationId) {
		___FeatherEA___Window_BattleLog_showAnimation.call(this, subject, targets, animationId);
		
		targets.forEach(item => {
			if ($dataEnemies[item._enemyId]) {
				$dataEnemies[item._enemyId].meta.dodge && (item.dodge = false)

				if (!item.dodgeCancelled) {
							
					$dataEnemies[item._enemyId].meta.dodge && (item.dodgeSwitch = 1);
					$dataEnemies[item._enemyId].meta.dodge && (item.dodge = true);

				}	
			}
			
		});
	};
	
	
	___FeatherEA___Spriteset_Battle_createEnemies = Spriteset_Battle.prototype.createEnemies
	Spriteset_Battle.prototype.createEnemies = function() {
		
		return createDog.call(this);
		
	};
	
	___FeatherEA___Sprite_Enemy_updateFrame = Sprite_Enemy.prototype.updateFrame;
	Sprite_Enemy.prototype.updateFrame = function() {
		
		playLevitateAnimation.call(this);
		playDOGAnimation.call(this);
		playTranscendance.call(this);
		playDodgeAnimation.call(this);

			
		return ___FeatherEA___Sprite_Enemy_updateFrame.call(this);
	};

})();
