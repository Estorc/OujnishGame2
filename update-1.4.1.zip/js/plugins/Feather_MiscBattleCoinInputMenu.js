//=============================================================================
// RPG Maker MZ - MiscBattleCoinInputMenu
//=============================================================================

/*:
 * @target MZ
 * @plugindesc Misc Battle Coin Input Menu system plugin.
 * @author Feather
 *
 * @help 
 * Misc Battle Coin Input Menu system plugin.
 *
 */
 

(() => {
    const pluginName = "MiscBattleCoinInputMenu";
	$AttackCostCoin = 0;


	___FeatherMBCIM___Window_NumberInput_update = Window_NumberInput.prototype.update
	Window_NumberInput.prototype.update = function() {
		if ($AttackCostCoin > 0) {
		Window_Selectable.prototype.update.call(this);
		this.processDigitChange();
		} else {
		___FeatherMBCIM___Window_NumberInput_update.call(this);
		}
	};


	___FeatherMBCIM___Window_NumberInput_processKeyboardDigitChange = Window_NumberInput.prototype.processKeyboardDigitChange
	Window_NumberInput.prototype.processKeyboardDigitChange = function() {
		if ($AttackCostCoin == 0) {
			
			___FeatherMBCIM___Window_NumberInput_processKeyboardDigitChange.call(this)
		}
	}

	___FeatherMBCIM___Window_NumberInput_start = Window_NumberInput.prototype.start
	Window_NumberInput.prototype.start = function() {
		if ($AttackCostCoin > 0) {
		this.itemX += 48;
		this._maxDigits = $gameMessage.numInputMaxDigits();
		this._number = $gameVariables.value($gameMessage.numInputVariableId());
		this._number = this._number.clamp(0, Math.pow(10, this._maxDigits) - 1);
		this.updatePlacement();
		this.y -= 48;
		this.placeButtons();
		this.createContents();
		this.resetTextColor();
		this.refresh();
		this.open();
		this.activate();
		this.select(0);
		} else {
		___FeatherMBCIM___Window_NumberInput_start.call(this);
		}
	};


	___FeatherMBCIM___Window_NumberInput_select = Window_NumberInput.prototype.select
	Window_Selectable.prototype.select = function(index) {
		if ($AttackCostCoin > 0 && index == (this._maxDigits-1)) {
			
		} else {
			___FeatherMBCIM___Window_NumberInput_select.call(this,index)
		}
	};


	___FeatherMBCIM___Window_NumberInput_drawAllItems = Window_NumberInput.prototype.drawAllItems
	Window_NumberInput.prototype.drawAllItems = function() {
		if ($AttackCostCoin > 0) {
			const topIndex = this.topIndex();
			for (let i = 0; i < this.maxVisibleItems(); i++) {
				const index = topIndex + i;
				if (index < this.maxItems()) {
					this.drawItemBackground(index);
					this.drawItem(index);
				}
			}
			if ($AttackCostCoin == 100000) {
				this.drawText((((this._number+$gameVariables.value(119))/$AttackCostCoin)*100+100).toString() + " %", 0, 0, this.width-110, "right");
				this.drawTextEx("\x1b" + "I[97]", this.width-110, 0, 80);
			} else {
				this.drawText((((this._number)/$AttackCostCoin)*1000).toString() + " %", 0, 0, this.width-110, "right");
				this.drawTextEx("\x1b" + "I[97]", this.width-110, 0, 80);
			}
		} else {
			___FeatherMBCIM___Window_NumberInput_drawAllItems.call(this);
		}
	};

	___FeatherMBCIM___Window_NumberInput_itemRect = Window_NumberInput.prototype.itemRect
	Window_NumberInput.prototype.itemRect = function(index) {
		if ($AttackCostCoin > 0) {
		const rect = Window_Selectable.prototype.itemRect.call(this, index);
		rect.y += 48;
		const innerMargin = this.innerWidth - this.maxCols() * this.itemWidth();
		rect.x += innerMargin / 2;
		return rect;
		} else {
		return ___FeatherMBCIM___Window_NumberInput_itemRect.call(this,index);
		}
	};

	___FeatherMBCIM___Window_NumberInput_buttonY = Window_NumberInput.prototype.buttonY
	Window_NumberInput.prototype.buttonY = function() {
		if ($AttackCostCoin > 0) {
		return this.itemHeight() + this.buttonSpacing()+ 48;
		} else {
		___FeatherMBCIM___Window_NumberInput_buttonY.call(this);
		}
	};

	___FeatherMBCIM___Window_NumberInput_changeDigit = Window_NumberInput.prototype.changeDigit
	Window_NumberInput.prototype.changeDigit = function(up) {
		if ($AttackCostCoin > 0) {
			const index = this.index();
			this._number += up ? Math.pow(10,this._maxDigits - 1 - index) : -Math.pow(10,this._maxDigits - 1 - index);
			this._number = (this._number < 0) ? 0 : this._number;
			if ($AttackCostCoin == 100000) {
				this._number = (this._number > $AttackCostCoin - $gameVariables.value(119)) ? $AttackCostCoin : this._number;
			} else {
				this._number = (this._number > $AttackCostCoin) ? $AttackCostCoin : this._number;
			}
			this.playCursorSound();
		
			$gameVariables.setValue($gameMessage.numInputVariableId(), this._number);
			if (this._number > $gameParty.gold() && $gameParty.gold() < $AttackCostCoin-(($AttackCostCoin == 100000) ? $gameVariables.value(119) : 0)) {
				
				this._number = up ? Math.floor($gameParty.gold()) : 0
				
			} else if (this._number > $AttackCostCoin-(($AttackCostCoin == 100000) ? $gameVariables.value(119) : 0)) {
			
				this._number = up ? $AttackCostCoin-(($AttackCostCoin == 100000) ? $gameVariables.value(119) : 0) : 0
			
			}
			
			this.refresh();
		
		} else {

		___FeatherMBCIM___Window_NumberInput_changeDigit.call(this,up)

		}
	};

	
})();
