//=============================================================================
// RPG Maker MZ - MiscGenos
//=============================================================================

/*:
 * @target MZ
 * @plugindesc Misc Genos system plugin.
 * @author Feather
 *
 * @help 
 * Misc Genos system plugin.
 *
 */
 

(() => {
    const pluginName = "MiscGenos";
	
	___FeatherMG___Window_BattleLog_showAnimation = Window_BattleLog.prototype.showAnimation;
	Window_BattleLog.prototype.showAnimation = function(subject, targets, animationId) {
		___FeatherMG___Window_BattleLog_showAnimation.call(this, subject, targets, animationId);
		
		if (targets.some(item => $dataEnemies[item._enemyId] && $dataEnemies[item._enemyId].meta.BHScene && $dataEnemies[item._enemyId].meta.dodge)) {
		targets.forEach(function(target) {
			if (typeof target !== 'undefined' && typeof target._enemyId !== 'undefined' && $dataEnemies[target._enemyId].meta.dodge && !target.dodgeCancelled) {
					
					
					let BHscene = eval($dataEnemies[target._enemyId].meta.BHScene);
					let scene = BHscenes[BHscene[0]];
					!$gameBulletHell.scenes.some(item => item.name == scene.name && item.id == scene.id) && ($gameBulletHell.scenes.push(new BulletHellScene(scene)));
					scene = $gameBulletHell.scenes.find(item => item.name == scene.name && item.id == scene.id);
					
					if (scene.ppg_currentSubject != subject) {
						if (typeof scene.ppg_attackPaternWillChange === 'undefined') scene.ppg_attackPaternWillChange = 0;
						scene.ppg_attackPaternWillChange += 0.25;
						scene.ppg_attackPaternWillChange = Math.min(scene.ppg_attackPaternWillChange,1);
						scene.ppg_currentSubject = subject;
					}

			}	
		});
		}
		
	};
	
	


	
	___FeatherMG___Sprite_Enemy_updateFrame = Sprite_Enemy.prototype.updateFrame;
	Sprite_Enemy.prototype.updateFrame = function() {
		
		if($dataEnemies[this._enemy._enemyId].meta.BHScene && $gameBulletHell.ppg_action == 1) {
			
			this._offsetY = -2000;
			
		} else if ($dataEnemies[this._enemy._enemyId].meta.BHScene && this._offsetY == -2000) {
			
			this._offsetY = 0;
			
		}

		return ___FeatherMG___Sprite_Enemy_updateFrame.call(this);
	};

})();
