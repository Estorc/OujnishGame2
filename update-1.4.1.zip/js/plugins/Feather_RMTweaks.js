//=============================================================================
// RPG Maker MZ - RMTweaks
//=============================================================================

/*:
 * @target MZ
 * @plugindesc RMTweaks system plugin.
 * @author Feather
 *
 * @help 
 * RMTweaks system plugin.
 *
 */
 

(() => {
    const pluginName = "RMTweaks";
	
	___FeatherRMT___DataManager_extractSaveContents = DataManager.extractSaveContents;
	DataManager.extractSaveContents = function(contents) {
		___FeatherRMT___DataManager_extractSaveContents.call(this,contents);
		$gameVariables._Community_Lighting_PlayerColor = new VRGBA("#000000");
	};
	
	___FeatherRMT___Game_Actor_refresh = Game_Actor.prototype.refresh;
	Game_Actor.prototype.refresh = function() {
		if (!this._blockRefresh) ___FeatherRMT___Game_Actor_refresh.call(this);
	};
	
	___FeatherRMT___Game_Actor_turnEndOnMap = Game_Actor.prototype.turnEndOnMap;
	Game_Actor.prototype.turnEndOnMap = function() {
		if ((this._hp !== this.mhp && this.hrg) || (this._mp !== this.mmp && this.mrg)) {
			this._blockRefresh = true;
			___FeatherRMT___Game_Actor_turnEndOnMap.call(this);
			this._blockRefresh = false;
			this.refresh();
		}
	};

	/*
	Game_Player.prototype[_0x5f1364(0x545)] = function(goalX, goalY) {
		
		let dest = (Math.atan2(goalY-this.y,goalX-this.x)/Math.PI*180+179)/45<<0;
		switch (dest) {
			case 0:
				return 7
			case 1:
				return 8
			case 2:
				return 9
			case 3:
				return 6
			case 4:
				return 3
			case 5:
				return 2
			case 6:
				return 1
			case 7:
				return 4
		}
		return 0;
	}
	
	Game_Player.prototype[_0x5f1364(0x547)] = function(goalX, goalY) {
		
		let dest = (Math.atan2(goalY-this.y,goalX-this.x)/Math.PI*180+179)/45<<0;
		switch (dest) {
			case 0:
				return 7
			case 1:
				return 8
			case 2:
				return 9
			case 3:
				return 6
			case 4:
				return 3
			case 5:
				return 2
			case 6:
				return 1
			case 7:
				return 4
		}
		return 0;
	}
	*/
	
})();
