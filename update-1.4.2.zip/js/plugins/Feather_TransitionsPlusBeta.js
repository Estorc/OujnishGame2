//=============================================================================
// RPG Maker MZ - TransitionsPlus
//=============================================================================

/*:
 * @target MZ
 * @plugindesc Transitions Plus system plugin.
 * @author Feather
 *
 * @help 
 * Transitions Plus system plugin.
 *
 */
 

(() => {
    const pluginName = "Feather_TransitionsPlus";
	
	Scene_Map.prototype.updateFade = function() {
		let diffX = $gamePlayer.screenX()-this.fadePlayerX;
		let diffY = $gamePlayer.screenY()-this.fadePlayerY;
		if (this._fadeDuration > 0) {
			const d = this._fadeDuration;
			if (this._fadeSign > 0) {
				this._fadeOpacity -= this._fadeOpacity / d;
				if (d > this.fadeSpeed()/2) this._spriteset._yShift+=(-this._spriteset._yShift) / (d-this.fadeSpeed()/2);
				if (d > this.fadeSpeed()/2) this._spriteset._xShift+=(-this._spriteset._xShift) / (d-this.fadeSpeed()/2);
			} else {
				this._fadeOpacity += (255 - this._fadeOpacity) / d;
				if (d > this.fadeSpeed()) this._spriteset._yShift+=($dataSystem.advanced.screenHeight-this._spriteset._yShift) / (d-this.fadeSpeed()/2);
				if (d > this.fadeSpeed()) this._spriteset._xShift+=($dataSystem.advanced.screenHeight-this._spriteset._xShift) / (d-this.fadeSpeed()/2);
			}
			this.lastSceneFadeSprite.y = this._spriteset._yShift+diffY;
			this.lastSceneFadeSprite.x = this._spriteset._xShift+diffX;
			if (d <= this.fadeSpeed()/2) this.lastSceneFadeSprite.opacity -= this.lastSceneFadeSprite.opacity / d;
			this._fadeDuration--;
		}
	};
	
	___FeatherTP___Spriteset_Base_initialize = Spriteset_Base.prototype.initialize;
	Spriteset_Base.prototype.initialize = function() {
		___FeatherTP___Spriteset_Base_initialize.call(this);
		this._yShift = 0;
		this._xShift = 0;
	};	
	
	

	

	
	Spriteset_Map.prototype.updatePosition = function() {
		Spriteset_Base.prototype.updatePosition.call(this);
		this.y += this._yShift;
		this.x += this._xShift;
	};
	
	Scene_Map.prototype.isFading = function() {
		return this._fadeDuration > 0 && this._fadeSign === 1;
	};
	
	Scene_Map.prototype.featherStartFadeIn = function(duration, white) {
		let diffX = $gamePlayer.screenX()-this.fadePlayerX;
		let diffY = $gamePlayer.screenY()-this.fadePlayerY;
		this._fadeSign = 1;
		this._fadeDuration = duration || 30;
		this._fadeWhite = white;
		this._fadeOpacity = 0;
		this._spriteset._yShift = -diffY;
		this._spriteset._xShift = -diffX;
		this.lastSceneFadeSprite = new Sprite();
		this.lastSceneFadeSprite.bitmap = this.fadeBitmap;
		this.addChild(this.lastSceneFadeSprite);
		this.updateColorFilter();
	};

	Scene_Map.prototype.featherStartFadeOut = function(duration, white) {
		this._windowLayer.visible = false;
		SceneManager._nextScene.fadeBitmap = SceneManager.snap();
		this._windowLayer.visible = true;
		SceneManager._nextScene.fadePlayerX = $gamePlayer.screenX();
		SceneManager._nextScene.fadePlayerY = $gamePlayer.screenY();
		this._fadeSign = -1;
		this._fadeDuration = duration || 30;
		this._fadeWhite = white;
		this._fadeOpacity = 0;
		this.updateColorFilter();
	};
	
	Scene_Map.prototype.fadeInForTransfer = function() {
		const fadeType = $gamePlayer.fadeType();
		switch (fadeType) {
			case 0:
			case 1:
				this.featherStartFadeIn(this.fadeSpeed(), fadeType === 1);
				break;
		}
	};

	Scene_Map.prototype.fadeOutForTransfer = function() {
		const fadeType = $gamePlayer.fadeType();
		switch (fadeType) {
			case 0:
			case 1:
				this.featherStartFadeOut(this.fadeSpeed(), fadeType === 1);
				break;
		}
	};
	
	
})();
