//=============================================================================
// RPG Maker MZ - BattleVideo
//=============================================================================

/*:
 * @target MZ
 * @plugindesc BattleVideo system plugin.
 * @author Feather
 *
 * @help 
 * BattleVideo system plugin.
 *
 */
 

(() => {
    const pluginName = "BattleVideo";
	$vidSprite = null;
	$battlebgm = null;
	$evbattlebgm = [];
	let vid;
	let w = "auto"; 
	let h = "auto"; 
	let x = 0; 
	let y = 0;
	let loopStart = 0;
	let loopEnd = "end";
	let opacity = 1;
	let tint = 0xffffff;
	let loop = "yes";
	let muted = "no";
	let playbackRate = 1.0;
	let listeners = {};
	
	$replayMusicAfterEvent = function(name) {
		
		$evbattlebgm = $evbattlebgm.filter(bgm => bgm.name != name);
		if ($currentMusic == name) {
			if ($evbattlebgm.length != 0) {
				$currentMusic = $evbattlebgm[$evbattlebgm.length-1].name
				AudioManager.playBgm($evbattlebgm[$evbattlebgm.length-1].song);
			} else {
				AudioManager.replayBgm($battlebgm);
				$battlebgm = null;
			}
		}
		
	}
 
 
	___FeatherBV___Scene_Gameover_terminate = Scene_Gameover.prototype.terminate;
	Scene_Gameover.prototype.terminate = function() {
		___FeatherBV___Scene_Gameover_terminate.call(this);
		
		$destroyVideoOnBattle();
		
	};
	
	
	$loadVideoOnBattle = function(videoname) {
		
		var ext = Game_Interpreter.prototype.videoFileExt();
		var vidFilePath = 'movies/' + videoname + ext;
		var vidTexture = PIXI.Texture.fromVideo(vidFilePath);
		vid = vidTexture.baseTexture.source;
		$vidSprite = new PIXI.Sprite(vidTexture);
		vid.volume = 1*(WebAudio._masterVolume)*(AudioManager._bgmVolume/100);
		$vidSprite.blendMode = PIXI.BLEND_MODES["NORMAL".toUpperCase()] || PIXI.BLEND_MODES.NORMAL;


		window.vid = vid;
		$vidSprite.width = w === 'auto' ? Graphics.width : (parseInt(w) || Graphics.width);
		$vidSprite.height = h === 'auto' ? Graphics.height : (parseInt(h) || Graphics.height);
		$vidSprite.x = parseInt(x) || 0;
		$vidSprite.y = parseInt(y) || 0;
		$vidSprite.alpha = parseFloat(opacity) || 1.0;
		$vidSprite.tint = parseInt(tint) || 0xffffff;
		vid.loop = true;vid.muted = muted === 'yes' ? true : false;
		vid.playbackRate = parseFloat(playbackRate) || 1.0;
		$vidSprite.update = function() {vidTexture.update();}


		vid.currentTime = 0;
		vid.play();
		$vidSprite.name = "vidsprite"
		$vidSprite.vidname = videoname;
		
	}
	
	
	$destroyVideoOnBattle = function() {
		
		if (typeof vid !== 'undefined' && vid != null) {
			vid.pause();
			vid.remove();
			vid = null;
			$vidSprite = new PIXI.Sprite();
			$vidSprite.name = "vidsprite"
			$vidSprite.vidname = "undefined";
		}
		
	}
	
	
	___FeatherBV___Spriteset_Battle_terminate = Spriteset_Battle.prototype.terminate;
    Spriteset_Battle.prototype.terminate = function() {
        ___FeatherBV___Spriteset_Battle_terminate.call(this);
		$destroyVideoOnBattle();
    };
	
	
	___FeatherBV___Spriteset_Battle_createBattleback = Spriteset_Battle.prototype.createBattleback;
	Spriteset_Battle.prototype.createBattleback = function() {
		___FeatherBV___Spriteset_Battle_createBattleback.call(this);
		if ($vidSprite === null || $vidSprite.vidname === "undefined") {
			$vidSprite = new PIXI.Sprite();
			$vidSprite.name = "vidsprite"
			$vidSprite.vidname = "undefined";
		} else {
			vid.pause();
			vid.remove();
			vid = null;
			$loadVideoOnBattle($vidSprite.vidname);
		}
		this._backvidSprite = $vidSprite;
		this._baseSprite.addChild(this._backvidSprite);
		
	};
	
	
		
	___FeatherBV___Spriteset_Battle_updateBattleback = Spriteset_Battle.prototype.updateBattleback;
	Spriteset_Battle.prototype.updateBattleback = function() {
		___FeatherBV___Spriteset_Battle_updateBattleback.call(this);
			for (var i = 0; i < this._baseSprite.children.length; i++)
			{
				if (this._baseSprite.children[i].name === "vidsprite" && this._backvidSprite != $vidSprite)
				{
					this._backvidSprite = $vidSprite;
					this._baseSprite.removeChildAt(i);
					this._baseSprite.addChildAt(this._backvidSprite, i);
				}
			}
	};
	

})();
