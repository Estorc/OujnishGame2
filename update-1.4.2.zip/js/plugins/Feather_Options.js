//=============================================================================
// RPG Maker MZ - Feather Options
//=============================================================================

/*:
 * @target MZ
 * @plugindesc A plugin to reworks options.
 * @author Feather
 *
 * @help 
 * A plugin to reworks options.
 *
 */
 

(() => {
    const pluginName = "FeatherOptions";
	
	
	//-----------------------------------------------------------------------------
	// Scene_Feather_Options
	//
	// The scene class of the Feather's options screen.
	
	
	Scene_Feather_Options = function() {
		this.initialize(...arguments);
	};
	

	Scene_Feather_Options.prototype = Object.create(Scene_MenuBase.prototype);
	Scene_Feather_Options.prototype.constructor = Scene_Feather_Options;

	Scene_Feather_Options.prototype.initialize = function() {
		Scene_MenuBase.prototype.initialize.call(this);
	};
	
	
	Scene_Feather_Options.prototype.prepare = function(commands) {
		this._commands = commands;
	};


	Scene_Feather_Options.prototype.create = function() {
		Scene_MenuBase.prototype.create.call(this);
		this.createOptionsWindow();
	};
	

	Scene_Feather_Options.prototype.terminate = function() {
		Scene_MenuBase.prototype.terminate.call(this);
		ConfigManager.save();
	};
	

	Scene_Feather_Options.prototype.createOptionsWindow = function() {
		const rect = this.optionsWindowRect();
		this._optionsWindow = new Window_Feather_Options(rect,this._commands);
		this._optionsWindow.setHandler("cancel", this.popScene.bind(this));
		this._optionsWindow._scene = this;
		this.addWindow(this._optionsWindow);
	};
	

	Scene_Feather_Options.prototype.optionsWindowRect = function() {
		const n = Math.min(this.maxCommands(), this.maxVisibleCommands());
		const ww = 400;
		const wh = this.calcWindowHeight(n, true);
		const wx = (Graphics.boxWidth - ww) / 2;
		const wy = (Graphics.boxHeight - wh) / 2;
		return new Rectangle(wx, wy, ww, wh);
	};


	Scene_Feather_Options.prototype.maxCommands = function() {
		// Increase this value when adding option items.
		return 7;
	};
	

	Scene_Feather_Options.prototype.maxVisibleCommands = function() {
		return 12;
	};
	
	
	//-----------------------------------------------------------------------------
	// Window_Feather_Options
	//
	// The window for changing various settings on the options screen.


	function Window_Feather_Options() {
		this.initialize(...arguments);
	};

	Window_Feather_Options.prototype = Object.create(Window_Command.prototype);
	Window_Feather_Options.prototype.constructor = Window_Feather_Options;
	

	Window_Feather_Options.prototype.initialize = function(rect,commands) {
		this._commands = commands;
		Window_Command.prototype.initialize.call(this, rect);
	};
	
	
	Window_Feather_Options.prototype.update = function() {
		if (!this._setInputWindow) {
			this.processCursorMove();
			this.processHandling();
			this.processTouch();
			Window_Scrollable.prototype.update.call(this);
		}
	};
	

	Window_Feather_Options.prototype.makeCommandList = function() {
		this.addGeneralOptions();
	};


	Window_Feather_Options.prototype.addGeneralOptions = function() {
		this.selectedOption = [];
		for (const [text, symbol] of this._commands) {
			this.addCommand(text, symbol);
			this.selectedOption.push(2);
		}
		this.selectedOption[0] = 0;
	};
	
	
	Window_Feather_Options.prototype.processCursorMove = function() {
		const lastIndex = this.index();
		const lastSymbol = this.commandSymbol(lastIndex);
		Window_Selectable.prototype.processCursorMove.call(this);
		const index = this.index();
		const symbol = this.commandSymbol(index);
		if (index != lastIndex) {
			this.selectedOption[lastIndex] = 2;
			this.redrawItem(this.findSymbol(lastSymbol));
			this.selectedOption[index] = 0;
			this.redrawItem(this.findSymbol(symbol));
		}
	};
	
	
	Window_Feather_Options.prototype.onTouchSelect = function(trigger) {
		const lastIndex = this.index();
		const lastSymbol = this.commandSymbol(lastIndex);
		Window_Selectable.prototype.onTouchSelect.call(this);
		const index = this.index();
		const symbol = this.commandSymbol(index);
		if (index != lastIndex) {
			this.selectedOption[lastIndex] = 2;
			this.redrawItem(this.findSymbol(lastSymbol));
			this.selectedOption[index] = 0;
			this.redrawItem(this.findSymbol(symbol));
		}
	};


	Window_Feather_Options.prototype.drawItem = function(index) {
		const title = this.commandName(index);
		const status = this.keyStatusText(index);
		const rect = this.itemLineRect(index);
		const statusWidth = this.statusWidth();
		const titleWidth = rect.width - statusWidth;
		this.resetTextColor();
		this.changePaintOpacity(1);
		this.drawText(title, rect.x, rect.y, titleWidth, "left");
		this.selectedOption[index] != 2 && this.changePaintOpacity(!this.selectedOption[index]);
		this.drawTextEx(status[0], rect.x + titleWidth, rect.y, statusWidth);
		this.changePaintOpacity(!!this.selectedOption[index]);
		this.drawTextEx(status[1], rect.x+48 + titleWidth, rect.y, statusWidth-48);
	};
	

	Window_Feather_Options.prototype.statusWidth = function() {
		return 120;
	};
	

	Window_Feather_Options.prototype.keyStatusText = function(index) {
		const symbol = this.commandSymbol(index);
		const value = this.getConfigValue(symbol);
		return [this.statusText(value,0),this.statusText(value,1)];
	};


	Window_Feather_Options.prototype.statusText = function(value,index) {
		
		let text = [];
		text[index] = Feather_Core.convertKeyCodeToIcon(value[index]);
		if (text[index]) {
			text[index] = '\\I['+text[index].toString()+']';
		} else {
			text[index] = Feather_Core.convertKeyCodeToString(value[index]);
		}
		
		return text[index];
	};


	Window_Feather_Options.prototype.processOk = function() {
		const index = this.index();
		const symbol = this.commandSymbol(index);
		const rect = this.setInputWindowRect();
		this._setInputWindow = new Window_Feather_SetInput(rect);
		this._setInputWindow._optionsWindow = this;
		this._setInputWindow.keyIndex = this.selectedOption[index];
		this._setInputWindow.keySymbol = symbol;
		this._setInputWindow.keyValue = this.getConfigValue(symbol);
		Input._currentSetState = null;
		this._scene.addWindow(this._setInputWindow);
	};
	
	
	Window_Feather_Options.prototype.setInputWindowRect = function() {
		const ww = 800;
		const wh = 100;
		const wx = (Graphics.boxWidth - ww) / 2;
		const wy = (Graphics.boxHeight - wh) / 2;
		return new Rectangle(wx, wy, ww, wh);
	};
	

	Window_Feather_Options.prototype.cursorRight = function() {
		const index = this.index();
		const symbol = this.commandSymbol(index);
		this.playCursorSound();
		this.selectedOption[index] = 1;
		this.redrawItem(this.findSymbol(symbol));
	};
	

	Window_Feather_Options.prototype.cursorLeft = function() {
		const index = this.index();
		const symbol = this.commandSymbol(index);
		this.playCursorSound();
		this.selectedOption[index] = 0;
		this.redrawItem(this.findSymbol(symbol));
	};
	

	Window_Feather_Options.prototype.changeValue = function(symbol, value) {
		const lastValue = this.getConfigValue(symbol);
		if (lastValue !== value) {
			this.setConfigValue(symbol, value);
			this.redrawItem(this.findSymbol(symbol));
			this.playCursorSound();
		}
	};
	

	Window_Feather_Options.prototype.getConfigValue = function(symbol) {
		return ConfigManager[symbol];
	};
	

	Window_Feather_Options.prototype.setConfigValue = function(symbol, value) {
		ConfigManager[symbol] = value;
		BulletHellInput.makeKeyMapper();
	};
	
	
	//-----------------------------------------------------------------------------
	// Window_Feather_Options
	//
	// The window for changing various settings on the options screen.


	function Window_Feather_SetInput() {
		this.initialize(...arguments);
	};


	Window_Feather_SetInput.prototype = Object.create(Window_Selectable.prototype);
	Window_Feather_SetInput.prototype.constructor = Window_Feather_SetInput;
	
	
	Window_Feather_SetInput.prototype.initialize = function(rect) {
		Window_Selectable.prototype.initialize.call(this, rect);
		this.refresh();
	};
	
	
	Window_Feather_SetInput.prototype.colSpacing = function() {
		return 0;
	};
	

	Window_Feather_SetInput.prototype.refresh = function() {
		const rect = this.innerRect;
		const text = 'Appuyez sur la touche que vous souhaitez affecter.'
		const textWidth = this.textWidth(text);
		const x = rect.x+rect.width/2 - textWidth/2;
		const y = rect.height/2-16;
		const width = rect.width;
		this.contents.clear();
		this.resetTextColor();
		this.changePaintOpacity(1);
		this.drawTextEx(text, x, y, textWidth);
	};
	

	Window_Feather_SetInput.prototype.open = function() {
		this.refresh();
		Window_Selectable.prototype.open.call(this);
	};
	
	
	Window_Feather_SetInput.prototype.update = function() {
		this.processCursorMove();
		Window_Base.prototype.update.call(this);
	};
		

	Window_Feather_SetInput.prototype.processCursorMove = function() {
		if (Input.isInputSet()) {
			this.playCursorSound();
			this.keyValue[this.keyIndex] = Input.isInputSet();
			this._optionsWindow.setConfigValue(this.keySymbol,this.keyValue);
			this._optionsWindow.redrawItem(this._optionsWindow.findSymbol(this.keySymbol));
			this.destroy();
			this._optionsWindow._setInputWindow = null;
		}
	};
	
	
	//-----------------------------------------------------------------------------
	// Classes Rewrite
	//
	
	
	___FeatherO___Input__onKeyDown = Input._onKeyDown;
	Input._onKeyDown = function(event) {
		___FeatherO___Input__onKeyDown.call(this, event);
		this._currentSetState = event.keyCode;
	};
	
	
	___FeatherO___Input_clear = Input.clear;
	Input.clear = function() {
		___FeatherO___Input_clear.call(this);
		this._currentSetState = null;
	};
	
	
	Input.isInputSet = function() {
		return this._currentSetState;
	};
		
	
})();
