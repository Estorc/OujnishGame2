//=============================================================================
// RPG Maker MZ - ClassesReworks
//=============================================================================

/*:
 * @target MZ
 * @plugindesc Classes Reworks system plugin.
 * @author Feather
 *
 * @help 
 * Classes Reworks system plugin.
 *
 */
 

(() => {
    const pluginName = "Classes Reworks";

	Game_BattlerBase.RELATION_TRAIT = 500;
	
	___FeatherCR___Game_Actor_changeExp = Game_Actor.prototype.changeExp;
	Game_Actor.prototype.changeExp = function(exp, show) {
		let lastLevel = this._level;
		if (!this._levelsGained) this._levelsGained = 0;
		if (!this._choosedBranches) this._choosedBranches = [];
		if (!this._classSkills) this._classSkills = [];
		___FeatherCR___Game_Actor_changeExp.call(this,exp,show);
		if (show) {
			this._levelsGained = this._level-lastLevel;
			this._level-=this._levelsGained;
			this._expGained = exp;
		} else {
			this._levelsGained = 0;
			this.featherLearnNewBranches();
			this.featherLearnNewSkills();
			this._newSkills = [];
		}
	};
	
	Game_Actor.prototype.levelUp = function() {
		this._level++;
	};
	
	Game_Actor.prototype.levelDown = function() {
		this._level--;
	};
	
	Game_Actor.prototype.displayLevelUp = function(newSkills) {
		//
	};
	
	___FeatherCR___Game_Actor_allTraits = Game_Actor.prototype.allTraits;
	Game_Actor.prototype.allTraits = function() {
		return ___FeatherCR___Game_Actor_allTraits.call(this).concat((!!this._choosedBranches && this._choosedBranches.reduce((a,b) => b.traits.concat(a),[])) || []);
	};
	
	___FeatherCR___Game_BattlerBase_paramRate = Game_BattlerBase.prototype.paramRate;
	Game_BattlerBase.prototype.paramRate = function(paramId) {
		return ___FeatherCR___Game_BattlerBase_paramRate.call(this,paramId) * this.calcRelationTraits(paramId);
	};
	
	Game_BattlerBase.prototype.calcRelationTraits = function(id) {
		let traits = this.traitsWithId(Game_BattlerBase.TRAIT_PARAM+500, id);
			
		if (id < 2) return 1;
			
		return ((traits.some(item => item.relId == 0)) ? ((1-this._hp/this.param(0))*traits.filter(item => item.relId == 0).reduce((r, trait) => r * trait.value, 1)+1) : 1) *
				((traits.some(item => item.relId == 1)) ? ((1-this._mp/this.param(1))*traits.filter(item => item.relId == 1).reduce((r, trait) => r * trait.value, 1)+1) : 1);
	};
	
	___FeatherCR___Game_Actor_setup = Game_Actor.prototype.setup;
	Game_Actor.prototype.setup = function(actorId) {
		this._preChoosedBranches = [];
		this._levelsGained = 0;
		if ($dataActors[actorId].meta.ChoosedBranches) this._preChoosedBranches = $dataActors[actorId].meta.ChoosedBranches.split(",").map(a => a.trim());
		___FeatherCR___Game_Actor_setup.call(this, actorId);
		this.initBranches();
	};
	
	Game_Actor.prototype.initSkills = function() {
		this._skills = [];
		this._classSkills = [];
		for (const learning of this.featherLearnings()) {
			if (learning.level <= this._level && (!learning.meta.Branch || this._preChoosedBranches.includes(learning.meta.Branch))) {
				if (!this._skills.includes(learning.skillId) && !learning.meta.Permanent) this._classSkills.push(learning.skillId)
				this.learnSkill(learning.skillId);
			}
		}
	};
	
	
	Game_Actor.prototype.initBranches = function() {
		this._choosedBranches = [];
		const allBranches = this.currentClass().longMeta.Branch || [];
		for (const branchItem of allBranches) {
			if (this.isBellowLevel(branchItem.Level) && this._preChoosedBranches.some(a => a == branchItem.ID)) {
				let branch = Feather_Core.deepCopy(branchItem);
				this._preChoosedBranches.splice(this._preChoosedBranches.findIndex(a => a == branch.ID), 1);
				branch.traits = [];
				branch.Level = this._level;
				this._choosedBranches.push(branch);
				if (branch.Params) this.featherApplyParams(eval(branch.Params),branch);
			}
		}
	};
	


	
	
	Game_Actor.prototype.featherLearnNewBranches = function() {
		const allBranches = this.currentClass().longMeta.Branch || [];
		for (const branch of allBranches) {
			if (this.isBellowLevel(branch.Level) && this._preChoosedBranches.some(a => a == branch.ID)) {
				this._preChoosedBranches.splice(this._preChoosedBranches.findIndex(a => a == branch.ID), 1);
				branch.traits = [];
				branch.Level = this._level;
				this._choosedBranches.push(branch);
				if (branch.Params) this.featherApplyParams(eval(branch.Params),branch);
			}
		}
	};
	
	
	
	
	
	
	
	
	
	Game_Actor.prototype.featherApplyParams = function (params,branch) {
		
		for (let i = 0; i < params.length; i+=2) {
			
			const param = params[i];
			const value = params[i+1];
			
			switch (param) {
				
				case "multHp":
					branch.traits.push({
						code:Game_BattlerBase.TRAIT_PARAM,
						dataId:0,
						value:value
					})
				break;
				case "multMp":
					branch.traits.push({
						code:Game_BattlerBase.TRAIT_PARAM,
						dataId:1,
						value:value
					})
				break;
				case "multAtk":
					branch.traits.push({
						code:Game_BattlerBase.TRAIT_PARAM,
						dataId:2,
						value:value
					})
				break;
				case "multDef":
					branch.traits.push({
						code:Game_BattlerBase.TRAIT_PARAM,
						dataId:3,
						value:value
					})
				break;
				case "multMat":
					branch.traits.push({
						code:Game_BattlerBase.TRAIT_PARAM,
						dataId:4,
						value:value
					})
				break;
				case "multMdf":
					branch.traits.push({
						code:Game_BattlerBase.TRAIT_PARAM,
						dataId:5,
						value:value
					})
				break;
				case "multAgi":
					branch.traits.push({
						code:Game_BattlerBase.TRAIT_PARAM,
						dataId:6,
						value:value
					})
				break;
				case "multLuk":
					branch.traits.push({
						code:Game_BattlerBase.TRAIT_PARAM,
						dataId:7,
						value:value
					})
				break;
				case "multTarget":
					branch.traits.push({
						code:Game_BattlerBase.TRAIT_SPARAM,
						dataId:0,
						value:value
					})
				break;
				case "multPharmacology":
					branch.traits.push({
						code:Game_BattlerBase.TRAIT_SPARAM,
						dataId:3,
						value:value
					})
				break;
				
				case "multFire":
					branch.traits.push({
						code:Game_BattlerBase.TRAIT_ELEMENT_RATE,
						dataId:1,
						value:value
					})
				break;
				case "multIce":
					branch.traits.push({
						code:Game_BattlerBase.TRAIT_ELEMENT_RATE,
						dataId:2,
						value:value
					})
				break;
				case "multThunder":
					branch.traits.push({
						code:Game_BattlerBase.TRAIT_ELEMENT_RATE,
						dataId:3,
						value:value
					})
				break;
				case "multWater":
					branch.traits.push({
						code:Game_BattlerBase.TRAIT_ELEMENT_RATE,
						dataId:4,
						value:value
					})
				break;
				case "multEarth":
					branch.traits.push({
						code:Game_BattlerBase.TRAIT_ELEMENT_RATE,
						dataId:5,
						value:value
					})
				break;
				case "multWind":
					branch.traits.push({
						code:Game_BattlerBase.TRAIT_ELEMENT_RATE,
						dataId:6,
						value:value
					})
				break;
				case "multLight":
					branch.traits.push({
						code:Game_BattlerBase.TRAIT_ELEMENT_RATE,
						dataId:7,
						value:value
					})
				break;
				case "multDarkness":
					branch.traits.push({
						code:Game_BattlerBase.TRAIT_ELEMENT_RATE,
						dataId:8,
						value:value
					})
				break;
				
				case "multState":
					branch.traits.push({
						code:Game_BattlerBase.TRAIT_ATTACK_STATE,
						dataId:value[0],
						value:value[1]
					})
				break;
				
				case "increaseDodge":
					branch.traits.push({
						code:Game_BattlerBase.TRAIT_XPARAM,
						dataId:1,
						value:value
					})
				break;
				case "increaseMagicDodge":
					branch.traits.push({
						code:Game_BattlerBase.TRAIT_XPARAM,
						dataId:4,
						value:value
					})
				break;
				case "increaseMagicReflect":
					branch.traits.push({
						code:Game_BattlerBase.TRAIT_XPARAM,
						dataId:5,
						value:value
					})
				break;
				case "increaseCounter":
					branch.traits.push({
						code:Game_BattlerBase.TRAIT_XPARAM,
						dataId:6,
						value:value
					})
				break;
				
				case "partyAbility":
					branch.traits.push({
						code:Game_BattlerBase.TRAIT_PARTY_ABILITY,
						dataId:value,
						value:true
					})
				break;
				
				case "rage":
					branch.traits.push({
						code:Game_BattlerBase.TRAIT_PARAM+Game_BattlerBase.RELATION_TRAIT,
						dataId:2,
						relId:0,
						value:value
					})
				break;
				case "adrenaline":
					branch.traits.push({
						code:Game_BattlerBase.TRAIT_PARAM+Game_BattlerBase.RELATION_TRAIT,
						dataId:3,
						relId:0,
						value:value
					})
				break;
				
				case "hpRegen":
					branch.traits.push({
						code:Game_BattlerBase.TRAIT_XPARAM,
						dataId:7,
						value:value
					})
				break;
				case "mpRegen":
					branch.traits.push({
						code:Game_BattlerBase.TRAIT_XPARAM,
						dataId:8,
						value:value
					})
				break;
				case "xParam":
					branch.traits.push({
						code:Game_BattlerBase.TRAIT_XPARAM,
						dataId:value[0],
						value:value[1]
					})
				break;
				case "sParam":
					branch.traits.push({
						code:Game_BattlerBase.TRAIT_XPARAM,
						dataId:value[0],
						value:value[1]
					})
				break;
				case "allowWeapon":
					branch.traits.push({
						code:Game_BattlerBase.TRAIT_EQUIP_WTYPE,
						dataId:value,
						value:true
					})
				break;
				case "multipleAtk":
					branch.traits.push({
						code:Game_BattlerBase.TRAIT_ATTACK_TIMES,
						dataId:0,
						value:value
					})
				break;
				case "multElem":
					branch.traits.push({
						code:'multElem',
						dataId:value[0],
						value:value[1]
					})
				break;
				case "increaseElem":
					branch.traits.push({
						code:'increaseElem',
						dataId:value[0],
						value:value[1]
					})
				break;
				case "increaseMaxSummons":
					branch.traits.push({
						code:'increaseMaxSummons',
						dataId:0,
						value:value
					})
				break;
				case "ChangeClass":
					this.featherChangeClass(value);
					SceneManager._scene._branchChoosed = false;
				break;
				case "Ascension":
				
					let prob = {
						
						wizard: 0,
						magus: 0,
						swordman: 0,
						dancer: 0,
						warrior: 0,
						bowman: 0
						
					};
				
					prob.wizard    = this._equips.reduce((a,b) => (b.object() && (b.object().wtypeId == 6 || b.object().atypeId == 2)) + a,0)+1;
					prob.magus     = this._equips.reduce((a,b) => (b.object() && ((b.object().wtypeId == 6 || b.object().wtypeId == 2) || b.object().atypeId == 0)) + a,0);
					prob.swordman  = this._equips.reduce((a,b) => (b.object() && (b.object().wtypeId == 2 || b.object().atypeId == 4)) + a,0);
					prob.dancer    = this._equips.reduce((a,b) => (b.object() && (b.object().wtypeId == 13 || b.object().atypeId == 2)) + a,0);
					prob.warrior   = this._equips.reduce((a,b) => (b.object() && ((b.object().wtypeId == 1 || b.object().wtypeId == 2 || b.object().wtypeId == 3 || b.object().wtypeId == 4 || b.object().wtypeId == 5 || b.object().wtypeId == 9 || b.object().wtypeId == 10 || b.object().wtypeId == 11) || b.object().atypeId == 1)) + a,0);
					prob.bowman    = this._equips.reduce((a,b) => (b.object() && (b.object().wtypeId == 6 || b.object().atypeId == 3)) + a,0);
					
					prob.magus    += (this._paramPlus[4] > $gameParty.members()[0]._paramPlus.clone().sort((a,b) => b-a)[1]);
					prob.dancer   += (this._paramPlus[6] > $gameParty.members()[0]._paramPlus.clone().sort((a,b) => b-a)[1]);
					prob.swordman += (this._paramPlus[2] > $gameParty.members()[0]._paramPlus.clone().sort((a,b) => b-a)[1]);
					prob.warrior  += (this._paramPlus[3] > $gameParty.members()[0]._paramPlus.clone().sort((a,b) => b-a)[1]);
					prob.bowman   += (this._paramPlus[7] > $gameParty.members()[0]._paramPlus.clone().sort((a,b) => b-a)[1]);
					
					if (prob.wizard >= prob.magus && 
						prob.wizard >= prob.swordman && 
						prob.wizard >= prob.dancer && 
						prob.wizard >= prob.warrior && 
						prob.wizard >= prob.bowman)
					this.featherChangeClass(16);
					
					else if (prob.magus >= prob.wizard && 
						prob.magus >= prob.swordman && 
						prob.magus >= prob.dancer && 
						prob.magus >= prob.warrior && 
						prob.magus >= prob.bowman)
					this.featherChangeClass(21);
					
					else if (prob.swordman >= prob.magus && 
						prob.swordman >= prob.wizard && 
						prob.swordman >= prob.dancer && 
						prob.swordman >= prob.warrior && 
						prob.swordman >= prob.bowman)
					this.featherChangeClass(26);
					
					else if (prob.dancer >= prob.magus && 
						prob.dancer >= prob.wizard && 
						prob.dancer >= prob.swordman && 
						prob.dancer >= prob.warrior && 
						prob.dancer >= prob.bowman)
					this.featherChangeClass(31);
					
					else if (prob.warrior >= prob.magus && 
						prob.warrior >= prob.swordman && 
						prob.warrior >= prob.dancer && 
						prob.warrior >= prob.wizard && 
						prob.warrior >= prob.bowman)
					this.featherChangeClass(36);
					
					else if (prob.bowman >= prob.magus && 
						prob.bowman >= prob.swordman && 
						prob.bowman >= prob.dancer && 
						prob.bowman >= prob.warrior && 
						prob.bowman >= prob.wizard)
					this.featherChangeClass(41);
				break;
				
			}
			
		}
		
	};
	
	
	Game_Actor.prototype.featherLevelUp = function() {
		this._level++;
	};
	
	
	Game_Actor.prototype.featherLearnings = function() {

		if (this.actor().longMeta.Learning) {
			if (!this.actor().longMeta.Learning.meta) this.actor().longMeta.Learning.forEach(a => {a.skillId = eval(a.skillId); a.level = eval(a.level);a.meta = []})
			return this.currentClass().learnings.concat(this.actor().longMeta.Learning);
		} else return this.currentClass().learnings;
		
	}
	
	
	Game_Actor.prototype.featherLearnNewSkills = function() {
		for (const learning of this.featherLearnings()) {
			if (learning.level <= this._level) {
				if (!learning.meta.Branch || (learning.meta.Branch.trim().charAt(0) === '[' && !eval(learning.meta.Branch).some(a => !this._choosedBranches.map(item => item.ID).includes(a) )) || this._choosedBranches.some(a => a.ID == learning.meta.Branch.trim())) {
					if (!this._skills.includes(learning.skillId) && !learning.meta.Permanent) this._classSkills.push(learning.skillId)
					this.learnSkill(learning.skillId);
				}
			}
		}
	}
	
	
	Game_Actor.prototype.featherChangeClass = function(classId) {
		const lastSkills = this.skills();
		this._exp[classId] = this.currentExp();
		this._classId = classId;
		this._exp[classId] = Math.max(this.currentLevelExp(),this.currentExp());
		this.changeExp(this.currentExp(), true);
		this._skills = this._skills.filter(a => $dataSkills[a].meta.Permanent || !this._classSkills.includes(a));
		this._classSkills = [];
		this.featherLearnNewSkills();
		this._newSkills = this.findNewSkills(lastSkills);
		this.refresh();
	};
	
	Game_Actor.prototype.isInLevelRange = function(data) {
		const regExp = /([0-9]+)([-,]*)/g;
		const levelRangeA = [];
		const levelRangeB = [];
		const levelRangeC = [];
		const level = this._level;
		for (;;) {
			const match = regExp.exec(data);
			if (match) {
				if (levelRangeA.length > levelRangeB.length) {
					levelRangeB.push(eval(match[1]));
				}
				if (match[2] === "-") {
					levelRangeA.push(eval(match[1]));
				} else {
					levelRangeC.push(eval(match[1]));
				}
			} else {
				break;
			}
		}
		return levelRangeC.includes(level) || levelRangeA.some((a,b) => (a <= level && levelRangeB[b] >= level) || (a >= level && levelRangeB[b] <= level));
	};
	
	
	Game_Actor.prototype.isBellowLevel = function(data) {
		const regExp = /([0-9]+)([-,]*)/g;
		const levelRangeA = [];
		const levelRangeB = [];
		const levelRangeC = [];
		const level = this._level;
		for (;;) {
			const match = regExp.exec(data);
			if (match) {
				if (levelRangeA.length > levelRangeB.length) {
					levelRangeB.push(eval(match[1]));
				}
				if (match[2] === "-") {
					levelRangeA.push(eval(match[1]));
				} else {
					levelRangeC.push(eval(match[1]));
				}
			} else {
				break;
			}
		}
		return levelRangeA.some(a => a <= level) || levelRangeB.some(a => a <= level) || levelRangeC.some(a => a <= level);
	};
	
	
	___FeatherCR___BattleManager_updateBattleEnd = BattleManager.updateBattleEnd
	BattleManager.updateBattleEnd = function() {
		if ($gameParty.members().some(item => item._levelsGained > 0)) {
			SceneManager._scene._windowLayer.visible = false;
			SceneManager.snapForBackground();
			SceneManager._scene._windowLayer.visible = true;
			return SceneManager.goto(Scene_FeatherLevelUp);
		}
		___FeatherCR___BattleManager_updateBattleEnd.call(this);
		
	}
	
	
	___FeatherCR___Scene_Battle_stop = Scene_Battle.prototype.stop;
	Scene_Battle.prototype.stop = function() {
		if (!$gameParty.members().some(item => item._levelsGained > 0)) {
			return ___FeatherCR___Scene_Battle_stop.call(this);
		}
		Scene_Message.prototype.stop.call(this);
		this._statusWindow.close();
		this._partyCommandWindow.close();
		this._actorCommandWindow.close();
	};
	
	
	
	___FeatherCR___Scene_Map_needsFadeIn = Scene_Map.prototype.needsFadeIn;
	Scene_Map.prototype.needsFadeIn = function() {
		return ___FeatherCR___Scene_Map_needsFadeIn.call(this) || SceneManager.isPreviousScene(Scene_FeatherLevelUp);
	};
	
	
	
	
	
	
	
	___FeatherCR___DataManager_onLoad = DataManager.onLoad;
	DataManager.onLoad = function(object) {
		___FeatherCR___DataManager_onLoad.call(this,object);
		if (object && object[1] && object[1].learnings) {
			object.forEach(item => {
				if (item) this.extractArrayMetadata(item.learnings);
			}, this)
		}
	};
	
	
	
	
	
	
	
	
	
	//-----------------------------------------------------------------------------
	// Window_LevelUpDisplaySkills
	//
	// This window is the window for the level up skills display system.

	function Window_LevelUpDisplaySkills() {
		this.initialize.apply(this, arguments);
		this._lifetime = 100;
		this._t = 0;
	}

	Window_LevelUpDisplaySkills.prototype = Object.create(Window_Base.prototype);
	Window_LevelUpDisplaySkills.prototype.constructor = Window_LevelUpDisplaySkills;

	Window_LevelUpDisplaySkills.prototype.initialize = function (rect) {
		Window_Base.prototype.initialize.call(this, rect);
		this.openness = 0;
		this._text = "";
	};

	Window_LevelUpDisplaySkills.prototype.update = function() {
		Window_Base.prototype.update.call(this);
		this.updateLifeTime();
		
	};
	
	Window_LevelUpDisplaySkills.prototype.updateLifeTime = function() {
		this._lifetime--;
		const MOVE_DURATION = 60;
		if (this._lifetime <= 0) {
			this.opacity = Feather_Core.easeOutSine(this._t,255,-255,MOVE_DURATION);
			this.contentsOpacity = Feather_Core.easeOutSine(this._t,255,-255,MOVE_DURATION);
			this._t = Math.min(MOVE_DURATION,this._t+1);
		}
	};

	Window_LevelUpDisplaySkills.prototype.setText = function(text) {
		if (this._text !== text) {
			this._text = text;
			this.refresh();
		}
	};

	Window_LevelUpDisplaySkills.prototype.clear = function() {
		this.setText("");
	};

	Window_LevelUpDisplaySkills.prototype.setItem = function(item) {
		this.setText(item ? item.description : "");
	};

	Window_LevelUpDisplaySkills.prototype.refresh = function() {
		const rect = this.baseTextRect();
		this.contents.clear();
		this.drawTextEx(this._text, rect.x, rect.y, rect.width);
	};
	
	
	//-----------------------------------------------------------------------------
	// Window_LevelUpBranch
	//
	// This window is command window for the level up branch system.

	function Window_LevelUpBranch() {
		this.initialize.apply(this, arguments);
	}

	Window_LevelUpBranch.prototype = Object.create(Window_Command.prototype);
	Window_LevelUpBranch.prototype.constructor = Window_LevelUpBranch;

	Window_LevelUpBranch.prototype.initialize = function (x, y, branches) {
		this._branches = branches;
		this._branchesLength = branches.length;
		let height = Scene_Base.prototype.calcWindowHeight(Math.min(branches.length,6), true);
		let rect = {x:x-150,y:y-height/2,width:300,height:height};
		Window_Command.prototype.initialize.call(this, rect);
		this.openness = 0;
	};

	Window_LevelUpBranch.prototype.makeCommandList = function () {
		for (const branch of this._branches) {
			this.addCommand(branch.Name, branch.ID);
		}
	};

	Window_LevelUpBranch.prototype.maxItems = function() {
		return this._branchesLength;
	};
	
	//-----------------------------------------------------------------------------
	// Sprite_LevelUpExpGauge
	//
	// This sprite is the exp gauge for the level up system.

	function Sprite_LevelUpExpGauge() {
		this.initialize.apply(this, arguments);
	}

	Sprite_LevelUpExpGauge.prototype = Object.create(Sprite_Gauge.prototype);
	Sprite_LevelUpExpGauge.prototype.constructor = Sprite_LevelUpExpGauge;

	Sprite_LevelUpExpGauge.prototype.initialize = function () {
		Sprite_Gauge.prototype.initialize.call(this);
		this._startNeeded = false;
		this._timer = -1;
	};
	
	Sprite_LevelUpExpGauge.prototype.destroy = function(options) {
		this._battler._levelUpGaugeLastExp = this._value;
		this.bitmap.destroy();
		Sprite.prototype.destroy.call(this, options);
	};
	
	Sprite_LevelUpExpGauge.prototype.setup = function(battler) {
		this._battler = battler;
		this._maxValue = this.currentMaxValue();
		this._value = battler._levelUpGaugeLastExp || 0;
		this._timer = -1;
	};
	
	Sprite_LevelUpExpGauge.prototype.start = function() {
		this._animationEnded = false;
		this._startNeeded = false;
		if (this._battler.isMaxLevel()) this._timer = 40;
		this.updateBitmap();
	};
	
	Sprite_LevelUpExpGauge.prototype.updateBitmap = function() {
		
		if (!this._animationEnded && this._timer == -1) Sprite_Gauge.prototype.updateBitmap.call(this);
		if (this._timer > -1) {
			this._timer--;
			if (this._timer == 0) this._animationEnded = true;
			this.opacity = (this._timer/20)*255;
		}
		
	}
	
	Sprite_LevelUpExpGauge.prototype.updateGaugeAnimation = function() {
		if (this._duration > 0) {
			const d = this._duration;
			this._value = (this._value * (d - 1) + this._targetValue) / d;
			//this._maxValue = (this._maxValue * (d - 1) + this._targetMaxValue) / d;
			this._duration--;
			this.redraw();
			if (this._duration % 2) AudioManager.playSe({name: 'Decision2', pan: 0, pitch: 80+(this._value/this._maxValue)*90, volume: 40});
		} else {
			if (this._value == this._maxValue) {
				AudioManager.playSe({name: 'Up4', pan: 0, pitch: 150, volume: 80});
				this._animationEnded = true;
				this._maxValue = this._battler.expForLevel(this._battler.level+2) - this._battler.nextLevelExp();
				this._value = (this._battler.level<this._battler.maxLevel()-1) ? 0 : this._maxValue;
				this.redraw();
			}
			else this._timer = 40;
			this._battler._levelUpGaugeLastExp = 0;
		}
	};
	
	Sprite_LevelUpExpGauge.prototype.bitmapWidth = function() {
		return 800;
	};

	Sprite_LevelUpExpGauge.prototype.bitmapHeight = function() {
		return 32;
	};
	
	Sprite_LevelUpExpGauge.prototype.gaugeX = function() {
		return 0;
	};
	
	Sprite_LevelUpExpGauge.prototype.smoothness = function() {
		return 70;
	};
	
	Sprite_LevelUpExpGauge.prototype.currentValue = function() {
		return Math.min(this._battler.currentExp() - this._battler.currentLevelExp(), this._maxValue);
	};

	Sprite_LevelUpExpGauge.prototype.currentMaxValue = function() {
		return this._battler.nextLevelExp() - this._battler.currentLevelExp();
	};
	
	Sprite_LevelUpExpGauge.prototype.label = function() {
		return TextManager.level;
	};
	
	Sprite_LevelUpExpGauge.prototype.gaugeColor1 = function() {
		return ColorManager.mpGaugeColor1();
	};

	Sprite_LevelUpExpGauge.prototype.gaugeColor2 = function() {
		return ColorManager.mpGaugeColor2();
	};
	
	Sprite_LevelUpExpGauge.prototype.valueColor = function() {
		return ColorManager.normalColor();
	};
	
	Sprite_LevelUpExpGauge.prototype.drawValue = function() {
		const currentValue = this._maxValue-(this._value<<0);
		const width = this.bitmapWidth();
		const height = this.bitmapHeight();
		this.setupValueFont();
		this.bitmap.drawText(currentValue, 0, 0, width, height, "right");
	};
	
	
	
	
	//-----------------------------------------------------------------------------
	// Window_LevelUpStats
	//
	// This window is the window for the level up stats raise system.

	function Window_LevelUpStats() {
		this.initialize.apply(this, arguments);
	}

	Window_LevelUpStats.prototype = Object.create(Window_Base.prototype);
	Window_LevelUpStats.prototype.constructor = Window_LevelUpStats;

	Window_LevelUpStats.prototype.initialize = function () {
		let rect = {x:1280,y:Graphics.boxHeight*0.65-250,width:350,height:320};
		Window_Base.prototype.initialize.call(this, rect);
		this.setBackgroundType(2);
		this._actor = null;
		this._statsRaise = [];
		this._t;
		this._MOVE_DURATION = 40;
		this._PARAMS_NAME_COLOR = ColorManager.getColor(16);
		this._RAISE_BONUS_COLOR = ColorManager.getColor(14);
		this._TEXT_NORMAL_COLOR = ColorManager.normalColor();
		this.createStats();
	};
	
	Window_LevelUpStats.prototype.update = function () {
		this.x = Feather_Core.easeOutSine(this._t,1280,(Graphics.boxWidth*0.8-175)-1280,this._MOVE_DURATION);
	};
	
	Window_LevelUpStats.prototype.refresh = function () {
		this.makeStats();
	};
	
	Window_LevelUpStats.prototype.changeTextColor = function(color) {
		this.contents.textColor = color;
	};
	
	Window_LevelUpStats.prototype.drawItemDarkRect = function(x, y, width, height, opacity) {
		opacity = Math.max(opacity || 1, 1);
		while (opacity--) {
			height = height || this.lineHeight();
			this.contents.paintOpacity = 160;
			const color = "#202040";
			this.contents.fillRect(x + 1, y + 1, width - 2, height - 2, color);
			this.contents.paintOpacity = 255;
		}
	};
	
	Window_LevelUpStats.prototype.createStats = function () {
		// Declare variables
		const params = [0,1,2,3,4,5,6,7];
		const paramsIcons = [84,29,76,81,12,13,14,87];
		const lineHeight = this.lineHeight();
		const padding = this.itemPadding();
		const baseX = 0;
		const baseY = this.innerHeight - params.length * lineHeight;
		const baseWidth = this.innerWidth;
		const valueFontSize = 22;

		// Calculate Widths
		let paramNameWidth = Math.max(...params.map(param => this.textWidth(TextManager.param(param))));
		paramNameWidth += padding * 2 + ImageManager.iconWidth + 4;

		let paramValueWidth = baseWidth - paramNameWidth;
		paramNameWidth = baseWidth - paramValueWidth;
		paramValueWidth -= 50;

		// Draw Parameters
		let x = baseX;
		let y = baseY;
		let alter = 2;
		for (const paramId of params) {
			// Draw Param Name
			
			this.changeTextColor(this._PARAMS_NAME_COLOR);
			this.contents.fontSize = valueFontSize;
			
			this.drawItemDarkRect(x, y, paramNameWidth, lineHeight, alter);
			const iconY = y + (this.lineHeight() - ImageManager.iconHeight) / 2;
			const textMargin = ImageManager.iconWidth + 4;
			this.drawIcon(paramsIcons[paramId], x+4, iconY);
			this.drawText(TextManager.param(paramId), x+4 + textMargin, y, paramNameWidth-8);
			
			this.changeTextColor(this._TEXT_NORMAL_COLOR);
			this.changeOutlineColor(ColorManager.outlineColor());
			this.contents.fontFace = $gameSystem.mainFontFace();
			this.contents.fontSize = $gameSystem.mainFontSize();
			
			y += lineHeight;
			alter = alter === 2 ? 1 : 2;
		}
	};

	Window_LevelUpStats.prototype.makeStats = function () {
		// Declare variables
		const params = [0,1,2,3,4,5,6,7];
		const lineHeight = this.lineHeight();
		const padding = this.itemPadding();
		const baseY = this.innerHeight - params.length * lineHeight;
		const baseWidth = this.innerWidth;
		const valueFontSize = 22;

		// Calculate Widths
		let paramNameWidth = Math.max(...params.map(param => this.textWidth(TextManager.param(param))));
		paramNameWidth += padding * 2 + ImageManager.iconWidth + 4;

		let paramValueWidth = baseWidth - paramNameWidth;
		paramNameWidth = baseWidth - paramValueWidth;
		paramValueWidth -= 50;

		// Draw Parameters
		let x = paramNameWidth;
		let y = baseY;
		let alter = 2;
		this.contents.clearRect(x,y,this.innerWidth,this.innerHeight);
		for (const paramId of params) {
			// Draw Param Before
			
			this.contents.fontSize = valueFontSize;
			
			this.drawItemDarkRect(x, y, paramValueWidth, lineHeight, alter);
			this.drawText((this._actor.param(paramId)-this._statsRaise[paramId]).toString().replace(/\B(?=(\d{3})+(?!\d))/g, " "), x+4, y, paramValueWidth-8, "right");
			
			x += paramValueWidth;
			
			this.changeTextColor(this._RAISE_BONUS_COLOR);
			this.contents.fontSize = 12;
			if (this._statsRaise[paramId] > 0) this.drawText("+" + this._statsRaise[paramId].toString().replace(/\B(?=(\d{3})+(?!\d))/g, " "), x+4, y, 50-8, "left");
			
			this.changeTextColor(this._TEXT_NORMAL_COLOR);
			this.changeOutlineColor(ColorManager.outlineColor());
			this.contents.fontFace = $gameSystem.mainFontFace();
			this.contents.fontSize = $gameSystem.mainFontSize();

			// Prepare Next Parameter
			x = paramNameWidth;
			y += lineHeight;
			alter = alter === 2 ? 1 : 2;
		}
	};
	
	
	//-----------------------------------------------------------------------------
	// Scene_FeatherLevelUp
	//
	// The scene for selecting a branch of level up.

	function Scene_FeatherLevelUp() {
		this.initialize.apply(this, arguments);
	}

	Scene_FeatherLevelUp.prototype = Object.create(Scene_MenuBase.prototype);
	Scene_FeatherLevelUp.prototype.constructor = Scene_FeatherLevelUp;

	Scene_FeatherLevelUp.prototype.initialize = function () {
		Scene_MenuBase.prototype.initialize.call(this);
		this.playBgm();
		this._memberIndex = 0;
		this._portraitT = 0;
		this._tick = 0;
		this._waitingBranchChoice = false;
		this._waitingLeveling = 0;
		this._waitingExpBar = false;
		this._statsRaise = [0,0,0,0,0,0,0,0];
		this._skillsDisplayWindows = [];
		this._branchChoosed = false;
	};
	
	Scene_FeatherLevelUp.prototype.playBgm = function () {
		switch ($gameSystem.victoryMe().name) {
			
			case "Fanfare1":
			case "RMMV_Fanfare1":
			case "RMMV_Fanfare2":
			case "RMMV_Fanfare3":
				AudioManager.playBgm({name: 'RMMV_VictoryLoop1', pan: 0, pitch: 100, volume: 50});
			break;
			
			case "Victory2":
			case "Victory5":
			case "RMMV_Victory2":
				AudioManager.playBgm({name: 'RMMV_VictoryLoop2', pan: 0, pitch: 100, volume: 50});
			break;
			
			default:
				AudioManager.playBgm({name: 'LevelUpClassic', pan: 0, pitch: 100, volume: 50});
			break;
			
		}
		
	};

	Scene_FeatherLevelUp.prototype.create = function () {
		this.createBackground();
		this.createActorPortrait();
		this.updateActor();
		this.createWindowLayer();
		this.createStatsWindow();
		this.createHelpWindow();
	};
	
	Scene_FeatherLevelUp.prototype.createExpBar = function(member) {
		this._expBar = new Sprite_LevelUpExpGauge();
		this.addChild(this._expBar);
		this._expBar.setup(member);
		this._expBar.start();
		this._expBar.move(Graphics.boxWidth/2-this._expBar.width/2, Graphics.boxHeight*0.075);
		this._expBar.show();
		this._waitingExpBar = true;
	};
	
	Scene_FeatherLevelUp.prototype.createActorPortrait = function() {
		this._actorPortraitSprite = new Sprite();
		this._actorPortraitSprite.bitmap = ImageManager.loadBitmap("img/pictures/", "Oujnish");
		this._actorPortraitSprite.move(0, Graphics.boxHeight*0.65-this._actorPortraitSprite.height/2);
        this._actorPortraitSprite.scale.x *= -1;
		this.addChild(this._actorPortraitSprite);
	};

	Scene_FeatherLevelUp.prototype.start = function() {
		Scene_MenuBase.prototype.start.call(this);
	};
	
	Scene_FeatherLevelUp.prototype.update = function() {
		Scene_MenuBase.prototype.update.call(this);
		this._tick++;
		this.updateHelpWindow();
		if (this._expBar) this.updateExpBar();
		if (this._skillsDisplayWindows.length > 0 || this._skillsDisplayWindow) this.updateSkillsDisplayWindows();
		if (this.waitingLeveling()) this.updateStatsWindow();
		this.updateActorPortrait();
		this.updateLevelUpBranchCommandWindow();
		if (!this.updateLeveling()) {
			
		}
	};
	
	Scene_FeatherLevelUp.prototype.updateExpBar = function() {
		
		if (this._expBar._animationEnded) {
			this._waitingExpBar = false;
		}
		
	};
	
	Scene_FeatherLevelUp.prototype.updateSkillsDisplayWindows = function() {
		
		if (!this._skillsDisplayWindow) {
			this._skillsDisplayWindow = this._skillsDisplayWindows.shift();
			this.addChild(this._skillsDisplayWindow);
			this._skillsDisplayWindow.open();
			AudioManager.playSe({name: 'Heal7', pan: 0, pitch: 150, volume: 80});
		}
		if (this._skillsDisplayWindow.opacity <= 0) {
			this._skillsDisplayWindow.destroy();
			this._skillsDisplayWindow = null;
			this._waitingLeveling--;
		}
		
	};
	
	Scene_FeatherLevelUp.prototype.updateLevelUpBranchCommandWindow = function() {
		
		if (this._levelUpBranchCommandWindow && this._levelUpBranchCommandWindow.isClosed()) {
			this._levelUpBranchCommandWindow.destroy();
			this._levelUpBranchCommandWindow = null;
		}
		
	};
	
	Scene_FeatherLevelUp.prototype.updateHelpWindow = function() {
		if (this._levelUpBranchCommandWindow) {
			if (this._helpWindow.isClosed()) this._helpWindow.open();
			this._helpWindow.setText(this._levelUpBranchCommandWindow._branches[this._levelUpBranchCommandWindow.index()].Desc);
		} else {
			if (this._helpWindow.isOpen()) this._helpWindow.close();
		}
	};
	
	
	Scene_FeatherLevelUp.prototype.updateStatsWindow = function() {
		const RAISE_DURATION = 20;
		let lastT = this._levelUpStatsWindow._t;
		this._levelUpStatsWindow._actor = $gameParty.members()[this._memberIndex];
		this._levelUpStatsWindow._statsRaise = this._statsRaise;
		this._levelUpStatsWindow.refresh();
		if (this._statsRaise.reduce((a,b) => a+b)) {
			
			this._levelUpStatsWindow._t = Math.min(this._levelUpStatsWindow._MOVE_DURATION,this._levelUpStatsWindow._t+1);
			
		}
		if (this._waitingLeveling == 1) {
			
			this._levelUpStatsWindow._t--;
			
		}
		if (!(this._tick % 2) && lastT >= this._levelUpStatsWindow._t && this._statsRaise.reduce((a,b) => a+b)) {
			this._statsRaise = this._statsRaise.map(a => a = Math.max(a-Math.max(((a/RAISE_DURATION)<<0),1), 0));
			AudioManager.playSe({name: 'Cursor1', pan: 0, pitch: 130+Math.random()*50, volume: 30});
			if (!this._statsRaise.reduce((a,b) => a+b)) this._waitingLeveling--;
		}
		if (!this._levelUpStatsWindow._t) this._waitingLeveling--;
	};
	
	
	Scene_FeatherLevelUp.prototype.updateActorPortrait = function() {
		
		const member = $gameParty.members()[this._memberIndex];
		const MOVE_DURATION = 40;
		this._actorPortraitSprite.bitmap = ImageManager.loadBitmap("img/pictures/", member.getBattlePortrait());
		this._actorPortraitSprite.y = Graphics.boxHeight*0.65-this._actorPortraitSprite.height/2;
		this._actorPortraitSprite.x = Feather_Core.easeOutSine(this._portraitT,0,this._actorPortraitSprite.width,MOVE_DURATION);
		if (member._levelsGained > 0 || this._waitingLeveling > 1 || (this._expBar && this._expBar._timer == -1)) this._portraitT = Math.min(MOVE_DURATION,this._portraitT+1);
		else this._portraitT = Math.max(0,this._portraitT-1);
	};
	
	
	Scene_FeatherLevelUp.prototype.updateLeveling = function() {
		while (!this.isFading() && !this.waitingBranchChoice() && !this.waitingLeveling() && !this.waitingExpBar()) {
			const member = $gameParty.members()[this._memberIndex];
			const allBranches = member.currentClass().longMeta.Branch  || [];
			const lastSkills = member.skills();
			if (member._expGained > 0 && !this._expBar) {
				
				return this.createExpBar(member);
				
			};
			if (this._expBar && this._expBar._startNeeded) {
				
				this._waitingExpBar = true;
				return this._expBar.start();
				
			}
			if (!member.isMaxLevel() && member._levelsGained > 0) {
				
				member._levelsGained--;
				this._statsRaise = [0,0,0,0,0,0,0,0].map((a,b) => a-member.paramBase(b));
				member.featherLevelUp();
				this._expBar.setup(member);
				
				const branches = allBranches.filter(branch => 
					member.isInLevelRange(branch.Level) &&
					( branch.ID      	   &&	!member._choosedBranches.some(item => branch.ID === item.ID ) )		 		 					 &&
					( !branch.Require      ||	eval(branch.Require).every(item => member._choosedBranches.map(a => a.ID).includes(item)) ) 		 &&
					( !branch.Incompatible || 	!eval(branch.Incompatible).some(item => member._choosedBranches.map(a => a.ID).includes(item)) ) &&
					( !branch.Condition    || 	eval(branch.Condition) )
				);
				console.log(member._level, branches);
			
				if (branches.length && !this._branchChoosed) {
					
					this.createLevelUpBranchCommand(branches);
					return true;
					
				}
				member.featherLearnNewSkills();
				this.requestLevelingDisplay(member.findNewSkills(lastSkills).concat(member._newSkills || []));
				member._newSkills = [];
				member.refresh();
				this._statsRaise = this._statsRaise.map((a,b) => a+member.paramBase(b));
				this._expBar._startNeeded = true;
				this._branchChoosed = false;
			
			} else {
				
				if (this._expBar) {
					this._expBar.destroy();
					this._expBar = null;
				};
				this._memberIndex++;
				this._portraitT = 0;
				this._branchChoosed = false;
				if (this._memberIndex > $gameParty.members().length-1) {
					
					this._memberIndex--;
					this.fadeOutAll();
					this.popScene();
					BattleManager.replayBgmAndBgs();
					
				}
				
			}
			
			return false;
		}
		
		return true;
	};
	
	Scene_FeatherLevelUp.prototype.waitingBranchChoice = function() {
		return this._waitingBranchChoice;
	};
	
	Scene_FeatherLevelUp.prototype.waitingLeveling = function() {
		return this._waitingLeveling;
	};
	
	Scene_FeatherLevelUp.prototype.waitingExpBar = function() {
		return this._waitingExpBar;
	};

	Scene_FeatherLevelUp.prototype.createHelpWindow = function() {
		Scene_MenuBase.prototype.createHelpWindow.call(this);
		this._helpWindow.openness = 0;
		this._helpWindow.y = this._helpWindow.height;
	};
	
	Scene_FeatherLevelUp.prototype.createStatsWindow = function() {
		this._levelUpStatsWindow = new Window_LevelUpStats();
		this.addWindow(this._levelUpStatsWindow);
	};
	
	Scene_FeatherLevelUp.prototype.createLevelUpBranchCommand = function (branches) {
		const member = $gameParty.members()[this._memberIndex];
		if (member._preChoosedBranches && branches.some(a => member._preChoosedBranches.includes(a.ID))) {
			const branch = branches.find(a => member._preChoosedBranches.includes(a.ID));
			member._preChoosedBranches.splice(member._preChoosedBranches.findIndex(a => a == branch.ID), 1);
			this.chooseBranch(branch);
		} else {
			this._waitingBranchChoice = true;
			this._levelUpBranchCommandWindow = new Window_LevelUpBranch(Graphics.boxWidth/2, Graphics.boxHeight/2, branches);
			for (const branch of branches) {
				this._levelUpBranchCommandWindow.setHandler(branch.ID, this.chooseBranch.bind(this,branch));
			}
			this.addWindow(this._levelUpBranchCommandWindow);
			this._levelUpBranchCommandWindow.open();
		}
	};
	
	Scene_FeatherLevelUp.prototype.chooseBranch = function (branch) {
		
		const member = $gameParty.members()[this._memberIndex];
		member._levelsGained++;
		member._level--;
		branch = Feather_Core.deepCopy(branch);
		branch.traits = [];
		this._waitingBranchChoice = false;
		this._branchChoosed = true;
		if (branch.ID.toUpperCase() != "NULL") {
			branch.Level = member._level;
			member._choosedBranches.push(branch);
			if (branch.Params) member.featherApplyParams(eval(branch.Params),branch);
		}
		if (this._levelUpBranchCommandWindow) this._levelUpBranchCommandWindow.close();
		
	};
	
	Scene_FeatherLevelUp.prototype.requestLevelingDisplay = function (newSkills) {
		
		let texts = [];
		let j = 0;
		let i = 0;
		if (newSkills.length > 0) texts.push("");
		for (const skill of newSkills) {
			if (i == 4) {
				i = 0;
				j++;
				texts.push("");
			}
			texts[j] += `<center>\\C[16]\\I[${skill.iconIndex}]`+TextManager.obtainSkill.format(skill.name)+"\n</center>";
			i++
		}
		
		this._waitingLeveling = 2 + texts.length;
		this._levelUpStatsWindow._t = 0;
		
		for (const text of texts) {
			let window = new Window_LevelUpDisplaySkills(this.levelUpDisplaySkillsWindowRect());
			window.setText(text);
			this._skillsDisplayWindows.push(window);
		}
	};
	
	Scene_FeatherLevelUp.prototype.levelUpDisplaySkillsWindowRect = function() {
		const ww = Graphics.boxWidth*0.6;
		const wh = this.calcWindowHeight(4, false) + 8;
		const wx = (Graphics.boxWidth - ww) / 2;
		const wy = Graphics.boxHeight-wh-8;
		return new Rectangle(wx, wy, ww, wh);
	};
	


})();
