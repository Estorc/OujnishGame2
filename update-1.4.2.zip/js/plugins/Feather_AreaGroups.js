//=============================================================================
// RPG Maker MZ - AreaGroups
//=============================================================================

/*:
 * @target MZ
 * @plugindesc Area Groups system plugin.
 * @author Feather
 *
 * @help 
 * Area Groups system plugin.
 *
 * @param AreaGroups:arraystruct
 * @text Area Groups Settings
 * @type struct<AreaGroup>[]
 * @desc Settings for Area Groups.
 * @default []
 *
 * @param WorldMapAreaGroups:arraystruct
 * @text World Map Area Groups Settings
 * @type struct<RegionAreaGroup>[]
 * @desc Settings for World Map Area Groups.
 * @default []
 */
/*~struct~RegionAreaGroup:
 *
 * @param RegionId:number
 * @text Region Id
 * @type number
 * @desc Id of the region.
 * @default 0
 *
 * @param AreaGroupId:number
 * @text Area Group Id
 * @type number
 * @desc Id of the Area Group.
 * @default 0
 *
 */
/*~struct~AreaGroup:
 *
 * @param Id:number
 * @text Id
 * @type number
 * @desc Id of this Area Group.
 * @default 0
 *
 * @param Name:str
 * @text Name
 * @desc Name of this Area Group.
 * @default Untitled Area
 *
 * @param ElementsMultiplier:arraystruct
 * @text Elements Multiplier
 * @type struct<Elements>[]
 * @desc Elements multiplier in this Area Group (alchemy).
 * @default []
 *
 */
/*~struct~Elements:
 *
 * @param Id:number
 * @text Id
 * @type number
 * @desc Id of this element (alchemy).
 * @default 0
 *
 * @param Multiplier:number
 * @text Multiplier
 * @type number
 * @decimals 2
 * @desc Multiplier of this element.
 * @default 1.00
 * @min 0
 *
 */
 

(() => {
    const pluginName = "Feather_AreaGroups";
	
	
	//-----------------------------------------------------------------------------
	// Feather_AreaGroups
	//
	// The main class of Feather Area Groups.
	
	
	Feather_AreaGroups = function() {
		throw new Error("This is a static class");
	};
	
	
	Feather_AreaGroups.data = Feather_Core.loadPluginParameters(PluginManager.parameters(pluginName));
	

	___FeatherAG___Game_Map_setup = Game_Map.prototype.setup;
	Game_Map.prototype.setup = function(mapId) {
		___FeatherAG___Game_Map_setup.call(this, mapId);
		this.dataAreaGroups = Feather_AreaGroups.data;
	};
	
	Game_Map.prototype.getAreaGroup = function() {
		if (!$dataMap || !$dataMap.meta) {
			return null;
		}
		let id = eval($dataMap.meta.AreaGroup);
		if (typeof id === 'undefined') return null;
		if (id === -1) {
			id = Feather_AreaGroups.data.WorldMapAreaGroups.find(a => a.RegionId === $gamePlayer.regionId());
			if (id) id = id["AreaGroupId"];
			else return null;
		}
		return Feather_AreaGroups.data.AreaGroups.find(a => a.Id === id);
	};

})();
