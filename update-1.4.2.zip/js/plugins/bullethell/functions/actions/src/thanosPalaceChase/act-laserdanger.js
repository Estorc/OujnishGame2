module.exports = {
		
    name: 'Laser Danger',
	id: 11,

    execute (index, _BH) {
		this.hp -= 1;

		if (this.hp != 0) {
			if (Number.isInteger(this.hp / 30)) {
						
			this.pos.y = 0;

			}

			if (Number.isInteger(this.hp / 60)) {
						
			this.pos.y = _BH.bhmaxheight/2;
			AudioManager.playSe({name: 'Siren', pan: 0, pitch: 150, volume: 100});

			}
		}

		if (this.hp == 0) {
			
		if (typeof this.timer === 'undefined') {
			this.timer = 0;
			AudioManager.playSe({name: 'Darkness4', pan: 0, pitch: 100, volume: 90});
		}
		this.timer += 1;
			
			args = {};
			args.name = "";
			args.posx = this.pos.x;
			args.posy = this.pos.y-32;
			args.width = 16;
			args.height = 16;
			args.speed = 16;
			args.direction = 180;
			args.directioniscircle = "false";
			args.sprite = 'thanoscarlaser';
			args.hp = 0;
			args.candie = "false";
			args.canbetouched = "false";
			args.action = 0;
			args.deathaction = 0;
			args.isPlayerShot = "false";
			args.isBonus = "false";
			args.anchorAligned = false;
			_BH.createBHObject(args)
			
			
		if (this.timer <= 60) {
			
			this.hp = 1;
			
		}
			
		}
    },
};