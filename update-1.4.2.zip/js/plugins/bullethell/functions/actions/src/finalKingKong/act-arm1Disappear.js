module.exports = {
		
    name: 'KK_Arm1Disappear',
	id: 1102,

    execute (index, _BH) {
		if(typeof this.begin === 'undefined') {

			this.begin = 0;
			this.timer = 0;
			this.originx = this.pos.x;
			this.originy = this.pos.y;
			
		}
		
		_BH.objects[0].armCleared = true;
		
		this.hp = 1;
		this.collision = [{}];
		this.action = BHactions.find(action => action.name == 'KK_Arm1Disappear').execute;
		
		if (this.opacity > 255/2 || _BH.objects[0].headCleared) {
			
			this.opacity -= 10;
			
		}
		
	},
};