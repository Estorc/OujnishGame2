module.exports = {
		
    name: 'Beast Big Laser Danger',
	id: 14,

    execute (index, _BH) {
		if (this.hp != 0) {
			if (Number.isInteger(this.hp / 30)) {
						
			this.offset.y -= 1000;

			}

			if (Number.isInteger(this.hp / 60)) {
						
			this.offset.y = 0;
			AudioManager.playSe({name: 'Siren', pan: 0, pitch: 130, volume: 100});

			}
		}

		this.hp -= 1;

		if (this.hp == 0) {
			
			this.offset.y = 0;
			
		if (typeof this.timer === 'undefined') {
			this.timer = 0;
			AudioManager.playSe({name: 'Darkness4', pan: 0, pitch: 100, volume: 90});
		}
			
			args = {};
			args.name = "";
			args.posx = this.pos.x;
			args.posy = this.pos.y;
			args.offsetx = -8;
			args.offsety = 0;
			args.width = 64;
			args.height = 128;
			args.speed = 0;
			args.direction = 0;
			args.directioniscircle = "false";
			args.sprite = 'beastbiglaser';
			args.hp = 300;
			args.candie = "true";
			args.canbetouched = "false";
			args.cantbeinstakill = "true";
			args.action = 15;
			args.deathaction = 0;
			args.isPlayerShot = "false";
			args.isBonus = "false";
			args.anchorAligned = false;
			_BH.createBHObject(args)
			
		}
    },
};