module.exports = {
		
    name: 'Shoot Spawner',
	id: 503,

    execute (index, _BH) {
		
		this.hp +=1;
		
		if (this.hp % 30 == 0) {
			
			args = {};
			args.name = "shootSpawner";
			args.speed = 5;
			args.directioniscircle = "false";
			args.hp = (this.distance*48+24)/5;
			args.candie = "true";
			args.canbetouched = "false";
			args.deathaction = 502;
			args.isPlayerShot = "false";
			args.isBonus = "false";
			args.cantbeinstakill = "false";
			args.action = function(index, _BH) 
			{
				this.hp -= 1;
				if(this.scale.x < 1) {
					this.scale.x += 0.1;
					this.scale.y += 0.1;
				}
			};
			args.sprite = 'thanoscarbullet';
			args.width = 16;
			args.height = 16;
			args.scalex = 0;
			args.scaley = 0;
			args.posx = this.pos.x-8;
			args.posy = this.pos.y-8;
			args.direction = (Math.atan2(this.direction.y,this.direction.x) * 180 / Math.PI)+90;
			args.anchorAligned = false;
			_BH.createBHObject(args)
			
		}
		
    },
};