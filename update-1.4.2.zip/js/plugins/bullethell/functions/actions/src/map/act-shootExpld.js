module.exports = {
		
    name: 'Shoot Wall Explosion',
	id: 502,

    execute (index, _BH) {
		AudioManager.playSe({name: 'Explosion4', pan: 0, pitch: 150, volume: 20});
		
		
		let direction = (Math.atan2(this.direction.y,this.direction.x) * 180 / Math.PI)+90;
		
		
		for (n=0;n<4;n++) {
			
			args = {};
			args.name = "";
			args.speed = 2+Math.random()*this.speed;
			args.directioniscircle = "false";
			args.hp = 1;
			args.candie = "true";
			args.canbetouched = "false";
			args.deathaction = 0;
			args.isPlayerShot = "false";
			args.isBonus = "false";
			args.cantbeinstakill = "false";
			args.action = function(index, _BH) 
				{
				
					this.speed *= 0.99;
					this.opacity -= 5;
					this.scale.x -= 0.01;
					this.scale.y -= 0.01;
					this.collision = [{}];
					
					if (this.opacity <= 0) {

						this.hp = 0;
					
					}
				
				};
			args.sprite = 'thanoscarbullet';
			args.width = 16;
			args.height = 16;
			args.posx = this.pos.x;
			args.posy =this.pos.y;
			args.direction = direction-180 + 70-Math.random()*55;
			args.anchorAligned = false;
			_BH.createBHObject(args)
		}
		
		for (n=0;n<4;n++) {
			
			args = {};
			args.name = "";
			args.speed = 2+Math.random()*this.speed;
			args.directioniscircle = "false";
			args.hp = 1;
			args.candie = "true";
			args.canbetouched = "false";
			args.deathaction = 0;
			args.isPlayerShot = "false";
			args.isBonus = "false";
			args.cantbeinstakill = "false";
			args.action = function(index, _BH) 
				{
				
					this.speed *= 0.99;
					this.opacity -= 5;
					this.scale.x -= 0.01;
					this.scale.y -= 0.01;
					this.collision = [{}];
					
					if (this.opacity <= 0) {

						this.hp = 0;
					
					}
				
				};
			args.sprite = 'thanoscarbullet';
			args.width = 16;
			args.height = 16;
			args.posx = this.pos.x;
			args.posy =this.pos.y;
			args.direction = direction-180 + 290+Math.random()*55;
			args.anchorAligned = false;
			_BH.createBHObject(args)
		}
    },
};