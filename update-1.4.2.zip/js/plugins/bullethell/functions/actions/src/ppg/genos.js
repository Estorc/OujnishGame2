module.exports = {
		
    name: 'Genos',
	id: 68,

    execute (index, _BH) {
		if(typeof this.begin === 'undefined') {

			this.begin = 0;
			
		}
		
		if (this.direction.x > 0) {
			
			this.sprite = _BH.loadImages('GenosRight@4@7');
			_BH.collisionSprite = null;
			this.offset.x = -49;
			
		} else if (this.direction.x < 0) {
			
			this.sprite = _BH.loadImages('Genos@4@7'); 
			_BH.collisionSprite = null;
			this.offset.x = 0;
			
		}
    },
};