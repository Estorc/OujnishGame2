module.exports = {
		
    name: 'PPG Aura',
	id: 70,

    execute (index, _BH) {
		if(typeof this.begin === 'undefined') {

			this.x = 0;
			this.y = 0;
			this.originx = this.pos.x;
			this.originy = this.pos.y;
			this.begin = 0;
			this.genosid = _BH.getObjectByName("Genos");
			
		}
		
		this.x = _BH.objects[this.genosid].pos.x-9;
		this.y = _BH.objects[this.genosid].pos.y-2;
		
		
		this.offset.x = Math.ceil(this.x);
		this.offset.y = Math.ceil(this.y);
		
		this.pos.x = 0;
		this.pos.y = 0;
    },
};