module.exports = {
		
    name: 'Big Bullet',
	id: 45,

    execute (index, _BH) {
			if(typeof this.begin === 'undefined') {

				this.explosionPower = this.hp;
				this.begin = 0;
				
			}
			
		this.direction.x = Math.cos(_BH.getDirectionToPlayer(index) *Math.PI/180);
		this.direction.y = Math.sin(_BH.getDirectionToPlayer(index) *Math.PI/180);
		
		if (this.pos.y-_BH.bhmaxheight/2+16 <=460 &&
		    this.pos.x-_BH.bhmaxwidth/2+16 <=828 &&
			this.pos.x-_BH.bhmaxwidth/2+16 >=452 &&
			this.pos.y-_BH.bhmaxheight/2+16 >=84) {
			
			this.hp = 0;
			
		}
		if (typeof this.collideWithPlayer !== 'undefined' && this.collideWithPlayer == 1) {
			
				this.hp = 0;
			
		}			
    },
};