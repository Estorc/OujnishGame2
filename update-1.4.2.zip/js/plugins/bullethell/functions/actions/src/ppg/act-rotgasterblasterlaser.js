module.exports = {
		
    name: 'Rot Gaster Blaster Laser',
	id: 954,

    execute (index, _BH) {
		if(typeof this.begin === 'undefined') {

			this.pos.x += -40*this.direction.x
			this.pos.y += -40*this.direction.y
			AudioManager.playSe({name: 'ppg_gasterblasterlaser', pan: 0, pitch: 100, volume: 80});
			this.begin = 0;
			
		}

		this.begin += 1;

		if (this.begin < 10) {
			
			this.scale.y += 1/10
			this.opacity += 255/10
			
		}
					
		if (this.begin > 18) {
			
			this.collision = [{}];
			this.scale.y -= 1/20
			this.opacity -= 255/10
			
			if (this.opacity <= 0) {
			
				this.candie = true;
				this.hp = 0;
				
			}
			
		}
    },
};