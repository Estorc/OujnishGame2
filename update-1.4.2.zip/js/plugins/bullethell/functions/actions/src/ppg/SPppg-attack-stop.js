module.exports = {
		
    name: 'SP_PPG Attack Stop',
	id: 130,

    execute (index, _BH) {
		
			_BH.objects.map(item => item.name === "ppgPlatform" && item.destroy() & _BH.remove(item) || item);
			this.scene.ended = true;
			
    },
};