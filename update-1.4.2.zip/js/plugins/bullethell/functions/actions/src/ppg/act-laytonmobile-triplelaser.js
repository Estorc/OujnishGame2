module.exports = {
		
    name: 'Layton Mobile Triple Laser',
	id: 47,

    execute (index, _BH) {
		if(typeof this.begin === 'undefined') {
			this.timer = 0; 
			this.maxhp = this.hp;
			this.animt = 0; 
			this.animy = this.pos.y;
			this.begin = 0;
		}
			
		
		if (this.animt <= 60 && this.hp == 1) {
			this.animt += 1;
			this.pos.y = _BH.easeOutSine(this.animt,this.animy,(84+376-200-32+_BH.bhmaxheight/2)-this.animy,60);
		}
		if (this.animt <= 60 && this.hp == 2) {
			this.animt += 1;
			this.pos.y = _BH.easeOutSine(this.animt,this.animy,(84+376-100-32+_BH.bhmaxheight/2)-this.animy,60);
		}
		if (this.animt <= 60 && this.hp == 3) {
			this.animt += 1;
			this.pos.y = _BH.easeOutSine(this.animt,this.animy,(84+376-32+_BH.bhmaxheight/2)-this.animy,60);
		}
    },
};