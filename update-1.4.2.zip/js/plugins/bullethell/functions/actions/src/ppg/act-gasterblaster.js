module.exports = {
		
    name: 'Gaster Blaster',
	id: 31,

    execute (index, _BH) {
		if(typeof this.begin === 'undefined') {
			

			AudioManager.playSe({name: 'ppg_gasterblaster', pan: 0, pitch: 100, volume: 80});
			if (this.direction.x > 0) {
				this.sprite = _BH.loadImages('gaster_blaster');
			} else {
				this.sprite = _BH.loadImages('gaster_blaster_left');
			}
			this.begin = 0;
			
		}

		this.speed /= 2;	
		if (this.speed < 1 && this.speed > 0)	 {
			
			this.speed = 0;
			this.pos.x = Math.ceil(this.pos.x);
			this.pos.y = Math.ceil(this.pos.y);
			
		}
		this.hp -= 1;

		if (this.hp == 0) {
			
				args = {};
				args.name = "";
				args.speed = 0;
				args.directioniscircle = "false";
				args.hp = 0;
				args.candie = "false";
				args.canbetouched = "false";
				args.deathaction = 0;
				args.isPlayerShot = "false";
				args.isBonus = "false";
				args.cantbeinstakill = "true";
				args.action = 32;
				args.sprite = (this.sprite.name == 'gaster_blaster') ? 'gaster_blaster_opening@6@3' : 'gaster_blaster_opening_left@6@3';
				args.width = 114;
				args.height = 96;
				args.posx = this.pos.x;
				args.posy = this.pos.y;
				let _direction = (Math.atan2(this.direction.y,this.direction.x) * 180 / Math.PI);
				if (_direction < 0) { _direction += 360; }
				args.direction = _direction;
				args.anchorAligned = false;
				_BH.createBHObject(args)
			
		}
    },
};