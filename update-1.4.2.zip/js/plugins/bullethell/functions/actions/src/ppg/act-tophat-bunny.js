module.exports = {
		
    name: 'Top Hat Bunny',
	id: 36,

    execute (index, _BH) {
		if (typeof this.maxhp === 'undefined') { this.maxhp = this.hp }
			
		
		if (this.speed > 0 && ((this.direction.x < 0 && this.sprite.name == 'ppg_tophat_left') || (this.direction.x > 0 && this.sprite.name == 'ppg_tophat_right'))) {
			if (this.pos.x > _BH.bhmaxwidth/2 + 300 && this.pos.x < 1280 - 300) {
				if (this.speed <= 1) {
					
					this.speed = 0;
					this.pos.y = Math.ceil(this.pos.y);
					this.pos.x = Math.ceil(this.pos.x);
					
				} else {
				
					this.speed *= 0.25;
				
				}
			}
		} else {
			
			this.hp -= 1;
			
			
			if (this.hp == Math.floor(this.maxhp*0.9)) {
				
					if (this.direction.x < 0) {
						_BH.createGroundJumpingBullet(this.pos.x-3,this.pos.y-3+16,28,26,5,270,'ppg_smallBunny_left',-4,-6);
					}
					else {
						_BH.createGroundJumpingBullet(this.pos.x-1+28,this.pos.y-3+16,28,26,5,90,'ppg_smallBunny_right',-4,-6);
					}
			}
				
				
				
			if (this.hp == Math.floor(this.maxhp*0.7)) {
				
					if (this.direction.x < 0) {
						_BH.createGroundJumpingBullet(this.pos.x-3,this.pos.y-3+16,28,26,5,270,'ppg_smallBunny_left',-4,-6);
					}
					else {
						_BH.createGroundJumpingBullet(this.pos.x-1+28,this.pos.y-3+16,28,26,5,90,'ppg_smallBunny_right',-4,-6);
					}
				
			}
				
				
				
			if (this.hp == Math.floor(this.maxhp*0.5)) {
				
					if (this.direction.x < 0) {
						_BH.createGroundJumpingBullet(this.pos.x-3,this.pos.y-3+16,28,26,5,270,'ppg_smallBunny_left',-4,-6);
					}
					else {
						_BH.createGroundJumpingBullet(this.pos.x-1+28,this.pos.y-3+16,28,26,5,90,'ppg_smallBunny_right',-4,-6);
					}
				
			}
				
				
				
			if (this.hp == Math.floor(this.maxhp*0.3)) {
				
					if (this.direction.x < 0) {
						_BH.createGroundJumpingBullet(this.pos.x-3,this.pos.y-3+16,28,26,5,270,'ppg_smallBunny_left',-4,-6);
					}
					else {
						_BH.createGroundJumpingBullet(this.pos.x-1+28,this.pos.y-3+16,28,26,5,90,'ppg_smallBunny_right',-4,-6);
					}
				
			}
				
				
				
			if (this.hp == Math.floor(this.maxhp*0.1)) {
				
					if (this.direction.x < 0) {
						_BH.createGroundJumpingBullet(this.pos.x-3,this.pos.y-3+16,28,26,5,270,'ppg_smallBunny_left',-4,-6);
					}
					else {
						_BH.createGroundJumpingBullet(this.pos.x-1+28,this.pos.y-3+16,28,26,5,90,'ppg_smallBunny_right',-4,-6);
					}
				
			}
			
			if (this.hp <= 0) {
				
				if (this.speed == 0) {this.direction.x *= -1; this.speed = 1}
				this.speed *= 1.25;
			}
			
		}
    },
};