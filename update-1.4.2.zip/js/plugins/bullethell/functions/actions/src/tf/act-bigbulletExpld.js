module.exports = {
		
    name: 'Big Bullet Explosion',
	id: 44,

    execute (index, _BH) {
		AudioManager.playSe({name: 'Ice2', pan: 0, pitch: 150, volume: 70});

		for (n=0;n<this.explosionPower;n++) {
			args = {};
			args.name = "";
			args.posx = this.pos.x+8;
			args.posy = this.pos.y+8;
			args.width = 16;
			args.height = 16;
			args.speed = 7;
			args.direction = _BH.getRandomInt(360);
			args.directioniscircle = "true";
			args.sprite = 'ppg_commonbullet';
			args.hp = 0;
			args.candie = "false";
			args.canbetouched = "false";
			args.action = 0;
			args.deathaction = 0;
			args.isPlayerShot = "false";
			args.isBonus = "false";
			args.anchorAligned = false;
			_BH.createBHObject(args)
		}
    },
};