module.exports = {
		
    name: 'Bonehead',
	id: 2401,

    execute (index, _BH) {
		if(typeof this.begin === 'undefined') {

			this.x = 0;
			this.y = 0;
			this.originx = this.pos.x;
			this.originy = this.pos.y;
			this.begin = 0;
			
			args = {};
			args.name = "";
			args.speed = 0;
			args.directioniscircle = "false";
			args.hp = this.hp;
			args.candie = "true";
			args.canbetouched = "false";
			args.deathaction = 0;
			args.isPlayerShot = "false";
			args.isBonus = "false";
			args.cantbeinstakill = "true";
			args.action = 2402;
			args.sprite = "bonepart2";
			args.offsety = -2;
			args.width = 6;
			args.height = 6;
			args.anchorx = 0;
			args.posx = this.pos.x+6*this.direction.x;
			args.posy = this.pos.y+2+6*this.direction.y;
			args.angle = this.angle;
			args.collision_angle = "angle";
			args.collision_scalex = "scale";
			args.collision_scaley = "scale";
			args.direction = this.angle-270;
			args.scalex = this.hp;
			args.anchorAligned = false;
			args.damage = this.damage;
			args.motionblurFrames = this.motionblurFrames;
			this.bone = _BH.createBHObject(args)
			
		}
		
		this.bone.angle = this.angle;
		
		this.bone.changeDirection(this.angle-270,false);
		this.bone.pos.x = this.pos.x+6*this.bone.direction.x;
		this.bone.pos.y = this.pos.y+2+6*this.bone.direction.y;
		this.bone.scale.x = this.hp;
		
		if (this.hp <= 0) this.bone.hp = 0;

    },
};