module.exports = {
		
    name: 'Bone End',
	id: 2403,

    execute (index, _BH) {
		

    },
};