//=============================================================================
// RPG Maker MZ - ItemsMoreMetas
//=============================================================================

/*:
 * @target MZ
 * @plugindesc Items More Metas system plugin.
 * @author Feather
 *
 * @help 
 * Items More Metas system plugin.
 *
 */
 

(() => {
    const pluginName = "ItemsMoreMetas";
	
	
	
	___FeatherIMM___Game_Actor_changeEquip = Game_Actor.prototype.changeEquip
	Game_Actor.prototype.changeEquip = function(slotId, item) {
		if (item && item.meta.Ascension) {
			this.addState(84);
		};
		___FeatherIMM___Game_Actor_changeEquip.call(this, slotId, item)
		if (!this.armors().some(item => item.meta.Ascension)) {
			this.removeState(84)
		};
	};
	
	___FeatherIMM___Game_Action_makeTargets = Game_Action.prototype.makeTargets
	Game_Action.prototype.makeTargets = function() {
		targets = ___FeatherIMM___Game_Action_makeTargets.call(this);
		const subject = this.subject();
		const item = this.item();
		if (item.meta.damageYourself || (subject._equips && $dataWeapons[subject._equips[0]._itemId] && $dataWeapons[subject._equips[0]._itemId].meta.damageYourself && !targets.includes(subject))) {
			targets.push(subject)
		}
		return targets;
	};
	
	
	___FeatherIMM___Game_Action_executeHpDamage = Game_Action.prototype.executeHpDamage;
	Game_Action.prototype.executeHpDamage = function(target, value) {
		if (target.armors && target.armors().some(item => item.meta.DeathCounter) && target.hp > 1) {

			value = Math.min(target.hp-1, value);
		}
		___FeatherIMM___Game_Action_executeHpDamage.call(this,target,value);
	};
	
	
	___FeatherIMM___Game_Action_isDrain = Game_Action.prototype.isDrain;
	Game_Action.prototype.isDrain = function() {
		return ___FeatherIMM___Game_Action_isDrain.call(this) || this.isDrainHP();
	};
	
	
	

	Game_Action.prototype.isDrainHP = function() {
		try {
			return ($dataWeapons[$gameActors.actor(this._subjectActorId)._equips[0]._itemId].meta.DrainHP && this._item._itemId == 1 && this._item._dataClass == "skill");
		} 
		catch (error) {
			return false;
		}
	}	
		
	Game_Action.prototype.isDrainMP = function() {
		try {
			return ($dataWeapons[$gameActors.actor(this._subjectActorId)._equips[0]._itemId].meta.DrainMP && this._item._itemId == 1 && this._item._dataClass == "skill");
		} 
		catch (error) {
			return false;
		}
	}

	Game_Action.prototype.isHpEffect = function() {
		
		return (this.item() && (this.checkDamageType([1, 3, 5]) || this.isDrainHP()));
		
	};

	Game_Action.prototype.isMpEffect = function() {

		return (this.item() && (this.checkDamageType([2, 4, 6]) || this.isDrainMP()));

	};

	___FeatherIMM___Game_Battler_consumeItem = Game_Battler.prototype.consumeItem;
	Game_Battler.prototype.consumeItem = function(item) {
		if (item.meta.gainItem) $gameParty.gainItem($dataItems[item.meta.gainItem.trim()], 1);
		___FeatherIMM___Game_Battler_consumeItem.call(this, item);
	};

})();
