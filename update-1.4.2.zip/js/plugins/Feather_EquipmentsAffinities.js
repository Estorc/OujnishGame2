//=============================================================================
// RPG Maker MZ - EquipmentsAffinities
//=============================================================================

/*:
 * @target MZ
 * @plugindesc Equipments Affinities system plugin.
 * @author Feather
 *
 * @help 
 * Equipments Affinities system plugin.
 *
 * @param ArmorTypesAffinities:arraystruct
 * @text Equipment Types Affinities
 * @type struct<Affinities>[]
 * @desc Settings for Equipment Types Affinities.
 * @default []
 *
 */
 /*~struct~Affinities:
 *
 * @param tagname:str
 * @text Tag Name
 * @desc Tag Name of the affinity.
 * @default Untitled Affinity
 *
 * @param armortypes:number[]
 * @text Types ID
 * @desc Types ID of equipment affected by the affinity.
 * @type number[]
 * @default []
 *
 * @param params:struct
 * @text Parameters Multipliers
 * @type struct<Parameters>
 * @desc Parameters Multipliers.
 * @default {"mhp:number":"1.00","mmp:number":"1.00","atk:number":"1.00","def:number":"1.00","mat:number":"1.00","mdf:number":"1.00","agi:number":"1.00","luk:number":"1.00"}
 *
 * @param xparams:struct
 * @text EX Parameters Increment
 * @type struct<XParameters>
 * @desc EX Parameters Increment.
 * @default {"hit:number":"0.00","eva:number":"0.00","cri:number":"0.00","cev:number":"0.00","mev:number":"0.00","mrf:number":"0.00","cnt:number":"0.00","hrg:number":"0.00","mrg:number":"0.00","trg:number":"0.00"}
 *
 * @param sparams:struct
 * @text SP Parameters Multipliers
 * @type struct<SParameters>
 * @desc SP Parameters Multipliers.
 * @default {"trg:number":"1.00","grd:number":"1.00","rec:number":"1.00","pha:number":"1.00","mcr:number":"1.00","tcr:number":"1.00","pdr:number":"1.00","mdr:number":"1.00","fdr:number":"1.00","exr:number":"1.00"}
 *
 */
 /*~struct~Parameters:
 *
 * @param mhp:number
 * @text MHP Multiplier
 * @desc Maximum Hit Points Multiplier.
 * @decimals 2
 * @type number
 * @max 10.00
 * @default 1.00
 *
 * @param mmp:number
 * @text MMP Multiplier
 * @desc Maximum Magic Points Multiplier.
 * @decimals 2
 * @type number
 * @max 10.00
 * @default 1.00
 *
 * @param atk:number
 * @text ATK Multiplier
 * @desc ATtacK power Multiplier.
 * @decimals 2
 * @type number
 * @max 10.00
 * @default 1.00
 *
 * @param def:number
 * @text DEF Multiplier
 * @desc DEFense power Multiplier.
 * @decimals 2
 * @type number
 * @max 10.00
 * @default 1.00
 *
 * @param mat:number
 * @text MAT Multiplier
 * @desc Magic ATtack power Multiplier.
 * @decimals 2
 * @type number
 * @max 10.00
 * @default 1.00
 *
 * @param mdf:number
 * @text MDF Multiplier
 * @desc Magic DeFense power Multiplier.
 * @decimals 2
 * @type number
 * @max 10.00
 * @default 1.00
 *
 * @param agi:number
 * @text AGI Multiplier
 * @desc AGIlity Multiplier.
 * @decimals 2
 * @type number
 * @max 10.00
 * @default 1.00
 *
 * @param luk:number
 * @text LUK Multiplier
 * @desc LUcK Multiplier.
 * @decimals 2
 * @type number
 * @max 10.00
 * @default 1.00
 *
 */
 /*~struct~XParameters:
 *
 * @param hit:number
 * @text HIT Increment
 * @desc HIT rate Increment.
 * @decimals 2
 * @type number
 * @min -10.00
 * @max 10.00
 * @default 0.00
 *
 * @param eva:number
 * @text EVA Increment
 * @desc EVAsion rate Increment.
 * @decimals 2
 * @type number
 * @min -10.00
 * @max 10.00
 * @default 0.00
 *
 * @param cri:number
 * @text CRI Increment
 * @desc CRItical rate Increment.
 * @decimals 2
 * @type number
 * @min -10.00
 * @max 10.00
 * @default 0.00
 *
 * @param cev:number
 * @text CEV Increment
 * @desc Critical EVasion rate Increment.
 * @decimals 2
 * @type number
 * @min -10.00
 * @max 10.00
 * @default 0.00
 *
 * @param mev:number
 * @text MEV Increment
 * @desc Magic EVasion rate Increment.
 * @decimals 2
 * @type number
 * @min -10.00
 * @max 10.00
 * @default 0.00
 *
 * @param mrf:number
 * @text MRF Increment
 * @desc Magic ReFlection rate Increment.
 * @decimals 2
 * @type number
 * @min -10.00
 * @max 10.00
 * @default 0.00
 *
 * @param cnt:number
 * @text CNT Increment
 * @desc CouNTer attack rate Increment.
 * @decimals 2
 * @type number
 * @min -10.00
 * @max 10.00
 * @default 0.00
 *
 * @param hrg:number
 * @text HRG Increment
 * @desc Hp ReGeneration rate Increment.
 * @decimals 2
 * @type number
 * @min -10.00
 * @max 10.00
 * @default 0.00
 *
 * @param mrg:number
 * @text MRG Increment
 * @desc Mp ReGeneration rate Increment.
 * @decimals 2
 * @type number
 * @min -10.00
 * @max 10.00
 * @default 0.00
 *
 * @param trg:number
 * @text TRG Increment
 * @desc Tp ReGeneration rate Increment.
 * @decimals 2
 * @type number
 * @min -10.00
 * @max 10.00
 * @default 0.00
 *
 */
 /*~struct~SParameters:
 *
 * @param trg:number
 * @text TRG Multiplier
 * @desc TarGet rate Multiplier.
 * @decimals 2
 * @type number
 * @max 10.00
 * @default 1.00
 *
 * @param grd:number
 * @text GRD Multiplier
 * @desc GuaRD effect rate Multiplier.
 * @decimals 2
 * @type number
 * @max 10.00
 * @default 1.00
 *
 * @param rec:number
 * @text REC Multiplier
 * @desc RECovery effect rate Multiplier.
 * @decimals 2
 * @type number
 * @max 10.00
 * @default 1.00
 *
 * @param pha:number
 * @text PHA Multiplier
 * @desc PHArmacology Multiplier.
 * @decimals 2
 * @type number
 * @max 10.00
 * @default 1.00
 *
 * @param mcr:number
 * @text MCR Multiplier
 * @desc Mp Cost rate Multiplier.
 * @decimals 2
 * @type number
 * @max 10.00
 * @default 1.00
 *
 * @param tcr:number
 * @text TCR Multiplier
 * @desc Tp Charge rate Multiplier.
 * @decimals 2
 * @type number
 * @max 10.00
 * @default 1.00
 *
 * @param pdr:number
 * @text PDR Multiplier
 * @desc Physical Damage rate Multiplier.
 * @decimals 2
 * @type number
 * @max 10.00
 * @default 1.00
 *
 * @param mdr:number
 * @text MDR Multiplier
 * @desc Magic Damage rate Multiplier.
 * @decimals 2
 * @type number
 * @max 10.00
 * @default 1.00
 *
 * @param fdr:number
 * @text FDR Multiplier
 * @desc Floor Damage rate Multiplier.
 * @decimals 2
 * @type number
 * @max 10.00
 * @default 1.00
 *
 * @param exr:number
 * @text EXR Multiplier
 * @desc EXperience Rate Multiplier.
 * @decimals 2
 * @type number
 * @max 10.00
 * @default 1.00
 *
 */
 

(() => {
	'use strict'
    const pluginName = "Feather_EquipmentsAffinities";
	
	//-----------------------------------------------------------------------------
	// Feather_EquipmentsAffinities
	//
	// The main class of Feather Equipments Affinities.
	
	
	function Feather_EquipmentsAffinities() {
		throw new Error("This is a static class");
	};
	
	Feather_EquipmentsAffinities.initialize = function() {
		Object.assign(this, Feather_Core.loadPluginParameters(PluginManager.parameters(pluginName)));
		this.ArmorTypesAffinities.forEach(item => {
			item.paramArray = [];
			for (let id in item.params) {
				item.paramArray.push(item.params[id]);
			}
			item.xparamArray = [];
			for (let id in item.xparams) {
				item.xparamArray.push(item.xparams[id]);
			}
			item.sparamArray = [];
			for (let id in item.sparams) {
				item.sparamArray.push(item.sparams[id]);
			}
		},this);
	}
	
	Feather_EquipmentsAffinities.initialize();
	
	Game_Actor.prototype.armorAffinityParam = function(affinity) {
		let traits = [];
		
		if (this._lastArmorAffinityConfig && [this._level].concat(this._equips) === this._lastArmorAffinityConfig) {
			return this._lastArmorAffinityTraits || [];
		}
		for (const item of this.equips().filter(a => a && a.atypeId && affinity.armortypes.includes(a.atypeId))) {
			for (let i in affinity.paramArray)
				if (affinity.paramArray[i] !== 1) traits.push({code:Game_BattlerBase.TRAIT_PARAM,dataId:eval(i),value:affinity.paramArray[i]});
			for (let i in affinity.xparamArray)
				if (affinity.xparamArray[i]) traits.push({code:Game_BattlerBase.TRAIT_XPARAM,dataId:eval(i),value:affinity.xparamArray[i]});
			for (let i in affinity.sparamArray)
				if (affinity.sparamArray[i] !== 1) traits.push({code:Game_BattlerBase.STRAIT_SPARAM,dataId:eval(i),value:affinity.sparamArray[i]});
		}
		this._lastArmorAffinityConfig = [this._level].concat(this._equips);
		this._lastArmorAffinityTraits = traits;
		return traits;
	}
	
	let ___FeatherEA___Game_Actor_allTraits = Game_Actor.prototype.allTraits;
	Game_Actor.prototype.allTraits = function() {
		return ___FeatherEA___Game_Actor_allTraits.call(this)
		.concat(this.actor().metaArray.EquipmentAffinity && this.actor().metaArray.EquipmentAffinity.reduce((a,b) => {
			return a.concat(this.armorAffinityParam(Feather_EquipmentsAffinities.ArmorTypesAffinities.find(item => item.tagname === b.trim())));
		}, []) || [])
		.concat(this.currentClass().metaArray.EquipmentAffinity && this.currentClass().metaArray.EquipmentAffinity.reduce((a,b) => {
			return a.concat(this.armorAffinityParam(Feather_EquipmentsAffinities.ArmorTypesAffinities.find(item => item.tagname === b.trim())));
		}, []) || []);
	};
	
})();
