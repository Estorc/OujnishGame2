//=============================================================================
// RPG Maker MZ - Quests
//=============================================================================

/*:
 * @target MZ
 * @plugindesc Quests system plugin.
 * @author Feather
 *
 * @help 
 * Quests system plugin.
 *
 * @command addCompletedQuest
 * @text Complete Quest
 * @desc Save the ID of the finished quest in a array.
 *
 * @arg id
 * @type string
 * @text ID
 * @desc ID to Save.
 */
 

(() => {
    const pluginName = "Feather_Quests";
	
	QUEST_PROPOSED_TEXT = "Une quête vous est proposée. Souhaitez-vous\nessayer de la réaliser ?";
	QUESTS_FULL_TEXT = "<center>Vous avez déjà 3 quêtes actives !</center>\n<center>Souhaitez-vous en remplacer une ?</center>";
	ASK_FOR_REPLACE_TEXT = "Laquelle souhaitez-vous remplacer ?";
	UNCANCELLABLE_QUEST_TEXT = "<center>Cette quête ne peut être remplacée...</center>";
	YES_CHOICE_TEXT = "Oui";
	NO_CHOICE_TEXT = "Non";
	CANCEL_CHOICE_TEXT = "Aucune finalement";
	let ___FeatherQ____choiceListWindow_callOkHandler;
	let ___FeatherQ____choiceListWindow_callCancelHandler;
	
	
    PluginManager.registerCommand(pluginName, "addCompletedQuest", args => {
	
		
		FeatherQuests.addCompletedQuest(eval(args.id));
		

    });
	
	
	//-----------------------------------------------------------------------------
	// FeatherQuests
	//
	// The class of the Feather's Quests.
	
	
	FeatherQuests = function() {
		throw new Error("This is a static class");
	};
	
	
	FeatherQuests._activeQuests = [];
	FeatherQuests._completedQuests = [];
	FeatherQuests._actionSuccess = false;
	FeatherQuests._isRunning = false;
	
	
	FeatherQuests.maxQuests = function() {
		
		return 3;
		
	};
	
	
	FeatherQuests.isRunning = function() {
		
		return this._isRunning;
		
	};
	
	
	FeatherQuests.toggleRunning = function() {
		
		this._isRunning = !this._isRunning;
		
	}
	
	
	FeatherQuests.getCompletedQuest = function(id) {
		
		return this._completedQuests.includes(id);
		
	};
	
	
	FeatherQuests.addCompletedQuest = function(id) {
		
		this._completedQuests.push(id);
		
	};
	
	
	FeatherQuests.toggleChoiceListStyle = function() {
		
		if (!___FeatherQ____choiceListWindow_callOkHandler) {
			___FeatherQ____choiceListWindow_callOkHandler = SceneManager._scene._choiceListWindow.callOkHandler;
			___FeatherQ____choiceListWindow_callCancelHandler = SceneManager._scene._choiceListWindow.callCancelHandler;
			SceneManager._scene._choiceListWindow.callOkHandler = function () {
				let tempCallback = $gameMessage._choiceCallback;				
				this._messageWindow.terminateMessage();
				this.close();
				tempCallback(this.index());
				FeatherQuests.toggleChoiceListStyle();
			}
			SceneManager._scene._choiceListWindow.callCancelHandler = function () {
				let tempCallback = $gameMessage._choiceCallback;	
				this._messageWindow.terminateMessage();
				this.close();
				tempCallback(1);
				FeatherQuests.toggleChoiceListStyle();
			}
		} else {
			SceneManager._scene._choiceListWindow.callOkHandler = ___FeatherQ____choiceListWindow_callOkHandler;
			SceneManager._scene._choiceListWindow.callCancelHandler = ___FeatherQ____choiceListWindow_callCancelHandler;
			___FeatherQ____choiceListWindow_callOkHandler = null;
			___FeatherQ____choiceListWindow_callCancelHandler = null;
		}
		
	};
	
	
	FeatherQuests.askForContinue = function(text,callback,...arguments) {
		
		FeatherQuests.toggleChoiceListStyle();
		$gameMessage.add(text);
		$gameMessage.setChoices([YES_CHOICE_TEXT,NO_CHOICE_TEXT], 0, 1);
		$gameMessage.setChoiceBackground(0);
		$gameMessage.setChoicePositionType(2);
		$gameMessage.setChoiceCallback(n => {
			if (n == 0) return callback(...arguments);
			FeatherQuests.toggleRunning();
		});
		
	};
	
	
	FeatherQuests.isFull = function() {
		
		return this._activeQuests.length >= this.maxQuests();
		
	};
	
	
	FeatherQuests.hasQuestByID = function(id) {
		
		return this._activeQuests.some(a => a._id == id);
		
	};
	
	
	FeatherQuests.getQuestByID = function(id) {
		
		if (this.hasQuestByID(id)) {
			return this._activeQuests.find(a => a._id == id);
		}
		
	};
	
	
	FeatherQuests.getQuestValueByID = function(id) {
		
		if (this.hasQuestByID(id)) {
			return this.getQuestByID(id).getValue();
		}
		
	};
	
	
	FeatherQuests.proposeQuest = function(quest,callback = function(){}) {
		
		this._actionSuccess = false;
		this._isRunning = true;
		callback();
		this.askForContinue(QUEST_PROPOSED_TEXT,this.addQuest,quest,callback)
		
	};
	
	
	FeatherQuests.addQuest = function(quest,callback = function(){}) {
		
		if (!FeatherQuests.hasQuestByID(quest._id)) {
			
			if (!FeatherQuests.isFull()) {
				 
				 FeatherQuests._activeQuests.push(quest);
				 FeatherQuests._actionSuccess = true;
				 callback();
				 return FeatherQuests.toggleRunning();
				 
			} else {
				
				FeatherQuests.askForContinue(QUESTS_FULL_TEXT,FeatherQuests.askForReplaceQuest,quest,callback);
				return 0;
				
			}
			
		}
		
		return FeatherQuests.toggleRunning();
		
	};
	
	
	FeatherQuests.askForReplaceQuest = function(quest,callback) {
		
		FeatherQuests.toggleChoiceListStyle();
		$gameMessage.add(ASK_FOR_REPLACE_TEXT);
		$gameMessage.setChoices(FeatherQuests._activeQuests.map(a => a.getDesc()).concat(CANCEL_CHOICE_TEXT), 0, 1);
		$gameMessage.setChoiceBackground(0);
		$gameMessage.setChoicePositionType(2);
		$gameMessage.setChoiceCallback(n => {
			if (n < FeatherQuests._activeQuests.length) return FeatherQuests.replaceQuest(quest,callback,n);
			FeatherQuests.toggleRunning();
		});
		
	};
	
	
	FeatherQuests.replaceQuest = function(quest,callback,id) {
		
		if (FeatherQuests._activeQuests[id].isCancellable()) {
			
			FeatherQuests._activeQuests[id].onCancel();
			FeatherQuests._activeQuests[id] = quest;
			FeatherQuests._actionSuccess = true;
			callback();
			
		} else {
			
			$gameMessage.add(UNCANCELLABLE_QUEST_TEXT);
		
		}
		
		FeatherQuests.toggleRunning();
		
	};
	
	
	//-----------------------------------------------------------------------------
	// Feather_Quest
	//
	// The class of Feather's Quest.


	Feather_Quest = function() {
		this.initialize(...arguments);	
	};


	Feather_Quest.prototype.initialize = function(id,desc,value,max,cancellable) {		

		this._id = id;
		this._desc = desc;
		this._max = max;
		this._value = value;
		this._cancellable = cancellable;

	};
	
	
	Feather_Quest.prototype.toggleCancellable = function() {
		
		this._cancellable = !this._cancellable;
		
	};
	
	
	Feather_Quest.prototype.destroy = function() {
		
		FeatherQuests._activeQuests.splice(FeatherQuests._activeQuests.indexOf(this),1);
		
	};
	
	
	Feather_Quest.prototype.onCancel = function() {
		
		//
		
	};
	
	
	Feather_Quest.prototype.setValue = function(value) {
		
		this._value = value;
		
	}
	
	
	Feather_Quest.prototype.getDesc = function() {
		
		return this._desc;
		
	};
	
	
	Feather_Quest.prototype.getMax = function() {
		
		return this._max;
		
	};
	
	
	Feather_Quest.prototype.getValue = function() {
		
		return this._value;
		
	};
	
	
	Feather_Quest.prototype.isCancellable = function() {
		
		return this._cancellable;
		
	};
	
	
	//-----------------------------------------------------------------------------
	// Window_Quest
	//
	// The window for displaying the party's quests.
	

	function Window_Quest() {
		this.initialize(...arguments);
	}

	Window_Quest.prototype = Object.create(Window_Selectable.prototype);
	Window_Quest.prototype.constructor = Window_Quest;

	Window_Quest.prototype.initialize = function(rect) {
		Window_Selectable.prototype.initialize.call(this, rect);
		this.refresh();
		this.openness = 0;
		this._disappearTimer = 0;
	};

	Window_Quest.prototype.colSpacing = function() {
		return 0;
	};

	Window_Quest.prototype.refresh = function() {
		const numQuests = FeatherQuests._activeQuests.length;
		if (numQuests != this.lastNumQuests) {
		this.height = Window_Selectable.prototype.fittingHeight(2+numQuests);
		this.contents.resize(this.contentsWidth(),this.contentsHeight());
		}
		this.contents.clear();
		let rect = this.itemLineRect(0);
		this.changeTextColor(ColorManager.textColor(14));
		this.drawText("Quêtes", rect.x, rect.y, rect.width, "center");
		rect = this.itemLineRect(1);
		this.changeTextColor(ColorManager.textColor(24));
		this.drawText("___________________________", rect.x, rect.y, rect.width, "center")
		for (const quest of FeatherQuests._activeQuests) {
			
			rect = this.itemLineRect(FeatherQuests._activeQuests.indexOf(quest) + 2);
			this.changeTextColor(ColorManager.textColor(14));
			let text = quest.getValue().toString() + "/" + quest.getMax().toString();
			this.drawText(text, rect.x, rect.y, rect.width, "right");
			rect.width -= this.textWidth(text) + 10;
			this.changeTextColor(ColorManager.textColor(0));
			text = quest.getDesc() + ":";
			this.drawText(text, rect.x, rect.y, rect.width, "left");
			
		}
		
		this.lastNumQuests = numQuests;
	};

	Window_Quest.prototype.open = function() {
		this.refresh();
		Window_Selectable.prototype.open.call(this);
	};
	
	
	//-----------------------------------------------------------------------------
	// Classes Rewrite
	//


	___FeatherQ___DataManager_makeSaveContents = DataManager.makeSaveContents;
	DataManager.makeSaveContents = function() {
		const contents = ___FeatherQ___DataManager_makeSaveContents.call(this);
		contents.feather_activeQuests = FeatherQuests._activeQuests;
		contents.feather_completedQuests = FeatherQuests._completedQuests;
		return contents;
	};
	

	___FeatherQ___DataManager_extractSaveContents = DataManager.extractSaveContents;
	DataManager.extractSaveContents = function(contents) {
		___FeatherQ___DataManager_extractSaveContents.call(this,contents);
		if (contents.feather_activeQuests && contents.feather_completedQuests) {
			FeatherQuests._activeQuests = contents.feather_activeQuests;
			FeatherQuests._completedQuests = contents.feather_completedQuests;
		}
	};
	
	
	___FeatherQ___Scene_Map_createAllWindows = Scene_Map.prototype.createAllWindows;
	Scene_Map.prototype.createAllWindows = function() {
		___FeatherQ___Scene_Map_createAllWindows.call(this);
		this.createQuestWindow();
	};
	
	
	___FeatherQ___Scene_Map_update = Scene_Map.prototype.update;
	Scene_Map.prototype.update = function() {
		___FeatherQ___Scene_Map_update.call(this);
		this.updateQuestWindow();
	};
	
	
	Scene_Map.prototype.updateQuestWindow = function() {
		if (FeatherQuests._activeQuests.length === 0 || $gameMessage.isBusy() || !$gamePlayer.canMove() || $gameBulletHell.active || !ConfigManager['showQuestsInProgress'] || $gamePlayer.isMoving()) {
			if (!this._questWindow.isClosed()) {
				this._questWindow.close();
			}
			this._questWindow._disappearTimer = 0;
		} else {
			if (this._questWindow._disappearTimer > 30 && this._questWindow.isClosed()) {
				this._questWindow.open();
			} else {
				this._questWindow._disappearTimer++;
			}
		}
	};
	
	
	Scene_Map.prototype.createQuestWindow = function() {
		const rect = this.questWindowRect();
		this._questWindow = new Window_Quest(rect);
		this.addWindow(this._questWindow);
	};
	

	Scene_Map.prototype.questWindowRect = function() {
		const wx = 0;
		const wy = 0;
		const ww = 400;
		const wh = this.calcWindowHeight(1, true);
		return new Rectangle(wx, wy, ww, wh);
	};

})();
