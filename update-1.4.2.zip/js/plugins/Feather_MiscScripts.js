//=============================================================================
// RPG Maker MZ - MiscScripts
//=============================================================================

/*:
 * @target MZ
 * @plugindesc MiscScripts.
 * @author Feather
 *
 * @help 
 * MiscScripts.
 *
 */
 

(() => {
    const pluginName = "MiscScripts";
 
 
	Sprite_Enemy.prototype.damageOffsetY = function() {
		return Sprite_Battler.prototype.damageOffsetY.call(this) - this.height/4;
	};
	
	Sprite_EnemyName.prototype.updatePosition = function(){
		if (!this._linkedSprite) return;
		this._lineHeight = this._lineHeight || Window_Base.prototype.lineHeight();
		this.x = this._linkedSprite._baseX + eval(this._linkedSprite._battler.enemy().meta["Battle Name OffsetX"] || 0);
		this.y = this._linkedSprite._baseY - this._lineHeight * 0.5 + eval(this._linkedSprite._battler.enemy().meta["Battle Name OffsetY"] || 0);
		const enemyOpt = VisuMZ.BattleCore.Settings.Enemy;
		this.x += enemyOpt.NameOffsetX || 0x0, this.y += -this._linkedSprite.height + (enemyOpt.NameOffsetY || 0x0);
	}

		
	___FeatherMS___Game_Action_makeDamageValue = Game_Action.prototype.makeDamageValue;
	Game_Action.prototype.makeDamageValue = function(target, critical) {
		let value = 1;
		
		if (this.ppgDamage) {
			value = this.ppgDamage;
			this.item().damage.formula = "1";
			value *= ___FeatherMS___Game_Action_makeDamageValue.call(this,target,critical);
			this.item().damage.formula = "";
		} else {
			
			value *= ___FeatherMS___Game_Action_makeDamageValue.call(this,target,critical);
			
		}
		return value;
		
	};
	
	
	___FeatherMS___Window_SkillList_drawItem = Window_SkillList.prototype.drawItem;
	Window_SkillList.prototype.drawItem = function(index) {
		const skill = this.itemAt(index);
		skill.meta.NameSize && (this.contents.fontSize = eval(skill.meta.NameSize));
		___FeatherMS___Window_SkillList_drawItem.call(this,index);
		this.contents.fontSize = $gameSystem.mainFontSize();
	};
	
	
	
	StorageManager.jsonToZip = function(json) {
		return new Promise((resolve, reject) => {
			try {
				const zip = pako.deflate(json, { to: "string", level: 1 });
				if (zip.length >= 500000) {
					console.warn("Save data is too big.");
				}
				resolve(zip);
			} catch (e) {
				reject(e);
			}
		});
	};
	
	
	___FeatherMS___CGMZ_Scene_Achievements_initialize = CGMZ_Scene_Achievements.prototype.initialize
	CGMZ_Scene_Achievements.prototype.initialize = function() {
		___FeatherMS___CGMZ_Scene_Achievements_initialize.call(this);
		$cgmz._achievements.forEach(a => a._isActive = FeatherQuests.hasQuestByID(a._id));
	};
	
	
	
	FeatherQuests.maxQuests = function() {
		
		return $cgmz.getProfession("Héros")._level*3;
		
	};

	
	
	___FeatherMS___Game_Enemy_performCollapse = Game_Enemy.prototype.performCollapse;
	Game_Enemy.prototype.performCollapse = function() {
		___FeatherMS___Game_Enemy_performCollapse.call(this);
		$cgmz.changeProfessionExp('Chasseur','+', 1);
		$gameParty.incrementKillCounter(this._enemyId);
	}
	
	
	

	
	
	___FeatherMS___BattleManager_playBattleBgm = BattleManager.playBattleBgm;
	BattleManager.playBattleBgm = function() {
		___FeatherMS___BattleManager_playBattleBgm.call(this);
		if ($gameParty.leader().hasWeapon($dataWeapons[505])) {
			
			AudioManager.playBgm({name: "legendaryshortsword", pan: 0, pitch: 100, volume: 100});
			
		}
	};
	
	
	___FeatherSMM___Game_Action_executeHpDamage = Game_Action.prototype.executeHpDamage;
	Game_Action.prototype.executeHpDamage = function(target, value) {
		if (ConfigManager[_0x48a899(0x1fe)]) {
			value = target.hp;
		}
		___FeatherSMM___Game_Action_executeHpDamage.call(this,target,value);
	};
	
	
	___FeatherSMM___Scene_Boot_loadGameFonts = Scene_Boot.prototype.loadGameFonts
	Scene_Boot.prototype.loadGameFonts = function() {
		___FeatherSMM___Scene_Boot_loadGameFonts.call(this);
		FontManager.load("kk-lyricsfont", "PersonifiedUXRegular.ttf");
	};
		
		
	Game_CharacterBase.prototype.hasStepAnime = function() {
		return (this._stepAnime || (this._characterIndex == 4 && this._characterName == "BigFanta"));
	};

	Game_CharacterBase.prototype.isThrough = function() {
		return (this._through || (this._characterIndex == 4 && this._characterName == "BigFanta"));
	};


	___FeatherSMM___Game_Follower_update = Game_Follower.prototype.update
	Game_Follower.prototype.update = function() {
		___FeatherSMM___Game_Follower_update.call(this);
		this.setStepAnime($gamePlayer._stepAnime);
	};
	

})();
