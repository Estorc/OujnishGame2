//=============================================================================
// RPG Maker MZ - InfernalMode
//=============================================================================

/*:
 * @target MZ
 * @plugindesc Infernal Mode system plugin.
 * @author Feather
 *
 * @help 
 * Infernal Mode system plugin.
 *
 */
 

(() => {
    const pluginName = "InfernalMode";
	
	
	
	
	/*Game_Action.prototype.makeDamageValue = function(target, critical) {
		const result = target.result();
		const item = this.item();
		const baseValue = this.evalDamageFormula(target);
		let value = baseValue * this.calcElementRate(target);
		
		
		if (typeof this.subject().armors !== 'undefined' && this.subject().armors().includes($dataArmors[1027])) {
			if (!this.subject().criticalForced) {
				
				result.critical = true;
				value *= 2;
				
			} else {
				
				result.critical = false;
				value *= 0.5;
				
			}
		}
		
		if (this.isPhysical()) {
			value *= target.pdr;
		}
		if (this.isMagical()) {
			value *= target.mdr;
		}
		if (baseValue < 0) {
			value *= target.rec;
		}
		if (result.critical) {
			value = this.applyCritical(value);
		}
		
		if (this.ppgDamage) {
			value = this.ppgDamage;
		}
		
		value = this.applyVariance(value, item.damage.variance);
		value = this.applyGuard(value, target);
		value = Math.round(value);
		return value;
	};*/
	
	
	___FeatherIM___Game_Action_makeDamageValue = Game_Action.prototype.makeDamageValue;
	Game_Action.prototype.makeDamageValue = function(target, critical) {
		const result = target.result();
		const item = this.item();
		let value = 1;
		
		
		if (this.subject().armors && this.subject().armors().some(item => item.meta.NoLuckCritics)) {
			critical = false;
			if (!this.subject().criticalForced) {
				
				critical = true;
				value *= 2;
				
			} else {
				
				critical = false;
				value *= 0.5;
				
			}
		}

		return value * ___FeatherIM___Game_Action_makeDamageValue.call(this,target,critical);
	};
	
	
	
	
	
	
	
	___FeatherIM___BattleManager_processTurn = BattleManager.processTurn
	BattleManager.processTurn = function() {
		this._subject.criticalForced = false;
		this._subject.infernalParams = false;
		
		if (this._subject.currentAction() && (this._subject.currentAction().isHpEffect() || this._subject.currentAction().isMpEffect()) && typeof this._subject.armors !== 'undefined' && this._subject.armors().some(item => item.meta.NoLuckCritics)) {
			
			
			if ($gameMap.getQTEResult() === "pending") {
			
				$gameMap.QTE(["normal"],350,$createQTEinRange(20),true)
				
			}
			
			if ($gameMap.getQTEResult() !== "start") {
				
				if ($gameMap.getQTEResult() !== "success") {
					this._subject.criticalForced = true;
				}				
				
				return ___FeatherIM___BattleManager_processTurn.call(this);
				
			}
			
			return 0;
		}
		
		if (typeof this._subject._enemyId !== 'undefined' && this._subject.currentAction() && (this._subject.currentAction().isHpEffect() || this._subject.currentAction().isMpEffect()) && $gameSwitches.value(1100)) {
			
			
			if ($gameMap.getQTEResult() === "pending") {
			
			
				let range = Math.min(22,(this._subject.param(2)/80) << 0);
				if (range == 0) {
					SceneManager._scene._QTEWindow.result = "success";
				} else {
					$gameMap.QTE(["infernal"],350,$createQTEinRange(range),true)
				}
				
			}
			
			if ($gameMap.getQTEResult() !== "start") {
				
				if ($gameMap.getQTEResult() === "success") {
					this._subject.infernalParams = true;
				}				
				
				___FeatherIM___BattleManager_processTurn.call(this);
				
			}
			
			return 0;
			
		}
		
		return ___FeatherIM___BattleManager_processTurn.call(this);
		
	};

})();
