//==============================================================================
// Kill Counter
// by Shaz
// Last Updated: 2016.02.15
//==============================================================================

/*:
 * @plugindesc Allows you to track number of enemies killed
 * @author Shaz
 * @target MZ
 *
 * @help
 * This plugin allows you to track, in a variable, the number of a certain
 * type of enemy killed.  It only increments to the maximum number of enemies
 * required.
 *
 * @command StartKillCounter
 * @text Start Kill Counter
 * @desc 
 * @arg enemyId
 * @type number
 * @text Enemy ID
 * @desc 
 * @arg questID
 * @type number
 * @text Quest ID
 * @desc 
 * @arg maxRequired
 * @type number
 * @text Max Required
 * @desc 
 *
 * @command EndKillCounter
 * @text End Kill Counter
 * @desc 
 * @arg enemyId
 * @type string
 * @text Enemy ID
 * @desc 
 *
 * Plugin Commands:
 * StartKillCounter enemyId variableId maxRequired - tracks kills in specified variable
 * EndKillCounter enemyId - stops counting kills
 *
 * enemyId - the id (no leading zeros) of the enemy to be counted
 * variableId - the id (no leading zeros) of the variable to hold the kill count
 * maxRequired - how many enemies are required, in total - default is 0, which
 *               means no limit
 */

(function() {
	const pluginName = "Kill Counter (MV)";
	
    PluginManager.registerCommand(pluginName, "StartKillCounter", args => {


        $gameParty.startKillCounter(eval(args.enemyId), eval(args.questID), eval(args.maxRequired || 0));

    });
	
	
    PluginManager.registerCommand(pluginName, "EndKillCounter", args => {
		
        $gameParty.endKillCounter(eval(args[0]));

    });
	

  var _Game_Party_initialize = Game_Party.prototype.initialize;
  Game_Party.prototype.initialize = function() {
    _Game_Party_initialize.call(this);
    this._killCounter = [];
  };

  Game_Party.prototype.startKillCounter = function(enemyId, questId, maxRequired) {
    if (!this._killCounter)
      this._killCounter = [];

    if (!maxRequired)
      maxRequired = 0;

    if (enemyId > 0)
      this._killCounter[enemyId] = [questId, maxRequired];
  };

  Game_Party.prototype.endKillCounter = function(enemyId) {
    if (this._killCounter && enemyId > 0)
      this._killCounter[enemyId] = null;
  };

  Game_Party.prototype.incrementKillCounter = function(enemyId) {
    if (this._killCounter && enemyId > 0 && this._killCounter[enemyId]) {
      killVar = this._killCounter[enemyId][0];
      killLimit = this._killCounter[enemyId][1];
      if (killVar && (killLimit === 0 || killLimit > FeatherQuests.getQuestByID(killVar).getValue()))
        FeatherQuests.getQuestByID(killVar)._value += 1;
    }
  }

})();