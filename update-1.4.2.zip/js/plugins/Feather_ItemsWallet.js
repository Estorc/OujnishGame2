//=============================================================================
// RPG Maker MZ - ItemsWallet
//=============================================================================

/*:
 * @target MZ
 * @plugindesc Items Wallet system plugin.
 * @author Feather
 *
 * @help 
 * Items Wallet system plugin.
 *
 */
 

(() => {
    const pluginName = "ItemsWallet";

	if (!DataManager.maxItemAmount) DataManager.maxItemAmount = function () {return 30};

	Game_Party.prototype.maxItems = function(item) {
		return ((this.items().some(item => item.meta.Wallet) && DataManager['maxItemAmount'](item) == 30) ? 999 : DataManager['maxItemAmount'](item));
	};
	
})();
