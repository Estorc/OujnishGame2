//=============================================================================
// RPG Maker MZ - MiscDifficult
//=============================================================================

/*:
 * @target MZ
 * @plugindesc Misc Difficulty system plugin.
 * @author Feather
 *
 * @help 
 * Misc Difficulty system plugin.
 *
 */
 

(() => {
    const pluginName = "MiscDifficulty";
	
	
	
	
	$gameBulletHell.addEventOnHit(function(damage) {
		if (!this.activeScene.karmaMode && $gameVariables.value(1000) < 4 && $gameVariables.value(1000) > 0) {
			this.player.iframes = $gameParty.battleMembers().map(item => item.def).reduce((a,b) => a + b, 0)/($gameVariables.value(1000)*10);
		} else {
			
			this.player.iframes = 1;
			
		}
		
		this.player.xp = 0;
		
		if (damage != 'oneshot') {
	
			switch ($gameVariables.value(1000)) {
				case 0:
					damage *= 75;
				break;
				case 1:
					damage *= 75;
				break;
				case 2:
					damage *= 200;
					this.player.level = Math.max(this.player.level-1,0);
				break;
				case 3:
					damage *= 250;
					this.player.level = 0;
				break;
				case 4:
					damage *= 500;
					this.player.level = 0;
				break;
				case 5:
					damage *= 99;
					this.player.level = 0;
				break;
				
			}
			
			if ($gameVariables.value(1000) == 5) {
				
				if ($gameParty.numItems($dataItems[5]) > 0) {
					
					AudioManager.playSe({name: 'Magic12', pan: 0, pitch: 100, volume: 100});
					$gameParty.loseItem($dataItems[5],damage)
					this.createPopupAtPlayerPosition('text','[Parée]',12);
					
				} else {
					
					this.getHitDamage("oneshot");
					
				}
				
				return 0;
				
			}
		
		}
		
		return damage;
		
	});
	
	
	
	
	$initDifficulty = function() {
		
		
		$difficultyWindow_ChoiceList_start = Window_ChoiceList.prototype.start
		Window_ChoiceList.prototype.start = function() {
			$difficultyWindow_ChoiceList_start.call(this)
			this.x = 900
			this.y = 450
			this.setBackgroundType(2)
		};
			
			
		$difficultyWindow_ChoiceList_processCursorMove = Window_ChoiceList.prototype.processCursorMove
		Window_ChoiceList.prototype.processCursorMove = function() {
			$difficultyWindow_ChoiceList_processCursorMove.call(this);
			if (this.index() == 0) {$gameScreen.picture(1)._opacity += 1} else $gameScreen.picture(1)._opacity -= 1;
			if (this.index() == 1) {$gameScreen.picture(2)._opacity += 1} else $gameScreen.picture(2)._opacity -= 1;
			if (this.index() == 2) {$gameScreen.picture(3)._opacity += 1} else $gameScreen.picture(3)._opacity -= 1;
			if (this.index() == 3) {$gameScreen.picture(4)._opacity += 1} else $gameScreen.picture(4)._opacity -= 1;
			$gameScreen.picture(1)._opacity = Math.min(Math.max($gameScreen.picture(1)._opacity, 0), 255);
			$gameScreen.picture(2)._opacity = Math.min(Math.max($gameScreen.picture(2)._opacity, 0), 255);
			$gameScreen.picture(3)._opacity = Math.min(Math.max($gameScreen.picture(3)._opacity, 0), 255);
			$gameScreen.picture(4)._opacity = Math.min(Math.max($gameScreen.picture(4)._opacity, 0), 255);
				
		};
		
	}


	$endDifficulty = function() {
		
		
		Window_ChoiceList.prototype.start = $difficultyWindow_ChoiceList_start;
		Window_ChoiceList.prototype.processCursorMove = $difficultyWindow_ChoiceList_processCursorMove;
		
	}
	
	
	Game_Enemy.prototype.param = function(paramId) {
		let value =
			this.paramBasePlus(paramId) *
			this.paramRate(paramId) *
			this.paramBuffRate(paramId);
			
		if (paramId == 0 || paramId == 1 || paramId == 2 || paramId == 4 || paramId == 6 || paramId == 7){
			switch ($gameVariables.value(1000)) {
				case 0:
					value = value * 1;
				break;
				case 1:
					value = value * 0.75;
				break;
				case 2:
					value = value * 1;
				break;
				case 3:
					value = value * 1.5;
				break;
				case 4:
					if ((paramId == 2 || paramId == 4) && this.infernalParams) {
						value *= 1.5;
					} else {
						value *= 2;
					}
				break;
				case 5:
					if ((paramId == 2 || paramId == 4) && this.infernalParams) {
						value *= 1.5;
					} else {
						value *= 4;
					}
				break;
			}
		}
		
		const maxValue = this.paramMax(paramId)*10;
		const minValue = this.paramMin(paramId);
		return Math.round(value.clamp(minValue, maxValue));
	};
	
	
	Game_Enemy.prototype.dropItemRate = function() {
		
		
		let difficultyDropRate;
		
			switch ($gameVariables.value(1000)) {
				case 0:
					difficultyDropRate = 0.5;
				break;
				case 1:
					difficultyDropRate = 1;
				break;
				case 2:
					difficultyDropRate = 0.5;
				break;
				case 3:
					difficultyDropRate = 0.4;
				break;
				case 4:
					difficultyDropRate = 0.33;
				break;
				case 5:
					difficultyDropRate = 0.25;
				break;
			}
		
		
		
		return $gameParty.hasDropItemDouble() ? (1+1*difficultyDropRate)*(1+difficultyDropRate*($cgmz.getProfession('Chasseur')._level/25)) : 1*(1+difficultyDropRate*($cgmz.getProfession('Chasseur')._level/25));
	};
	
})();
