//=============================================================================
// RPG Maker MZ - NightmareMode
//=============================================================================

/*:
 * @target MZ
 * @plugindesc Nightmare Mode system plugin.
 * @author Feather
 *
 * @help 
 * Nightmare Mode system plugin.
 *
 */
 

(() => {
    const pluginName = "NightmareMode";



	___FeatherNM___Game_Actor_setup = Game_Actor.prototype.setup;
	Game_Actor.prototype.setup = function(actorId) {
		___FeatherNM___Game_Actor_setup.call(this,actorId)
		if ($gameVariables.value(1000) == 5 && actorId <= 21) {
			const actor = $dataActors[actorId];
			this._name = actor.nickname
			this._nickname = actor.name
		}
	};
	
	___FeatherNM___BattleManager_playBattleBgm = BattleManager.playBattleBgm;
	BattleManager.playBattleBgm = function() {
		
		if ($gameVariables.value(1000) >= 4) {
			switch ($gameSystem.battleBgm().name) {
				
				case "Battle3":
					$gameSystem._battleBgm = {name: "RMMV_03_Battle_to_the_Max", volume: 100, pitch: 100, pan: 0}
					break;
				case "Battle8":
					$gameSystem._battleBgm = {name: "RMMV_03_The_Final_Battle", volume: 100, pitch: 100, pan: 0}
					break;
				
			}
		}
		$gameSystem.battleBgm()
		___FeatherNM___BattleManager_playBattleBgm.call(this)
	};


	___FeatherNM___Spriteset_Battle_createBattleback = Spriteset_Battle.prototype.createBattleback
	Spriteset_Battle.prototype.createBattleback = function() {
		___FeatherNM___Spriteset_Battle_createBattleback.call(this);
		if ($gameVariables.value(1000) == 4) {
			this._overlaySprite = new Sprite();
			this._overlaySprite.bitmap = ImageManager.loadPicture(".nightmareOverlay");
			this._overlaySprite.scale.x = $dataSystem.advanced.screenWidth/1280;
			this._overlaySprite.scale.y = $dataSystem.advanced.screenHeight/720;
			this._baseSprite.addChild(this._overlaySprite);
		}
		if ($gameVariables.value(1000) == 5) {
			this._overlaySprite = new Sprite();
			this._overlaySprite.bitmap = ImageManager.loadPicture(".lunaticOverlay");
			this._overlaySprite.scale.x = $dataSystem.advanced.screenWidth/1280;
			this._overlaySprite.scale.y = $dataSystem.advanced.screenHeight/720;
			this._baseSprite.addChild(this._overlaySprite);
		}
	};

	___FeatherNM___Game_Battler__removeState = Game_Battler.prototype.removeState
	Game_Battler.prototype.removeState = function(stateId) {
		if (stateId !== this.deathStateId() || $gameVariables.value(1000) < 4) {
			___FeatherNM___Game_Battler__removeState.call(this,stateId);
		}
	};


	___FeatherNM___Game_BattlerBase_recoverAll = Game_BattlerBase.prototype.recoverAll
	Game_BattlerBase.prototype.recoverAll = function() {
		___FeatherNM___Game_BattlerBase_recoverAll.call(this);
		if (this._states.includes(1)) this._hp = 0;
	};


	___FeatherNM___Game_Actor_clearStates = Game_Actor.prototype.clearStates
	Game_Actor.prototype.clearStates = function() {
		let isDead = (typeof this._states !== 'undefined' && (this._states.includes(1) || this._states.includes(54)) && $gameVariables.value(1000) >= 4);
		___FeatherNM___Game_Actor_clearStates.call(this);
		this._stateSteps = {};
		if (isDead) this.addState(1);
	};


	
})();
