//=============================================================================
// RPG Maker MZ - Events
//=============================================================================

/*:
 * @target MZ
 * @plugindesc Events system plugin.
 * @author Feather
 *
 * @help 
 * Events system plugin.
 *
 */
 

(() => {
    const pluginName = "Events";
	
	
	Game_Event.prototype.isPlayerNeighbor = function() {
		
		return (Math.abs(this._x - $gamePlayer._x) <= 1 && Math.abs(this._y - $gamePlayer._y) <= 1)
		
	}
	
	
	Game_Player.prototype.startAllNeighborsMapEvent = function(x, y, normal) {
		if (!$gameMap.isEventRunning() && $dataMap.meta && $dataMap.meta.NeighborsEvents) {
			this.startNeighborMapEvent(x-1, y, normal)
			this.startNeighborMapEvent(x+1, y, normal)
			this.startNeighborMapEvent(x, y-1, normal)
			this.startNeighborMapEvent(x, y+1, normal)
		}
	}
	
	
	Game_Player.prototype.startNeighborMapEvent = function(x, y, normal) {
		for (const event of $gameMap.eventsXy(x, y)) {
			if (
				event.event().meta.NeighborEvent
			) {
				event.start();
			}
		}
	}
	
	
	_FEvents_Game_Player_startMapEvent = Game_Player.prototype.startMapEvent
	Game_Player.prototype.startMapEvent = function(x, y, triggers, normal) {
		_FEvents_Game_Player_startMapEvent.call(this, x, y, triggers, normal)
		this.startAllNeighborsMapEvent(x, y, normal);
	};

})();
