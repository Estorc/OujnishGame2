//=============================================================================
// RPG Maker MZ - MiscFinalFormationMenu
//=============================================================================

/*:
 * @target MZ
 * @plugindesc Misc Final Formation Menu system plugin.
 * @author Feather
 *
 * @help 
 * Misc Final Formation Menu system plugin.
 *
 */
 

(() => {
    const pluginName = "MiscFinalFormationMenu";


	$waitFormationMenu = false;

	function Window_FinalFormation() {
		this.initialize(...arguments);
	}

	Window_FinalFormation.prototype = Object.create(Window_Selectable.prototype);
	Window_FinalFormation.prototype.constructor = Window_FinalFormation;

	Window_FinalFormation.prototype.initialize = function(rect) {
		Window_Selectable.prototype.initialize.call(this, rect);
		this.refresh();
	};

	Window_FinalFormation.prototype.colSpacing = function() {
		return 0;
	};

	Window_FinalFormation.prototype.refresh = function() {
		const rect = this.itemLineRect(0);
		const x = rect.x;
		const y = rect.y;
		const width = rect.width;
		this.contents.clear();
		this.contents.fontSize = 60;
		this.drawText("Choisissez votre ultime formation !", x, y+18, width, "center");
	};

	Window_FinalFormation.prototype.open = function() {
		this.refresh();
		Window_Selectable.prototype.open.call(this);
	};

	___FeatherMFFM___Scene_Menu_create = Scene_Menu.prototype.create;
	Scene_Menu.prototype.create = function() {
		___FeatherMFFM___Scene_Menu_create.call(this);
		if ($waitFormationMenu) {
			$waitFormationMenu = false;
			this._commandWindow.hide();
			this._goldWindow.hide();
			this._playtimeWindow.hide();
			this._dummyWindow.hide();
			this._statusWindow.height = 550;
			this._statusWindow.innerHeight = 520;
			const rect = this.commandWindowRect();
			this._finalFormationWindow = new Window_FinalFormation(rect);
			this.addWindow(this._finalFormationWindow);
			this.commandFormation();
			this._statusWindow.setHandler("cancel", this.popScene.bind(this));
			
		}
	};

	$openFormationMenu = function() {

			
		if (SceneManager._scene !== Scene_Menu) {
			SceneManager.push(Scene_Menu)
			$waitFormationMenu = true;
		}
		
	}
	
})();
